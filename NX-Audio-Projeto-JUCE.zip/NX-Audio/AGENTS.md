# AGENTS.md — FabFilter Pro-Q 3 (SC Clone) Architecture & Validation Guide

## 1. Visão Geral e Identificadores Preservados
- **Produto**: `FabFilter Pro-Q 3 (SC Clone)` (`ProQ3Clone`)
- **Formatos**: `VST3` e `Standalone` (Windows 64-bit, Visual Studio 2022, C++17, JUCE 8.0.4)
- **Identificadores VST3 Fixos**:
  - `PLUGIN_MANUFACTURER_CODE`: `ScAu`
  - `PLUGIN_CODE`: `Pq3C`
- **Compatibilidade de Sessões e Automação**:
  - Os IDs das 24 bandas (`band01_..` a `band24_..`) são imutáveis: `used`, `enabled`, `shape`, `freq`, `gain`, `q`, `slope`, `stereo`, `gain_q`, `dyn_range`, `dyn_enabled`, `dyn_auto`, `dyn_thresh`, `dyn_ext_sc`.
  - Excluir uma banda (`used = false`) nunca renumera nem desloca os slots `band01`..`band24`, garantindo que automações já gravadas no Studio One continuem vinculadas à banda correta (conforme manual oficial do Pro-Q 3, p. 12).

## 2. Arquitetura de Arquivos
- `CMakeLists.txt`: Configuração CMake para MSVC 2022 x64 + JUCE 8.0.4.
- `build_win64.bat`: Script de compilação local Windows x64 (usa `cd /d "%~dp0"` para nunca executar em `C:\Windows\System32`).
- `Source/PluginProcessor.h` & `Source/PluginProcessor.cpp`:
  - Motor DSP em ponto flutuante de 64 bits (`double`), livre de alocações no `processBlock`.
  - 9 tipos de filtro (`Bell`, `Low Shelf`, `Low Cut`, `High Shelf`, `High Cut`, `Notch`, `Band Pass`, `Tilt Shelf`, `Flat Tilt`) e 10 inclinações (`6 dB/oct` a `96 dB/oct` + `Brickwall`).
  - Detector dinâmico band-limited por banda com `Auto Threshold`, `Manual Threshold` (-60 a 0 dB), soft-knee de 6 dB e chaveamento entre entrada principal (`Input`) e barramento auxiliar (`Sidechain`).
- `Source/PluginEditor.h` & `Source/PluginEditor.cpp`:
  - Gráfico interativo logarítmico (10 Hz – 30 kHz), analisador FFT Pre/Post/Sidechain (4096 pontos, tilt de 4.5 dB/oct) e `ConcentricGainDynamicsComponent` (knob central de ganho estático + anel externo independente de faixa dinâmica + arco amarelo em tempo real).
- `Tests/test_proq3_acceptance.cpp`: Suite de testes automatizados C++17 que valida todos os cenários do Teste de Aceitação com erro < 0.05 dB.
- `.github/workflows/build_windows_vst3.yml`: Pipeline GitHub Actions (`windows-latest`) para compilação MSVC 2022 Release, execução da suite de testes C++, validação com `pluginval --strictness-level 10` e publicação automática em tags `v*.*.*`.

## 3. Licenças das Dependências
- **JUCE 8.0.4**: Dual license (JUCE Personal/Indie/Pro ou GPLv3) — https://juce.com/legal/juce-8-licence/
- **Steinberg VST3 SDK** (embutido via JUCE): Steinberg VST3 License / GPLv3.
- **Código-fonte e arte gráfica de `ProQ3Clone`**: Código C++17 e renderização vetorial `juce::Graphics` 100% próprios, construídos exclusivamente a partir de documentação pública (`ffproq3-manual.pdf`) sem engenharia reversa ou extração de assets.
