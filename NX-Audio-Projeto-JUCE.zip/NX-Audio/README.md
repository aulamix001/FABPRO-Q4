# NX Audio

Projeto editável de equalizador dinâmico em C++17, JUCE 8.0.4 e CMake. O nome interno do alvo é `ProQ3Clone`. O nome exibido na DAW é `NX Audio`, o cabeçalho usa `NX Audio Pro EQ³` e o pacote Windows é `NX Audio.vst3`. Os IDs de classe VST3 anteriores identificam as instâncias salvas nas sessões.

## Para continuar em outra IA

Extraia o ZIP e abra a pasta que contém este README e o `CMakeLists.txt`. Use estas notas como ponto de partida para o estado atual do projeto. O `AGENTS.md` veio com o projeto e descreve a arquitetura original.

- `Source/PluginProcessor.cpp` e `.h` contêm o DSP, os parâmetros de automação, o estado de sessão e a aplicação dos presets. Preserve os IDs `ScAu`, `Pq3C` e os IDs dos parâmetros existentes para manter a compatibilidade com as sessões da DAW.
- `Source/PluginEditor.cpp` e `.h` contêm a interface responsiva, o gráfico, os controles de banda e o painel de saída. A janela padrão é de 900 × 540.
- `Source/FactoryPresets.h` contém os 38 presets. Os 34 presets baseados em capturas foram estimados pelo gráfico. Os presets dinâmicos estão agrupados em Drums, Instruments e Vocals.
- `Tests/test_proq3_acceptance.cpp` contém a suíte DSP independente. `Assets/` reúne as imagens de referência do projeto. A interface é desenhada pelo JUCE.
- `build_win64.bat` e `.github/workflows/build_windows_vst3.yml` contêm os caminhos de build Windows.

O painel de saída abre por hover sobre a leitura de porcentagem e dB. Ele controla volume, escala de ganho, balanço L/R ou M/S, polaridade e Auto Gain. O ícone de piano alterna o teclado. O preset Default Setting abre com o gráfico plano. O gráfico usa uma curva total dourada e preenchimentos translúcidos nas respostas individuais e nas faixas dinâmicas. O seletor do gráfico alterna entre 12, 6, 3 e 30 dB e o menu Analyzer controla as leituras de entrada, saída e sidechain. MIDI Learn associa mensagens MIDI CC ao volume de saída e à escala de ganho e salva essas associações com a sessão.

O seletor permite carregar Natural Phase e Linear Phase. O DSP atual ainda usa o mesmo caminho de processamento nesses modos. A última distribuição Windows foi compilada por cross-compilation e validada no Wine. Os comandos abaixo são para um build nativo Windows com Visual Studio.

## Build Windows x64

Requer Git, CMake 3.22 ou mais recente, Visual Studio 2022 com Desenvolvimento para Desktop com C++ e JUCE 8.0.4. Execute na raiz do projeto em PowerShell.

```powershell
git clone --depth 1 --branch 8.0.4 https://github.com/juce-framework/JUCE.git JUCE
cmake -S . -B build -G "Visual Studio 17 2022" -A x64
cmake --build build --config Release --target ProQ3Clone_VST3 --parallel
```

O pacote é gerado em `build/ProQ3Clone_artefacts/Release/VST3/NX Audio.vst3`. Para gerar também o Standalone, execute `build_win64.bat` ou compile sem indicar um alvo específico.

O ZIP de fontes não inclui a dependência JUCE. A revisão usada é `51d11a2be6d5c97ccf12b4e5e827006e19f0555a` da tag `8.0.4`.

## Espectro, medição e filtros

O analisador calcula a FFT separadamente para L e R e combina as potências. Isso preserva sinais em oposição de fase. As janelas Hann de 4096 pontos se sobrepõem em 75% e o gráfico termina em Nyquist. Pre-EQ, Post-EQ e Sidechain compartilham a mesma escala em dBFS do medidor. O medidor retém o pico por 1,5 s antes de baixar a marca.

Os filtros Low Cut e High Cut usam seções Butterworth da ordem correspondente à inclinação. Configurações de 6, 18 e 30 dB/oct incluem uma seção de primeira ordem. A opção Brickwall usa uma aproximação IIR de 16ª ordem. Os IDs de parâmetros são preservados.

## Etiquetas do espectro

As etiquetas amarelas com texto preto aparecem após cerca de dois segundos com o cursor parado sobre o traço ou a área preenchida do espectro. O gráfico marca até cinco picos persistentes. Usa Post-EQ quando visível, seguido de Pre-EQ e Sidechain. Ao sair do gráfico, as etiquetas somem. Com Spectrum Grab desligado, use Peak Labels para exibir as etiquetas durante a pausa do cursor sem congelar o espectro. O estado de Peak Labels é salvo com a sessão.

## Solo de banda

Pressione e segure o ícone vermelho de fone no cartão da banda ou no painel da banda selecionada. O Solo deixa ouvir a faixa de frequência afetada. Em Low Cut e High Cut, a escuta isola a região que o corte atenua. Arraste na horizontal para alterar a frequência ou na vertical para ajustar o nível de escuta. Mantenha Ctrl ou Command ao arrastar na vertical para ajustar Q. Solte o botão ou pressione Escape para voltar ao EQ completo. O nível de escuta começa em −6 dB e o Solo é momentâneo.

## Atalho de Dynamic EQ

Passe o mouse sobre uma banda que suporte Dynamic EQ. O cartão da banda mostra um ícone de pulso no canto superior direito. Clique para selecionar a banda e abrir os controles dinâmicos. O ganho e a faixa dinâmica permanecem nos valores atuais.

## Painel do analisador e Dynamic EQ

Passe o mouse sobre Pre+Post na barra inferior para abrir o painel Spectrum. Clique para fixá-lo. Os botões Pre e Post funcionam separadamente. A lista mostra miniaturas ao vivo do Sidechain e das instâncias do NX Audio no mesmo processo da DAW. Escolha uma linha para colocar o sinal no gráfico. External Spectrum Off desativa a referência externa. O painel usa o nome da faixa que a DAW fornece pelo VST3. Em uma DAW que não envia esse nome, clique duas vezes no nome no cabeçalho da própria instância e digite um nome para salvar na sessão. Freeze segura os espectros. Spectrum Overlap vem ativado e colore em vermelho translúcido as regiões com energia em comum em cada linha, inclusive com External Spectrum Off. Escolha uma linha para ver a mesma região no gráfico principal. O botão de ajustes abre Range, Resolution, Speed, Tilt, Trace Detail e Peak Labels.

O botão Spectrum Grab vem ativo por padrão. Com Pre ou Post ligado, pause o mouse sobre o espectro por aproximadamente dois segundos. O traço congela, as bandas ficam atenuadas e as etiquetas mostram os picos em Hz ou em notas quando o piano está ligado. Arraste uma etiqueta ou o ponto marcado para criar e ajustar uma banda. Ao soltar, o analisador volta a acompanhar o sinal. O painel flutuante acompanha a posição horizontal da banda selecionada. Arraste verticalmente na régua de frequência ou use a roda para dar zoom. Arraste lateralmente para deslocar a visualização ampliada. Clique duas vezes na régua para voltar à escala completa.

Em Dynamic EQ, desative Auto para acessar o limiar manual e o medidor vertical do detector. Arraste o cursor do medidor ou clique duas vezes no valor para digitar o limiar. O botão SC alterna o acionamento pelo Sidechain.

## EQ Match e referências

Abra EQ Match pelo painel Spectrum. Reproduza o áudio para gravar o perfil de entrada. Em Reference, escolha Input para gravar outra tomada pela mesma entrada, External para usar o espectro selecionado no analisador ou um perfil salvo. Save Input as Reference salva o perfil atual por nome na biblioteca local do usuário. Reset Input inicia uma nova captura e preserva o perfil de referência.

Clique em Match para visualizar a correção. Escolha quantas bandas usar e clique em Apply Match para aplicar bandas editáveis. O algoritmo estima correções espectrais em 18 regiões, remove a diferença média de nível e limita cada banda a ±6 dB.
