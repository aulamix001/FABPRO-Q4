# NX Audio

Projeto editável de equalizador dinâmico em C++17, JUCE 8.0.4 e CMake. O nome interno do alvo é `ProQ3Clone`. O nome exibido na DAW é `NX Audio`, o cabeçalho usa `NX Audio Pro EQ³` e o pacote Windows é `NX Audio.vst3`. Os IDs de classe VST3 anteriores identificam as instâncias salvas nas sessões.

## Para continuar em outra IA

Extraia o ZIP e abra a pasta que contém este README e o `CMakeLists.txt`. Use estas notas como ponto de partida para o estado atual do projeto. O `AGENTS.md` veio com o projeto e descreve a arquitetura original.

- `Source/PluginProcessor.cpp` e `.h` contêm o DSP, os parâmetros de automação, o estado de sessão e a aplicação dos presets. Preserve os IDs `ScAu`, `Pq3C` e os IDs dos parâmetros existentes para manter a compatibilidade com as sessões da DAW.
- `Source/PluginEditor.cpp` e `.h` contêm a interface responsiva, o gráfico, os controles de banda e o painel de saída. A janela padrão é de 900 × 540.
- `Source/FactoryPresets.h` contém os 38 presets. Os 34 presets baseados em capturas foram estimados pelo gráfico. Os presets dinâmicos estão agrupados em Drums, Instruments e Vocals.
- `Tests/test_proq3_acceptance.cpp` contém a suíte DSP independente. `Assets/` reúne as imagens de referência do projeto. A interface é desenhada pelo JUCE.
- `build_win64.bat` e `.github/workflows/build_windows_vst3.yml` contêm os caminhos de build Windows.

O painel de saída abre por hover sobre a leitura de porcentagem e dB. Ele controla volume, escala de ganho, balanço L/R ou M/S, polaridade e Auto Gain. O ícone de piano alterna o teclado. O preset Default Setting abre com o gráfico plano. O gráfico usa uma curva total dourada e preenchimentos translúcidos nas respostas individuais e nas faixas dinâmicas. O seletor do gráfico alterna entre 12, 6, 3 e 30 dB e o menu Analyzer controla as leituras de entrada, saída e sidechain. MIDI Learn associa mensagens MIDI CC ao volume de saída e à escala de ganho e salva essas associações com a sessão.

O seletor permite carregar Natural Phase e Linear Phase. O DSP atual ainda usa o mesmo caminho de processamento nesses modos. A última distribuição Windows foi compilada por cross-compilation e validada no Wine. Os comandos abaixo são para um build nativo Windows com Visual Studio.

## Build Windows x64

Requer Git, CMake 3.22 ou mais recente, Visual Studio 2022 com Desenvolvimento para Desktop com C++ e JUCE 8.0.4. Execute na raiz do projeto em PowerShell.

```powershell
git clone --depth 1 --branch 8.0.4 https://github.com/juce-framework/JUCE.git JUCE
cmake -S . -B build -G "Visual Studio 17 2022" -A x64
cmake --build build --config Release --target ProQ3Clone_VST3 --parallel
```

O pacote é gerado em `build/ProQ3Clone_artefacts/Release/VST3/NX Audio.vst3`. Para gerar também o Standalone, execute `build_win64.bat` ou compile sem indicar um alvo específico.

O ZIP de fontes não inclui a dependência JUCE. A revisão usada é `51d11a2be6d5c97ccf12b4e5e827006e19f0555a` da tag `8.0.4`.

## Espectro, medição e filtros

O analisador calcula a FFT separadamente para L e R e combina as potências. Isso preserva sinais em oposição de fase. As janelas Hann de 4096 pontos se sobrepõem em 75% e o gráfico termina em Nyquist. Pre-EQ, Post-EQ e Sidechain compartilham a mesma escala em dBFS do medidor. O medidor retém o pico por 1,5 s antes de baixar a marca.

Os filtros Low Cut e High Cut usam seções Butterworth da ordem correspondente à inclinação. Configurações de 6, 18 e 30 dB/oct incluem uma seção de primeira ordem. A opção Brickwall usa uma aproximação IIR de 16ª ordem. Os IDs de parâmetros são preservados.

## Etiquetas do espectro

As etiquetas amarelas com texto preto aparecem após cerca de dois segundos com o cursor parado sobre o traço ou a área preenchida do espectro. O gráfico marca até cinco picos persistentes. Usa Post-EQ quando visível, seguido de Pre-EQ e Sidechain. Com Spectrum Grab desligado, use Peak Labels para exibir as etiquetas sem congelar o espectro. Nesse modo as etiquetas somem ao sair do gráfico. O estado de Peak Labels é salvo com a sessão.

## Solo de banda

Pressione e segure o ícone vermelho de fone no cartão da banda ou no painel da banda selecionada. O Solo deixa ouvir a faixa de frequência afetada. Em Low Cut e High Cut, a escuta isola a região que o corte atenua. Arraste na horizontal para alterar a frequência ou na vertical para ajustar o nível de escuta. Mantenha Ctrl ou Command ao arrastar na vertical para ajustar Q. Solte o botão ou pressione Escape para voltar ao EQ completo. O nível de escuta começa em −6 dB e o Solo é momentâneo.

## Atalho de Dynamic EQ

Passe o mouse sobre uma banda que suporte Dynamic EQ. O cartão da banda mostra um ícone de pulso no canto superior direito. Clique para selecionar a banda e abrir os controles dinâmicos. O ganho e a faixa dinâmica permanecem nos valores atuais.

## Painel do analisador e Dynamic EQ

Passe o mouse sobre Pre+Post na barra inferior para abrir o painel Spectrum. Clique para fixá-lo. Os botões Pre e Post funcionam separadamente. A lista mostra miniaturas ao vivo do Sidechain e das instâncias do NX Audio no mesmo processo da DAW. Escolha uma linha para colocar o sinal no gráfico. External Spectrum Off desativa a referência externa. O painel usa o nome da faixa que a DAW fornece pelo VST3. Em uma DAW que não envia esse nome, clique duas vezes no nome no cabeçalho da própria instância e digite um nome para salvar na sessão. Freeze segura os espectros. Spectrum Overlap vem ativado e colore em vermelho translúcido as regiões com energia em comum em cada linha, inclusive com External Spectrum Off. Escolha uma linha para ver a mesma região no gráfico principal. O botão de ajustes abre Range, Resolution, Speed, Tilt, Trace Detail e Peak Labels.

O botão Spectrum Grab vem ativo por padrão. Com Pre ou Post ligado, pause o mouse sobre o espectro por aproximadamente dois segundos. O traço congela, as bandas ficam atenuadas e as etiquetas mostram os picos em Hz ou em notas quando o piano está ligado. Os picos ficam no lugar enquanto você move o mouse até eles, mesmo se o ponteiro sair do gráfico. O painel da banda recolhe temporariamente para liberar o acesso aos picos. Arraste uma etiqueta ou o ponto marcado para criar e ajustar uma banda. Ao soltar, o analisador volta ao sinal ao vivo e o painel da banda reaparece. Pressione Escape para cancelar a captura. O painel flutuante acompanha a posição horizontal da banda selecionada. Arraste verticalmente na régua de frequência ou use a roda para dar zoom. Arraste lateralmente para deslocar a visualização ampliada. Clique duas vezes na régua para voltar à escala completa.

Em Dynamic EQ, o medidor vertical acompanha o nível do sinal do detector, e a curva e o arco de ganho acompanham a mudança de ganho efetivamente aplicada, inclusive durante a soltura. Desative Auto para acessar o limiar manual e o medidor. Arraste o cursor do medidor ou clique duas vezes no valor para digitar o limiar. O botão SC alterna o acionamento pelo Sidechain.

## EQ Match e referências

Abra EQ Match pelo painel Spectrum. Reproduza o áudio para gravar o perfil de entrada. Em Reference, escolha Input para gravar outra tomada pela mesma entrada, External para usar o espectro selecionado no analisador ou um perfil salvo. Save Input as Reference salva o perfil atual por nome na biblioteca local do usuário. Reset Input inicia uma nova captura e preserva o perfil de referência.

Clique em Match para visualizar a correção. Escolha quantas bandas usar e clique em Apply Match para aplicar bandas editáveis. O algoritmo estima correções espectrais em 18 regiões, remove a diferença média de nível e limita cada banda a ±6 dB.


## Prévia da curva e cartão da banda

Mova o mouse abaixo da linha de 0 dB para ver uma sugestão verde discreta. A prévia mostra Bell no centro e filtros de corte nas extremidades. Clique duas vezes para inserir a banda sugerida. No cartão, o ícone de forma abre a régua de filtros, e o botão de opções abre Shape, Slope, Stereo Placement, Cut, Copy, Paste, Split e os controles de dinâmica. O fone fica vermelho ao passar o mouse ou durante o Solo.

As bandas Left usam verde e as Right usam vermelho no gráfico e nos controles. All Pass altera a fase e preserva a magnitude.

## Modo Spectral

Use Make Spectral no menu de uma banda que suporte dinâmica. O NX Audio divide a região em cinco subfaixas com detectores independentes. O gráfico mostra a resposta combinada das subfaixas, e o processamento usa filtros IIR sem atraso adicional de bloco. Use o ganho dinâmico e o limiar para controlar o efeito.

## Visão de pistas

Clique no nome da pista na barra inferior. Track overview mostra os nomes, as curvas do EQ e os espectros das instâncias do NX Audio no mesmo processo da DAW. Search filtra a lista e Graph size muda a altura e a largura das miniaturas. Dê duplo clique numa pista para usar o espectro dela no analisador principal. Back to EQ ou Esc volta ao EQ.


## Revisão do manual de referência

A referência consultada foi o manual FabFilter Pro-Q 4 fornecido na conversa. A revisão priorizou os controles da visão geral e os exemplos de EQ Sketch, Band Controls, Spectral Dynamics, Instance List, Stereo Options e Character.

- A forma selecionada é mostrada como ícone. Shape e Stereo Placement abrem para cima, com ícones e nomes nas opções. FREQ, GAIN, Q e o cartão da banda têm acabamento translúcido, iluminação e dicas contextuais. Right mantém o realce vermelho.
- Clique no lápis EQ Sketch para desenhar da esquerda para a direita. Volte no traço para revisá-lo e solte para converter os trechos em bandas. Um Undo desfaz o gesto.
- Character oferece Clean, Subtle e Warm. Subtle e Warm aplicam níveis diferentes de saturação após o EQ e antes do controle de saída.
- Use Alt+Shift+clique para criar uma banda Spectral ou clique em Spec nos controles da banda. Density altera a largura das subfaixas e Tilt inclina o detector em 3 dB por oitava. O motor Spectral do NX Audio é um banco IIR de cinco subfaixas.
- O ícone junto ao nome da pista abre Track Overview. Graph size redimensiona os gráficos e os nós refletem as bandas reais. As áreas vermelhas indicam sobreposição com o espectro de referência.

Ainda ficam pendentes o processamento Natural Phase e Linear Phase distinto do caminho IIR, a resolução de fase linear, Spectral com fase linear e resolução variável, Atmos e os controles avançados de edição direta e fixação de pistas entre instâncias. A visão de pistas atual permite consulta, zoom, busca e comparação entre instâncias do NX Audio no mesmo processo da DAW.


## Split EQ e mascaramento

- Ative **Split EQ** no rodapé. O seletor da banda oferece **Both** (branco/cinza), **Transient** (verde) e **Tonal** (azul). Both aplica os mesmos ajustes aos dois caminhos.
- No menu de uma banda Both, **Separate Transient and Tonal** duplica seus ajustes em duas bandas independentes. A operação usa um dos 24 slots existentes. Desligar Split EQ suspende bandas isoladas e mantém seus ajustes na sessão.
- A separação causal do NX Audio estima ataques em quatro regiões de frequência e usa o sinal residual como componente tonal. O processamento das bandas ocorre em paralelo, sem latência adicional. O espectro Post e as duas barras coloridas exibem os componentes após o EQ. A leitura numérica em dB continua mostrando o pico da saída final.
- No Analyzer, escolha uma instância do NX Audio ou ative Sidechain. Com **Spectrum Overlap** ligado, as frequências sobrepostas aparecem em vermelho no topo do gráfico, com profundidade proporcional à intensidade da sobreposição.
