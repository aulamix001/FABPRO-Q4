#pragma once

#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_dsp/juce_dsp.h>
#include <array>
#include <atomic>
#include <complex>
#include <optional>
#include <vector>

class ProQ3AudioProcessor final : public juce::AudioProcessor
{
public:
    static constexpr int kMaxBands = 24;
    static constexpr int kMaxCascadedSections = 8; // Até 96 dB/oct + Brickwall (8 biquads em cascata)
    static constexpr int kFftOrder = 12;
    static constexpr int kFftSize = 1 << kFftOrder;
    static constexpr int kFftBins = kFftSize / 2 + 1;
    static constexpr float kMeterFloorDb = -100.0f;

    // 9 Tipos de Filtro conforme manual oficial do FabFilter Pro-Q 3 (p. 11: Band controls -> shape)
    enum FilterShape : int
    {
        kShapeBell      = 0, // 1. Bell
        kShapeLowShelf  = 1, // 2. Low Shelf
        kShapeLowCut    = 2, // 3. Low Cut
        kShapeHighShelf = 3, // 4. High Shelf
        kShapeHighCut   = 4, // 5. High Cut
        kShapeNotch     = 5, // 6. Notch
        kShapeBandPass  = 6, // 7. Band Pass
        kShapeTiltShelf = 7, // 8. Tilt Shelf
        kShapeFlatTilt  = 8, // 9. Flat Tilt
        kShapeAllPass   = 9
    };

    // 10 Inclinações conforme manual oficial (6 a 96 dB/oct + Brickwall para Low/High Cut)
    enum FilterSlope : int
    {
        kSlope6dB       = 0,
        kSlope12dB      = 1,
        kSlope18dB      = 2,
        kSlope24dB      = 3,
        kSlope30dB      = 4,
        kSlope36dB      = 5,
        kSlope48dB      = 6,
        kSlope72dB      = 7,
        kSlope96dB      = 8,
        kSlopeBrickwall = 9
    };

    struct BiquadCoeffs
    {
        double b0 = 1.0, b1 = 0.0, b2 = 0.0;
        double a1 = 0.0, a2 = 0.0;
    };

    struct BiquadState
    {
        double z1L = 0.0, z2L = 0.0;
        double z1R = 0.0, z2R = 0.0;

        void reset() noexcept
        {
            z1L = z2L = z1R = z2R = 0.0;
        }
    };

    enum class SignalTarget { both, transient, tonal };

    struct BandParameters
    {
        bool used       = false;
        bool enabled    = true;
        int shape       = kShapeBell;  // 0..8 (9 tipos do manual)
        double freqHz   = 1000.0;      // 10.0 a 30000.0 Hz
        double gainDb   = 0.0;         // -30.0 a +30.0 dB
        double q        = 1.0;         // 0.025 a 40.0
        int slopeIndex  = kSlope12dB;  // 0..9 (6 dB/oct a 96 dB/oct + Brickwall)
        int stereoMode  = 0;           // 0: Stereo, 1: Left, 2: Right, 3: Mid, 4: Side
        bool gainQInter = false;       // Gain-Q interaction

        // Parâmetros de EQ Dinâmico e Sidechain (Manual Pro-Q 3 p. 13-14)
        double dynRangeDb    = 0.0;    // -30.0 a +30.0 dB (0.0 = estático)
        bool   dynEnabled    = true;   // Bypass dynamics button (true = dinâmica ativa, false = suspensa)
        bool   dynAutoThresh = true;   // Auto Threshold vs Manual Threshold slider
        double dynThresholdDb = -18.0; // -60.0 a 0.0 dB (preservado mesmo quando dynAutoThresh == true)
        bool   dynExtSidechain = false;// false = Main Input, true = External Side Chain
        bool   spectral = false;
        double spectralDensity = 0.5;
        bool   spectralTilt = true;
        SignalTarget signalTarget = SignalTarget::both;
    };

    struct BandDynamicState
    {
        BiquadCoeffs detectorBpCoeffs;
        BiquadState  detectorBpState;
        double fastEnvLin      = 0.0;   // Envelope rápido do sinal detector
        double slowAutoRefLin  = 0.01;  // Referência adaptativa lenta para o modo Auto Threshold
        double smoothedGainModDb = 0.0; // Ganho dinâmico atual (redução < 0 ou expansão > 0) em dB
        double detectorLevelDb = -100.0;

        void reset() noexcept
        {
            detectorBpState.reset();
            fastEnvLin = 0.0;
            slowAutoRefLin = 0.01;
            smoothedGainModDb = 0.0;
            detectorLevelDb = -100.0;
        }
    };

    static constexpr size_t spectralRegionCount = 5;
    struct SpectralRegionState
    {
        BandDynamicState detector;
        BiquadCoeffs filter;
        BiquadState filterState;
        double detectedPeak = 0.0;
        double gainDb = 0.0;
    };

    struct BandDspChain
    {
        int activeSections = 1;
        std::array<BiquadCoeffs, kMaxCascadedSections> coeffs;
        std::array<BiquadState, kMaxCascadedSections> states;
        BandDynamicState dynState;
        std::array<SpectralRegionState, spectralRegionCount> spectralRegions {};
        int spectralSamples = 0;
        bool spectralWasActive = false;
        bool wasProcessing = false;
    };

    ProQ3AudioProcessor();
    ~ProQ3AudioProcessor() override;

    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;

    bool isBusesLayoutSupported (const BusesLayout& layouts) const override;

    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override;

    const juce::String getName() const override;

    bool acceptsMidi() const override;
    bool producesMidi() const override;
    bool isMidiEffect() const override;
    double getTailLengthSeconds() const override;

    int getNumPrograms() override;
    int getCurrentProgram() override;
    void setCurrentProgram (int index) override;
    const juce::String getProgramName (int index) override;
    void changeProgramName (int index, const juce::String& newName) override;

    void getStateInformation (juce::MemoryBlock& destData) override;
    void setStateInformation (const void* data, int sizeInBytes) override;

    // Helpers de IDs do APVTS para as 24 bandas (preservando IDs originais)
    static juce::String getBandParamID (int bandIndex, const juce::String& suffix);
    static juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout();

    // Regras de formato do manual Pro-Q 3
    static bool doesShapeSupportGain (int shape) noexcept;
    static bool doesShapeSupportDynamics (int shape) noexcept;
    static bool doesShapeSupportQ (int shape, int slopeIndex) noexcept;

    // Leitura de parâmetros de uma banda (0..23)
    BandParameters getBandParameters (int bandIndex) const noexcept;

    struct BandDynamicsReading
    {
        float gainDb = 0.0f;
        float detectorDb = -100.0f;
    };

    BandDynamicsReading getBandDynamicsReading (int bandIndex, bool tonalReading = false) const noexcept;
    float getBandDynamicGainDb (int bandIndex) const noexcept { return getBandDynamicsReading (bandIndex).gainDb; }
    float getBandDetectorLevelDb (int bandIndex) const noexcept { return getBandDynamicsReading (bandIndex).detectorDb; }

    struct BandResponse
    {
        std::array<BiquadCoeffs, kMaxCascadedSections> coefficients {};
        int sections = 0;
        double sampleRate = 44100.0;

        double magnitudeDbAtFrequency (double freqHz) const noexcept;
    };

    BandResponse makeBandResponse (BandParameters parameters, double dynamicGainDb = 0.0) const noexcept;

    struct SpectralResponse
    {
        std::array<BandResponse, spectralRegionCount> regions {};
        double magnitudeDbAtFrequency (double hz) const noexcept;
    };
    SpectralResponse makeSpectralResponse (const BandParameters&, int band, bool fullRange, bool tonalReading = false) const noexcept;

    // Cálculo analítico exato da magnitude em dB da função de transferência H(e^(jw))
    // includeDynamicGain = false -> retorna a curva estática; true -> inclui o ganho dinâmico instantâneo aplicado pelo DSP
    double getBandMagnitudeDbAtFrequency (int bandIndex, double freqHz, bool includeDynamicGain = false) const noexcept;
    double getTotalMagnitudeDbAtFrequency (double freqHz, bool includeDynamicGain = false) const noexcept;
    double getChannelMagnitudeDbAtFrequency (double freqHz, int targetChannel, bool includeDynamicGain = false) const noexcept;

    static int getFactoryPresetCount() noexcept;
    static juce::String getFactoryPresetName (int index);
    static juce::String getFactoryPresetCategory (int index);
    int getFactoryPresetIndex() const;
    void loadFactoryPreset (int index);

    // Ativa uma nova banda livre na frequência e ganho clicados
    int activateFirstFreeBand (float freqHz, float gainDb, float qValue = 1.0f, int shape = kShapeBell, float dynRangeDb = 0.0f, bool newUndoTransaction = true);
    void deactivateBand (int bandIndex);
    int activateFirstFreeBand (const BandParameters&, bool newUndoTransaction = true);
    void applyBandParameters (int bandIndex, const BandParameters&);

    // Suporte A/B Switch e Copy
    void toggleABState();
    void copyActiveToInactiveState();

    enum class MidiOutputTarget { outputLevel, gainScale };
    void armMidiLearn (MidiOutputTarget target) noexcept;
    void clearMidiLearn() noexcept;
    bool isMidiLearnArmed() const noexcept;
    bool hasMidiOutputMapping() const noexcept;
    bool isStateBActive() const noexcept { return currentIsB; }

    // Analisador de espectro Pre/Post/Sidechain e Spectrum Grab
    static float spectrumTiltDb (double frequency) noexcept;
    bool pullNextPreFftBlock (std::vector<float>& destMagnitudesDb);
    bool pullNextPostFftBlock (std::vector<float>& destMagnitudesDb);
    bool pullNextSidechainFftBlock (std::vector<float>& destMagnitudesDb);
    bool pullNextSplitSpectrum (size_t component, std::vector<float>& destMagnitudesDb);
    bool isSplitEqEnabled() const noexcept { return splitEqParameter->load (std::memory_order_relaxed) >= 0.5f; }
    float getSplitPeakDb (size_t component) const noexcept
    {
        return splitPeakDb[component].load (std::memory_order_relaxed);
    }

    struct SpectrumPeer
    {
        int id;
        juce::String name;
        juce::Colour colour;
    };
    juce::Colour getSpectrumTrackColour() const;
    juce::String getSpectrumInstanceName() const;
    bool hasSpectrumTrackName() const;
    void setSpectrumInstanceAlias (juce::String);
    std::vector<SpectrumPeer> getSpectrumPeers() const;
    bool readPostSpectrum (juce::uint64& generation, std::vector<float>& magnitudes);
    bool readPeerSpectrum (int peerId, std::vector<float>& magnitudes, double& rate);
    struct OverviewCurve
    {
        struct Marker
        {
            float frequency;
            float gain;
            int placement;
            SignalTarget signalTarget;
            int slot;
            bool enabled;
        };
        std::array<float, 80> common {}, left {}, right {};
        std::array<std::array<float, 80>, 2> split {};
        bool hasSplit = false;
        std::array<Marker, kMaxBands> markers {};
        size_t markerCount = 0;
        bool hasLeft = false;
        bool hasRight = false;
    };
    bool readOverviewCurve (int peerId, OverviewCurve&) const;
    bool withOverviewTrack (int peerId, const std::function<void (ProQ3AudioProcessor&)>&);
    void updateTrackProperties (const TrackProperties&) override;

    float getOutputPeakDbL() const noexcept { return outputPeakDbL.load (std::memory_order_relaxed); }
    float getOutputPeakDbR() const noexcept { return outputPeakDbR.load (std::memory_order_relaxed); }
    float getOutputHeldPeakDb (size_t channel) const noexcept
    {
        return outputHeldPeakDb[channel].load (std::memory_order_relaxed);
    }

    double getCurrentSampleRate() const noexcept { return currentSampleRate.load (std::memory_order_relaxed); }

    int getSelectedBandIndex() const noexcept { return selectedBandIndex.load (std::memory_order_relaxed); }
    void setSelectedBandIndex (int idx) noexcept { selectedBandIndex.store (juce::jlimit (-1, kMaxBands - 1, idx), std::memory_order_relaxed); }

    void setSoloBandIndex (int idx, float levelDb = -6.0f) noexcept;
    BandResponse makeSoloBandResponse (BandParameters parameters) const noexcept;
    int getSoloBandIndex() const noexcept { return soloBandIndex.load (std::memory_order_relaxed); }

    // Cálculo estático dos coeficientes para qualquer um dos 9 tipos de filtro e inclinações
    static void computeFilterCascadeCoeffs (const BandParameters& params,
                                            double sampleRate,
                                            double gainScale,
                                            double dynamicGainOffsetDb,
                                            std::array<BiquadCoeffs, kMaxCascadedSections>& outCoeffs,
                                            int& outNumSections) noexcept;

    static void computeBandDetectorCoeffs (double freqHz, double q, double sampleRate, BiquadCoeffs& outCoeffs) noexcept;

    // Cálculo de um passo do detector dinâmico por amostra (com Auto e Manual Threshold + Soft Knee)
    static double processDynamicEnvelopeSample (const BandParameters& bp,
                                                BandDynamicState& dynState,
                                                double detectorInputSample,
                                                double sampleRate,
                                                std::optional<double> detectorRightSample = std::nullopt) noexcept;

    juce::UndoManager undoManager;
    juce::AudioProcessorValueTreeState apvts;

private:
    void processMidiLearn (const juce::MidiBuffer& midiMessages);
    void processAudioRange (juce::AudioBuffer<float>&, int startSample, int numSamples);
    using BandSnapshot = std::array<BandParameters, kMaxBands>;
    void processEqBands (const BandSnapshot&, float* left, float* right, const float* scLeft, const float* scRight,
                         int numSamples, double sr, double gainScale, SignalTarget target);
    void processSplitEq (const BandSnapshot&, float* left, float* right, const float* scLeft, const float* scRight,
                         int numSamples, double sr, double gainScale, size_t fftSize, bool auditionComponent, bool newSoloBand);
    void resetEqProcessing() noexcept;
    void applyCharacter (float* left, float* right, int count, double rate, int mode) noexcept;
    void renderSolo (const float* left, const float* right, int numSamples,
                     const BandParameters&, const BandResponse&, bool newBand) noexcept;

    std::atomic<int> armedMidiTarget { -1 };
    std::array<std::atomic<int>, 2> learnedControllers { { -1, -1 } };
    std::array<juce::RangedAudioParameter*, 2> midiOutputParameters {};

    struct BandParameterValues
    {
        const std::atomic<float>* used = nullptr;
        const std::atomic<float>* enabled = nullptr;
        const std::atomic<float>* shape = nullptr;
        const std::atomic<float>* freqHz = nullptr;
        const std::atomic<float>* gainDb = nullptr;
        const std::atomic<float>* q = nullptr;
        const std::atomic<float>* slopeIndex = nullptr;
        const std::atomic<float>* stereoMode = nullptr;
        const std::atomic<float>* gainQInter = nullptr;
        const std::atomic<float>* dynRangeDb = nullptr;
        const std::atomic<float>* dynEnabled = nullptr;
        const std::atomic<float>* dynAutoThresh = nullptr;
        const std::atomic<float>* dynThresholdDb = nullptr;
        const std::atomic<float>* dynExtSidechain = nullptr;
        const std::atomic<float>* spectral = nullptr;
        const std::atomic<float>* allPass = nullptr;
        const std::atomic<float>* spectralDensity = nullptr;
        const std::atomic<float>* spectralTilt = nullptr;
        const std::atomic<float>* signalTarget = nullptr;
    };

    std::array<BandParameterValues, kMaxBands> bandParameterValues;

    void updateAllFilterCoefficients() noexcept;
    OverviewCurve getOverviewCurve() const;
    void publishBandDynamics (size_t band, BandDynamicsReading reading, bool tonalReading = false) noexcept;
    BandDynamicsReading processSpectralBand (size_t band, BandDspChain&, bool tonalReading,
                                             const BandParameters&, float* left, float* right,
                                             const float* scLeft, const float* scRight, int count);
    static double updateDynamicEnvelope (const BandParameters&, BandDynamicState&, double level, double controlRate) noexcept;
    static std::array<BandParameters, spectralRegionCount> getSpectralRegions (const BandParameters&, double rate) noexcept;

    struct SpectrumCapture
    {
        using Channel = std::array<float, 8192>;
        using StereoBuffer = std::array<Channel, 2>;
        std::unique_ptr<StereoBuffer> history = std::make_unique<StereoBuffer>();
        std::unique_ptr<StereoBuffer> frame = std::make_unique<StereoBuffer>();
        size_t writeIndex = 0;
        size_t activeSize = kFftSize;
        size_t samplesUntilFrame = kFftSize;
        size_t publishedPlan = 2;

        void setResolution (size_t fftSize) noexcept
        {
            if (activeSize != fftSize)
            {
                activeSize = fftSize;
                resetHistory();
            }
        }
        enum class FrameState { empty, writing, ready, reading };
        std::atomic<FrameState> frameState { FrameState::empty };

        // The audio thread owns the history. The published frame is read by the editor.
        void push (float left, float right) noexcept
        {
            (*history)[0][writeIndex] = left;
            (*history)[1][writeIndex] = right;
            writeIndex = (writeIndex + 1) & (activeSize - 1);
            if (--samplesUntilFrame != 0)
                return;

            samplesUntilFrame = activeSize / 4;
            auto previous = frameState.load (std::memory_order_relaxed);
            if (previous == FrameState::reading
                || ! frameState.compare_exchange_strong (previous, FrameState::writing, std::memory_order_acquire))
                return;
            for (size_t channel = 0; channel < history->size(); ++channel)
            {
                const auto& samples = (*history)[channel];
                auto dest = std::copy (samples.begin() + static_cast<std::ptrdiff_t> (writeIndex),
                                       samples.begin() + static_cast<std::ptrdiff_t> (activeSize), (*frame)[channel].begin());
                std::copy_n (samples.begin(), writeIndex, dest);
            }
            publishedPlan = activeSize == 1024 ? 0 : activeSize == 2048 ? 1 : activeSize == 4096 ? 2 : 3;
            frameState.store (FrameState::ready, std::memory_order_release);
        }

        void resetHistory() noexcept
        {
            writeIndex = 0;
            samplesUntilFrame = activeSize;
            auto published = FrameState::ready;
            frameState.compare_exchange_strong (published, FrameState::empty, std::memory_order_relaxed);
        }
    };

    bool pullSpectrum (SpectrumCapture&, std::vector<float>&);
    void updateOutputMeter (float leftPeak, float rightPeak, int samples, double sampleRate) noexcept;

    SpectrumCapture preFftFifo;
    SpectrumCapture postFftFifo;
    SpectrumCapture sidechainFftFifo;
    std::array<SpectrumCapture, 2> splitFftFifos;
    struct OverviewTarget
    {
        juce::CriticalSection mutex;
        ProQ3AudioProcessor* processor = nullptr;
    };
    const std::shared_ptr<OverviewTarget> overviewTarget = std::make_shared<OverviewTarget>();
    int spectrumPeerId = 0;
    struct SharedInstanceManager
    {
        juce::CriticalSection mutex;
        std::vector<ProQ3AudioProcessor*> instances;
        int nextId = 1;
    };
    juce::SharedResourcePointer<SharedInstanceManager> sharedInstances;
    juce::String spectrumTrackName;
    juce::Colour spectrumTrackColour { 0xffc81e51 };
    juce::String spectrumInstanceAlias;
    juce::String getSpectrumInstanceNameUnlocked() const;
    std::vector<float> cachedPostSpectrum;
    double lastPostSpectrumMs = 0.0;
    juce::uint64 postSpectrumGeneration = 0;
    void refreshPostSpectrum();
    struct SpectrumTransform
    {
        SpectrumTransform (int order)
            : size (size_t { 1 } << order), fft (order),
              window (size, juce::dsp::WindowingFunction<float>::hann) {}

        size_t size;
        juce::dsp::FFT fft;
        juce::dsp::WindowingFunction<float> window;
    };
    std::array<SpectrumTransform, 4> spectrumTransforms {{ { 10 }, { 11 }, { 12 }, { 13 } }};
    std::array<float, 8192 * 2> fftWorkspace {};

    using BandChains = std::array<BandDspChain, kMaxBands>;
    BandChains dspBands;
    std::unique_ptr<BandChains> tonalDspBands = std::make_unique<BandChains>();
    struct TransientRegion
    {
        float fast = 0.0f;
        float slow = 0.0f;
        float weight = 0.0f;
    };
    std::array<std::array<float, 3>, 2> splitLowPass {};
    std::array<TransientRegion, 4> splitEnvelopes {};
    std::array<std::atomic<float>, 2> splitPeakDb { { kMeterFloorDb, kMeterFloorDb } };
    const std::atomic<float>* splitEqParameter = nullptr;
    bool splitWasProcessing = false;
    std::array<std::atomic<juce::uint64>, kMaxBands> bandDynamicsReadings {};
    std::array<std::atomic<juce::uint64>, kMaxBands> tonalBandDynamicsReadings {};
    std::array<std::array<std::atomic<float>, spectralRegionCount>, kMaxBands> spectralGains {};
    std::array<std::array<std::atomic<float>, spectralRegionCount>, kMaxBands> tonalSpectralGains {};

    static constexpr int soloBufferSamples = 8192;
    using StereoWorkBuffer = std::array<std::array<float, soloBufferSamples>, 2>;
    StereoWorkBuffer soloAudio {};
    std::unique_ptr<StereoWorkBuffer> transientAudio = std::make_unique<StereoWorkBuffer>();
    std::array<BiquadState, kMaxCascadedSections> soloStates {};
    juce::SmoothedValue<float> characterAmount;
    std::array<float, 2> characterDc {}, characterTone {};
    juce::SmoothedValue<float> soloBlend;
    juce::SmoothedValue<float> soloGain;
    BandResponse soloResponse;
    BandParameters soloParameters;
    int renderedSoloBand = -1;

    std::atomic<double> currentSampleRate { 44100.0 };
    std::atomic<float> outputPeakDbL { kMeterFloorDb };
    std::atomic<float> outputPeakDbR { kMeterFloorDb };
    std::array<std::atomic<float>, 2> outputHeldPeakDb { { kMeterFloorDb, kMeterFloorDb } };
    std::array<int, 2> meterHoldSamples {};
    std::atomic<int> selectedBandIndex { -1 };
    std::atomic<int> soloBandIndex { -1 };
    std::atomic<float> soloLevelDb { -6.0f };

    juce::ValueTree stateA;
    juce::ValueTree stateB;
    bool currentIsB = false;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (ProQ3AudioProcessor)
};
