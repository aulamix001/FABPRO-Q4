#include "PluginEditor.h"
#include <cmath>

namespace
{
    constexpr int headerHeight = 43;
    constexpr int toolsHeight = 42;
    constexpr int settingsHeight = 184;
    constexpr int settingsRowHeight = 26;
    constexpr double previewLowHz = 25.0;
    constexpr double previewHighHz = 22000.0;

    const juce::Colour panelGold { 0xfff4bf56 };
    const juce::Colour panelText { 0xffe9e2ec };
    const juce::Colour panelMuted { 0xffb9adbf };
    const juce::Colour overlapColour { 0xffee2e41 };
    const std::array<const char*, 5> settingLabels { "Range", "Resolution", "Speed", "Tilt", "Trace detail" };

    float miniSpectrumPosition (double frequency)
    {
        return static_cast<float> (std::log (frequency / previewLowHz) / std::log (previewHighHz / previewLowHz));
    }
}

ProQ3AudioProcessorEditor::AnalyzerToolButton::AnalyzerToolButton (const char* name, Icon kind)
    : juce::Button (name), icon (kind)
{
    setClickingTogglesState (true);
}

void ProQ3AudioProcessorEditor::AnalyzerToolButton::paintButton (juce::Graphics& g, bool highlighted, bool down)
{
    const auto body = getLocalBounds().toFloat().reduced (0.65f);
    const auto active = getToggleState();
    auto accent = panelGold;
    switch (icon)
    {
        case Icon::freeze:   accent = juce::Colour (0xffa6c8ed); break;
        case Icon::grab:     accent = juce::Colour (0xffc698eb); break;
        case Icon::overlap:  accent = overlapColour; break;
        case Icon::settings: break;
    }

    g.setColour (down ? juce::Colour (0xbf211c2a) : highlighted ? juce::Colour (0xb95d4f65) : juce::Colour (0xaa39323f));
    g.fillRoundedRectangle (body, 5.0f);
    g.setColour (active && isEnabled() ? accent.withAlpha (0.55f) : juce::Colour (0x9063596b));
    g.drawRoundedRectangle (body, 5.0f, 1.0f);
    if (active && isEnabled())
    {
        g.setColour (accent.withAlpha (0.88f));
        g.fillRoundedRectangle (body.withSizeKeepingCentre (8.0f, 2.0f).withY (body.getBottom() - 4.0f), 1.0f);
    }

    const auto centre = body.getCentre();
    juce::Path mark;
    switch (icon)
    {
        case Icon::freeze:
            for (const float direction : { -1.0f, 1.0f })
            {
                mark.startNewSubPath (direction * 2.5f, -5.0f);
                mark.lineTo (direction * 2.5f, 5.0f);
            }
            mark.startNewSubPath (-6.0f, -1.0f);
            mark.lineTo (-4.5f, -1.0f);
            mark.startNewSubPath (4.5f, -1.0f);
            mark.lineTo (6.0f, -1.0f);
            break;
        case Icon::grab:
            mark.startNewSubPath (-7.0f, 3.5f);
            mark.lineTo (-4.0f, 1.0f);
            mark.lineTo (-1.0f, -3.5f);
            mark.lineTo (2.5f, 1.0f);
            mark.lineTo (6.5f, 0.0f);
            mark.addEllipse (-2.6f, -5.2f, 3.2f, 3.2f);
            break;
        case Icon::overlap:
            mark.startNewSubPath (-7.0f, 3.0f);
            mark.cubicTo (-3.0f, 3.0f, -5.0f, -4.5f, -1.0f, -4.5f);
            mark.cubicTo (2.0f, -4.5f, 1.0f, 3.0f, 6.5f, 3.0f);
            mark.startNewSubPath (-7.0f, 5.0f);
            mark.cubicTo (-0.5f, 4.5f, -0.5f, -1.5f, 2.4f, -1.5f);
            mark.quadraticTo (4.6f, -1.5f, 6.5f, 2.5f);
            break;
        case Icon::settings:
            for (int index = 0; index < 3; ++index)
            {
                const auto x = -5.0f + 5.0f * static_cast<float> (index);
                const auto offset = index == 1 ? 2.5f : -1.5f;
                mark.startNewSubPath (x, -5.5f);
                mark.lineTo (x, offset - 1.0f);
                mark.startNewSubPath (x, offset + 1.0f);
                mark.lineTo (x, 5.5f);
                mark.startNewSubPath (x - 1.5f, offset);
                mark.lineTo (x + 1.5f, offset);
            }
            break;
    }

    g.setColour (isEnabled() ? (active ? accent : panelText) : panelMuted.withAlpha (0.46f));
    g.strokePath (mark, juce::PathStrokeType (1.25f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded),
                  juce::AffineTransform::translation (centre.x, centre.y - 0.5f));
}

ProQ3AudioProcessorEditor::AnalyzerPanel::AnalyzerPanel()
{
    sourceList.setModel (this);
    sourceList.setRowHeight (rowHeight);
    sourceList.setColour (juce::ListBox::backgroundColourId, juce::Colours::transparentBlack);
    sourceList.setColour (juce::ScrollBar::thumbColourId, juce::Colour (0xaf776984));
    sourceList.setComponentID ("analyzer-external-source");
    sourceList.setTitle ("Spectrum sources");
    addAndMakeVisible (sourceList);

    instance.setJustificationType (juce::Justification::centred);
    instance.setFont (juce::FontOptions (12.5f, juce::Font::bold));
    instance.setColour (juce::Label::backgroundColourId, juce::Colour (0x551a1721));
    instance.setColour (juce::Label::outlineColourId, juce::Colour (0x6f69546d));
    instance.setColour (juce::Label::textColourId, panelText);
    instance.setComponentID ("analyzer-track-name");
    instance.setTitle ("Track name");
    addAndMakeVisible (instance);

    addChildComponent (settings);
}

ProQ3AudioProcessorEditor::AnalyzerPanel::~AnalyzerPanel()
{
    sourceList.setModel (nullptr);
}

void ProQ3AudioProcessorEditor::AnalyzerPanel::paint (juce::Graphics& g)
{
    const auto frame = getLocalBounds().toFloat().reduced (1.0f);
    juce::ColourGradient glass (juce::Colour (0xcd302933), frame.getTopLeft(),
                                 juce::Colour (0xe11d1a23), frame.getBottomLeft(), false);
    g.setGradientFill (glass);
    g.fillRoundedRectangle (frame, 9.0f);
    g.setColour (juce::Colour (0xb46a5b70));
    g.drawRoundedRectangle (frame, 9.0f, 1.0f);
    g.setColour (juce::Colour (0x8c322b39));
    g.fillRoundedRectangle (frame.withTrimmedTop (frame.getHeight() - toolsHeight + 2.0f).reduced (2.0f), 5.0f);
    g.setColour (juce::Colour (0x80635369));
    g.drawHorizontalLine (headerHeight - 1, 7.0f, frame.getRight() - 5.0f);
    g.drawHorizontalLine (getHeight() - toolsHeight, 7.0f, frame.getRight() - 5.0f);
}

void ProQ3AudioProcessorEditor::AnalyzerPanel::SettingsPane::paint (juce::Graphics& g)
{
    const auto frame = getLocalBounds().toFloat().reduced (0.75f);
    juce::ColourGradient glass (juce::Colour (0xfa332c3a), frame.getTopLeft(),
                                 juce::Colour (0xf52b2530), frame.getBottomLeft(), false);
    g.setGradientFill (glass);
    g.fillRoundedRectangle (frame, 8.0f);
    g.setColour (juce::Colour (0xcc716278));
    g.drawRoundedRectangle (frame, 8.0f, 1.0f);
    g.setFont (juce::FontOptions (12.0f));
    g.setColour (panelMuted);
    for (size_t i = 0; i < settingLabels.size(); ++i)
        g.drawText (settingLabels[i], 12, 8 + static_cast<int> (i) * settingsRowHeight, 84, 22,
                    juce::Justification::centredLeft);
}

void ProQ3AudioProcessorEditor::AnalyzerPanel::resized()
{
    pre.setBounds (11, 9, 53, 25);
    post.setBounds (70, 9, 53, 25);
    instance.setBounds (131, 9, getWidth() - 142, 25);
    sourceList.setBounds (5, headerHeight, getWidth() - 10, getHeight() - headerHeight - toolsHeight);

    auto rail = getLocalBounds().removeFromBottom (toolsHeight).reduced (10, 7);
    for (auto* control : { &freeze, &grab, &overlaps, &settingsButton })
    {
        control->setBounds (rail.removeFromLeft (39));
        rail.removeFromLeft (6);
    }
    match.setBounds (rail);

    settings.setBounds (getWidth() - 228, getHeight() - toolsHeight - settingsHeight - 2, 215, settingsHeight);
    const std::array<juce::ComboBox*, 5> menus { &range, &resolution, &speed, &tilt, &detail };
    for (size_t i = 0; i < menus.size(); ++i)
        menus[i]->setBounds (94, 8 + static_cast<int> (i) * settingsRowHeight, 109, 22);
    peaks.setBounds (12, 145, 191, 25);
}

int ProQ3AudioProcessorEditor::AnalyzerPanel::preferredHeight() const noexcept
{
    const auto listHeight = rowHeight * juce::jlimit (2, 7, static_cast<int> (sources.size()));
    const auto height = headerHeight + listHeight + toolsHeight;
    return settings.isVisible() ? juce::jmax (height, headerHeight + settingsHeight + toolsHeight + 2) : height;
}

int ProQ3AudioProcessorEditor::AnalyzerPanel::getNumRows()
{
    return static_cast<int> (sources.size());
}

juce::String ProQ3AudioProcessorEditor::AnalyzerPanel::getNameForRow (int row)
{
    return juce::isPositiveAndBelow (row, getNumRows()) ? sources[static_cast<size_t> (row)].name : juce::String();
}

void ProQ3AudioProcessorEditor::AnalyzerPanel::setSources (const std::vector<ProQ3AudioProcessor::SpectrumPeer>& peers)
{
    std::vector<Source> updated;
    updated.reserve (peers.size() + 2);
    const auto addSource = [&] (int id, const juce::String& name)
    {
        const auto existing = std::find_if (sources.begin(), sources.end(), [id] (const auto& source) { return source.id == id; });
        auto row = existing == sources.end() ? Source { id, name } : *existing;
        row.name = name;
        updated.push_back (std::move (row));
    };
    addSource (0, "External Spectrum Off");
    addSource (-1, "Sidechain");
    for (const auto& peer : peers)
        addSource (peer.id, peer.name);

    const juce::ScopedValueSetter<bool> updating (syncingSelection, true);
    sources = std::move (updated);
    sourceList.updateContent();
}

void ProQ3AudioProcessorEditor::AnalyzerPanel::setSelectedSource (int id)
{
    for (size_t i = 0; i < sources.size(); ++i)
    {
        if (sources[i].id != id)
            continue;
        const juce::ScopedValueSetter<bool> updating (syncingSelection, true);
        sourceList.selectRow (static_cast<int> (i), true);
        break;
    }
}

void ProQ3AudioProcessorEditor::AnalyzerPanel::selectedRowsChanged (int row)
{
    if (! syncingSelection && juce::isPositiveAndBelow (row, getNumRows()) && onSourceChanged)
        onSourceChanged (sources[static_cast<size_t> (row)].id);
}

bool ProQ3AudioProcessorEditor::AnalyzerPanel::sourceIsVisible (int row) const
{
    return sourceList.getLocalBounds().intersects (sourceList.getRowPosition (row, true));
}

bool ProQ3AudioProcessorEditor::AnalyzerPanel::hasOpenCombo() const
{
    return speed.isPopupActive() || tilt.isPopupActive() || range.isPopupActive()
        || detail.isPopupActive() || resolution.isPopupActive();
}

void ProQ3AudioProcessorEditor::AnalyzerPanel::paintListBoxItem (int index, juce::Graphics& g,
                                                                  int width, int height, bool selected)
{
    if (! juce::isPositiveAndBelow (index, getNumRows()))
        return;
    const auto& source = sources[static_cast<size_t> (index)];
    const juce::Rectangle<float> row (0.0f, 0.0f, static_cast<float> (width), static_cast<float> (height));
    if (selected)
    {
        g.setColour (juce::Colour (0x72554233));
        g.fillRect (row);
        g.setColour (panelGold);
        g.fillRoundedRectangle (row.reduced (3.0f, 5.0f).withWidth (3.0f), 1.5f);
    }
    else if (index % 2 != 0)
    {
        g.setColour (juce::Colour (0x39201c28));
        g.fillRect (row);
    }

    g.setColour (juce::Colour (0x685f535f));
    g.drawHorizontalLine (height - 1, 3.0f, row.getRight() - 2.0f);
    const auto plot = row.reduced (8.0f, 4.0f).withTrimmedLeft (115.0f);
    if (source.id != 0 && plot.getWidth() > 10.0f)
    {
        const juce::Graphics::ScopedSaveState saved (g);
        g.reduceClipRegion (plot.toNearestInt());
        g.setColour (juce::Colour (0x49695e71));
        for (const double hz : { 50.0, 100.0, 200.0, 500.0, 1000.0, 2000.0, 5000.0, 10000.0, 20000.0 })
        {
            const auto x = plot.getX() + plot.getWidth() * miniSpectrumPosition (hz);
            g.drawVerticalLine (juce::roundToInt (x), plot.getY(), plot.getBottom());
        }

        const auto spacing = plot.getWidth() / static_cast<float> (source.overlap.size() - 1);
        for (size_t i = 0; i < source.overlap.size(); ++i)
        {
            const auto strength = source.overlap[i];
            if (strength < 0.025f)
                continue;
            const auto x = plot.getX() + static_cast<float> (i) * spacing - 0.5f * spacing;
            g.setColour (overlapColour.withAlpha (0.55f * strength));
            g.fillRect (x, plot.getY(), spacing, plot.getHeight());
        }

        if (source.hasTrace)
        {
            juce::Path edge;
            for (size_t i = 0; i < source.levels.size(); ++i)
            {
                const auto x = plot.getX() + plot.getWidth() * static_cast<float> (i) / static_cast<float> (source.levels.size() - 1);
                const auto y = plot.getBottom() - 1.0f - (plot.getHeight() - 2.0f) * source.levels[i];
                if (i == 0) edge.startNewSubPath (x, y);
                else        edge.lineTo (x, y);
            }
            auto area = edge;
            area.lineTo (plot.getBottomRight());
            area.lineTo (plot.getBottomLeft());
            area.closeSubPath();
            const auto trace = selected ? panelGold : juce::Colour (0xffbfb5c8);
            g.setColour (trace.withAlpha (selected ? 0.19f : 0.085f));
            g.fillPath (area);
            g.setColour (trace.withAlpha (selected ? 0.97f : 0.72f));
            g.strokePath (edge, juce::PathStrokeType (1.2f, juce::PathStrokeType::curved));
        }
    }

    g.setColour (selected ? panelGold : panelText);
    g.setFont (juce::FontOptions (12.0f, selected ? juce::Font::bold : juce::Font::plain));
    g.drawFittedText (source.name, 14, 0, source.id == 0 ? width - 28 : 103, height, juce::Justification::centredLeft, 1);
}

void ProQ3AudioProcessorEditor::configureAnalyzerPanel()
{
    addChildComponent (analyzerBackdrop);
    addChildComponent (analyzerPanel);
    analyzerBackdrop.dismiss = [this] { dismissAnalyzerPanel(); };
    auto& panel = analyzerPanel;
    panel.setComponentID ("analyzer-panel");
    panel.onSourceChanged = [this] (int id) { selectAnalyzerSource (id); };
    panel.instance.onTextChange = [this]
    {
        audioProcessor.setSpectrumInstanceAlias (analyzerPanel.instance.getText());
        refreshAnalyzerPanel();
    };

    auto addToggle = [this] (juce::Component& parent, juce::TextButton& button, const char* id)
    {
        parent.addAndMakeVisible (button);
        button.getProperties().set ("spectrumControl", true);
        button.setClickingTogglesState (true);
        button.onClick = [this, &button, id]
        {
            setParameterFromEditor (id, button.getToggleState() ? 1.0f : 0.0f);
            refreshStatusControls();
            repaint (graphBounds);
        };
    };
    addToggle (panel, panel.pre, "analyzer_pre");
    addToggle (panel, panel.post, "analyzer_post");
    addToggle (panel.settings, panel.peaks, "analyzer_peak_alerts");
    for (auto* feed : { &panel.pre, &panel.post })
        feed->getProperties().set ("spectrumFeed", true);
    panel.pre.setTooltip ("Show the spectrum before EQ");
    panel.post.setTooltip ("Show the spectrum after EQ");
    panel.peaks.setTooltip ("Show peak labels after a short hover over the spectrum");

    for (auto* tool : { &panel.freeze, &panel.grab, &panel.overlaps, &panel.settingsButton })
        panel.addAndMakeVisible (*tool);
    panel.freeze.setTooltip ("Freeze the current spectrum traces");
    panel.freeze.onClick = [this] { repaint (graphBounds); };
    panel.grab.setToggleState (true, juce::dontSendNotification);
    panel.grab.setTooltip ("Spectrum Grab. Pause over the spectrum, then drag a held peak. Press Escape to return to the live trace.");
    panel.grab.onClick = [this]
    {
        finishSpectrumGrab();
    };
    panel.overlaps.setTooltip ("Show shared frequency regions for Sidechain and the other tracks");
    panel.overlaps.setToggleState (audioProcessor.apvts.getRawParameterValue ("analyzer_overlap")->load() >= 0.5f,
                                   juce::dontSendNotification);
    panel.overlaps.onClick = [this]
    {
        const bool enabled = analyzerPanel.overlaps.getToggleState();
        setParameterFromEditor ("analyzer_overlap", enabled ? 1.0f : 0.0f);
        lastPreviewRefreshMs = 0.0;
        if (! enabled)
        {
            activeSpectrumOverlap.fill (0.0f);
            for (auto& row : analyzerPanel.sources)
                row.overlap.fill (0.0f);
        }
        analyzerPanel.sourceList.repaint();
        repaint (graphBounds);
    };
    panel.settingsButton.setTooltip ("Analyzer display settings");
    panel.settingsButton.onClick = [this]
    {
        const auto open = analyzerPanel.settingsButton.getToggleState();
        analyzerPanel.settings.setVisible (open);
        if (open)
            analyzerPanel.settings.toFront (false);
        layoutAnalyzerPanel();
    };

    panel.range.addItemList ({ "60 dB", "90 dB", "100 dB", "120 dB" }, 1);
    panel.resolution.addItemList ({ "1024 points", "2048 points", "4096 points", "8192 points" }, 1);
    panel.speed.addItemList ({ "Slow", "Medium", "Fast" }, 1);
    panel.tilt.addItemList ({ "0 dB/oct", "3 dB/oct", "4.5 dB/oct", "6 dB/oct" }, 1);
    panel.detail.addItemList ({ "Smooth", "Balanced", "Detailed" }, 1);
    panel.resolution.setComponentID ("analyzer-resolution");
    panel.range.setTooltip ("Set the spectrum and meter display range");
    panel.resolution.setTooltip ("Use a longer FFT for finer frequency separation");
    panel.speed.setTooltip ("Set how quickly the trace falls after a peak");
    panel.tilt.setTooltip ("Change the visual spectrum weighting across octaves");
    panel.detail.setTooltip ("Adjust smoothing between neighbouring FFT values");
    const std::array settings { std::pair { "analyzer_speed", &panel.speed }, std::pair { "analyzer_tilt", &panel.tilt },
                                std::pair { "analyzer_range", &panel.range }, std::pair { "analyzer_detail", &panel.detail },
                                std::pair { "analyzer_resolution", &panel.resolution } };
    for (size_t i = 0; i < settings.size(); ++i)
    {
        auto& combo = *settings[i].second;
        panel.settings.addAndMakeVisible (combo);
        combo.getProperties().set ("spectrumControl", true);
        combo.onChange = [this]
        {
            lastPreviewRefreshMs = 0.0;
            repaint (graphBounds.getUnion (meterBounds));
        };
        analyzerAttachments[i] = std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment> (
            audioProcessor.apvts, settings[i].first, combo);
    }

    panel.addAndMakeVisible (panel.match);
    panel.match.getProperties().set ("spectrumControl", true);
    panel.match.setTooltip ("Capture input and compare it with an external or saved reference");
    panel.match.onClick = [this] { openMatchPanel(); };
}

void ProQ3AudioProcessorEditor::layoutAnalyzerPanel()
{
    constexpr int width = 304;
    const auto x = juce::jlimit (8, juce::jmax (8, getWidth() - width - 8),
                                analyzerButton.getBounds().getCentreX() - width / 2);
    const auto height = analyzerPanel.preferredHeight();
    analyzerPanel.setBounds (x, bottomBarBounds.getY() - height - 4, width, height);
}

void ProQ3AudioProcessorEditor::showAnalyzerMenu()
{
    if (analyzerPinned)
        dismissAnalyzerPanel();
    else
        openAnalyzerPanel (true);
}

void ProQ3AudioProcessorEditor::openAnalyzerPanel (bool pinned)
{
    if (matchPanel.isVisible())
        closeMatchPanel();
    analyzerPinned = pinned;
    analyzerLastInteraction = juce::Time::getMillisecondCounterHiRes();
    lastAnalyzerRefreshMs = analyzerLastInteraction;
    lastPreviewRefreshMs = 0.0;
    refreshAnalyzerPanel();
    analyzerBackdrop.setVisible (pinned);
    if (pinned)
        analyzerBackdrop.toFront (false);
    analyzerPanel.setVisible (true);
    analyzerButton.setToggleState (true, juce::dontSendNotification);
    analyzerPanel.toFront (false);
}

void ProQ3AudioProcessorEditor::dismissAnalyzerPanel()
{
    analyzerPinned = false;
    analyzerHoverSince = 0.0;
    analyzerHoverSuppressed = analyzerButton.getBounds().contains (getMouseXYRelative());
    analyzerPanel.settingsButton.setToggleState (false, juce::dontSendNotification);
    analyzerPanel.settings.setVisible (false);
    analyzerPanel.setVisible (false);
    analyzerBackdrop.setVisible (false);
    analyzerButton.setToggleState (false, juce::dontSendNotification);
}

void ProQ3AudioProcessorEditor::updateAnalyzerHover (double now)
{
    const auto overButton = analyzerButton.isMouseOver();
    if (! overButton)
    {
        analyzerHoverSince = 0.0;
        analyzerHoverSuppressed = false;
    }
    if (analyzerPinned || ! isShowing() || (spectrumGrabActive && ! analyzerPanel.isVisible()))
        return;

    if (! analyzerPanel.isVisible())
    {
        if (overButton && ! analyzerHoverSuppressed)
        {
            if (analyzerHoverSince <= 0.0)
                analyzerHoverSince = now;
            else if (now - analyzerHoverSince >= 140.0)
                openAnalyzerPanel (false);
        }
        return;
    }

    if (overButton || analyzerPanel.isMouseOver (true) || analyzerPanel.hasOpenCombo() || analyzerPanel.instance.isBeingEdited())
        analyzerLastInteraction = now;
    else if (now - analyzerLastInteraction >= 230.0)
        dismissAnalyzerPanel();
}

void ProQ3AudioProcessorEditor::refreshAnalyzerPanel()
{
    auto& panel = analyzerPanel;
    const auto on = [this] (const char* id)
    {
        return audioProcessor.apvts.getRawParameterValue (id)->load (std::memory_order_relaxed) >= 0.5f;
    };
    for (const auto& control : { std::pair { &panel.pre, "analyzer_pre" }, std::pair { &panel.post, "analyzer_post" },
                                std::pair { &panel.peaks, "analyzer_peak_alerts" } })
        control.first->setToggleState (on (control.second), juce::dontSendNotification);

    panel.overlaps.setToggleState (on ("analyzer_overlap"), juce::dontSendNotification);
    if (! panel.instance.isBeingEdited())
    {
        const auto name = audioProcessor.getSpectrumInstanceName();
        const bool comesFromHost = audioProcessor.hasSpectrumTrackName();
        panel.instance.setEditable (false, ! comesFromHost, false);
        panel.instance.setText (name, juce::dontSendNotification);
        panel.instance.setTooltip (comesFromHost ? "DAW track: " + name : "Double-click to name this instance");
    }
    auto peers = audioProcessor.getSpectrumPeers();
    const bool changed = peers.size() != analyzerPeers.size()
        || ! std::equal (peers.begin(), peers.end(), analyzerPeers.begin(),
                         [] (const auto& a, const auto& b) { return a.id == b.id && a.name == b.name; });
    if (panel.sources.empty() || changed)
    {
        analyzerPeers = std::move (peers);
        panel.setSources (analyzerPeers);
        if (analyzerExternalId > 0 && std::none_of (analyzerPeers.begin(), analyzerPeers.end(),
                                                   [this] (const auto& peer) { return peer.id == analyzerExternalId; }))
        {
            analyzerExternalId = 0;
            externalSpectrumDb.clear();
            activeSpectrumOverlap.fill (0.0f);
            if (selectedMatchSource == 2)
                matchReference = {};
            repaint (graphBounds);
        }
    }
    if (analyzerExternalId <= 0)
        analyzerExternalId = on ("analyzer_sc") ? -1 : 0;
    panel.setSelectedSource (analyzerExternalId);
    layoutAnalyzerPanel();
}

void ProQ3AudioProcessorEditor::selectAnalyzerSource (int sourceId)
{
    if (analyzerExternalId == sourceId)
        return;

    analyzerExternalId = sourceId;
    setParameterFromEditor ("analyzer_sc", sourceId == -1 ? 1.0f : 0.0f);
    externalSpectrumDb.clear();
    activeSpectrumOverlap.fill (0.0f);
    if (selectedMatchSource == 2)
        matchReference = {};
    lastExternalRefreshMs = 0.0;
    lastPreviewRefreshMs = 0.0;
    refreshStatusControls();
    repaint (graphBounds);
}

juce::String ProQ3AudioProcessorEditor::getAnalyzerSourceName() const
{
    if (analyzerExternalId == -1)
        return "Sidechain";
    const auto peer = std::find_if (analyzerPeers.begin(), analyzerPeers.end(),
                                    [this] (const auto& item) { return item.id == analyzerExternalId; });
    return peer == analyzerPeers.end() ? juce::String ("External") : peer->name;
}

void ProQ3AudioProcessorEditor::updateExternalSpectrum (bool frozen)
{
    if (frozen || analyzerExternalId <= 0)
        return;
    const auto now = juce::Time::getMillisecondCounterHiRes();
    if (now - lastExternalRefreshMs < 33.0)
        return;
    lastExternalRefreshMs = now;

    if (! audioProcessor.readPeerSpectrum (analyzerExternalId, externalSpectrumDb, externalSampleRate))
        externalSpectrumDb.clear();
    repaint (graphBounds);
}

double ProQ3AudioProcessorEditor::getAnalyzerTiltChange() const noexcept
{
    constexpr std::array<double, 4> values { -4.5, -1.5, 0.0, 1.5 };
    return values[static_cast<size_t> (juce::jlimit (0, 3, analyzerPanel.tilt.getSelectedId() - 1))];
}

double ProQ3AudioProcessorEditor::analyzerPreviewFrequency (double normalizedPosition)
{
    return previewLowHz * std::pow (previewHighHz / previewLowHz, normalizedPosition);
}

ProQ3AudioProcessorEditor::AnalyzerPreview ProQ3AudioProcessorEditor::sampleAnalyzerProfile (
    const std::vector<float>& spectrum, double rate)
{
    AnalyzerPreview levels;
    levels.fill (-160.0f);
    if (spectrum.size() < 2 || rate <= 0.0)
        return levels;

    const auto lastBin = static_cast<int> (spectrum.size() - 1);
    const auto binWidth = 0.5 * rate / lastBin;
    const auto steps = static_cast<double> (levels.size() - 1);
    const auto windowRatio = std::pow (previewHighHz / previewLowHz, 0.6 / steps);
    for (size_t i = 0; i < levels.size(); ++i)
    {
        const auto hz = analyzerPreviewFrequency (static_cast<double> (i) / steps);
        if (hz > 0.5 * rate)
            break;
        const auto first = juce::jmax (1, static_cast<int> (std::ceil (hz / (windowRatio * binWidth))));
        const auto end = juce::jmin (lastBin, static_cast<int> (std::floor (hz * windowRatio / binWidth)));
        float level = sampleSpectrum (spectrum, hz, rate);
        if (first <= end)
            level = juce::jmax (level, *std::max_element (spectrum.begin() + first, spectrum.begin() + end + 1));
        levels[i] = level - ProQ3AudioProcessor::spectrumTiltDb (hz);
    }
    return levels;
}

ProQ3AudioProcessorEditor::AnalyzerPreview ProQ3AudioProcessorEditor::measureAnalyzerOverlaps (
    const AnalyzerPreview& local, const AnalyzerPreview& reference)
{
    const float localPeak = *std::max_element (local.begin(), local.end());
    const float refPeak = *std::max_element (reference.begin(), reference.end());
    AnalyzerPreview strengths {};
    for (size_t i = 0; i < strengths.size(); ++i)
    {
        const auto audible = juce::jlimit (0.0f, 1.0f, (juce::jmin (local[i], reference[i]) + 67.0f) / 22.0f);
        const auto prominent = juce::jlimit (0.0f, 1.0f,
            (juce::jmin (local[i] - localPeak, reference[i] - refPeak) + 25.0f) / 17.0f);
        const auto balance = juce::jlimit (0.0f, 1.0f, (29.0f - std::abs (local[i] - reference[i])) / 19.0f);
        strengths[i] = audible * prominent * balance;
    }

    // Soften the display horizontally so a single shared FFT peak stays visible at thumbnail size.
    AnalyzerPreview display {};
    for (int i = 0; i < static_cast<int> (display.size()); ++i)
    {
        for (int neighbor = juce::jmax (0, i - 4); neighbor <= juce::jmin (static_cast<int> (display.size()) - 1, i + 4); ++neighbor)
        {
            const auto weight = 1.0f - 0.20f * static_cast<float> (std::abs (neighbor - i));
            auto& value = display[static_cast<size_t> (i)];
            value = juce::jmax (value, strengths[static_cast<size_t> (neighbor)] * weight);
        }
    }
    return display;
}

void ProQ3AudioProcessorEditor::updateSourcePreviews (double now, bool frozen)
{
    const bool panelOpen = analyzerPanel.isVisible();
    const bool overlapOn = audioProcessor.apvts.getRawParameterValue ("analyzer_overlap")->load() >= 0.5f;
    const bool sidechainOn = audioProcessor.apvts.getRawParameterValue ("analyzer_sc")->load() >= 0.5f;
    if (frozen || now - lastPreviewRefreshMs < 85.0
        || (! panelOpen && (! overlapOn || (analyzerExternalId <= 0 && ! sidechainOn))))
        return;

    lastPreviewRefreshMs = now;
    const auto sampleRate = audioProcessor.getCurrentSampleRate();
    const auto tilt = getAnalyzerTiltChange();
    const auto range = static_cast<float> (getSpectrumDisplayRange());
    const auto* local = &smoothedPostSpectrumDb;
    if (audioProcessor.apvts.getRawParameterValue ("analyzer_post")->load() < 0.5f)
        local = audioProcessor.apvts.getRawParameterValue ("analyzer_pre")->load() >= 0.5f ? &smoothedPreSpectrumDb : nullptr;
    const bool compare = overlapOn && local != nullptr && ! local->empty();
    const auto localProfile = compare ? sampleAnalyzerProfile (*local, sampleRate) : AnalyzerPreview {};

    const auto* active = analyzerExternalId > 0 ? &externalSpectrumDb : sidechainOn ? &smoothedSidechainSpectrumDb : nullptr;
    const auto activeRate = analyzerExternalId > 0 ? externalSampleRate : sampleRate;
    const auto activeProfile = active != nullptr ? sampleAnalyzerProfile (*active, activeRate) : AnalyzerPreview {};
    if (compare && active != nullptr)
    {
        activeSpectrumOverlap = measureAnalyzerOverlaps (localProfile, activeProfile);
        repaint (graphBounds);
    }
    else if (std::any_of (activeSpectrumOverlap.begin(), activeSpectrumOverlap.end(), [] (float value) { return value > 0.0f; }))
    {
        activeSpectrumOverlap.fill (0.0f);
        repaint (graphBounds);
    }

    if (! panelOpen)
        return;
    std::vector<float> peerSpectrum;
    for (size_t rowIndex = 1; rowIndex < analyzerPanel.sources.size(); ++rowIndex)
    {
        if (! analyzerPanel.sourceIsVisible (static_cast<int> (rowIndex)))
            continue;

        auto& row = analyzerPanel.sources[rowIndex];
        auto rate = sampleRate;
        const auto* spectrum = &smoothedSidechainSpectrumDb;
        if (row.id > 0)
        {
            if (row.id == analyzerExternalId)
                spectrum = active;
            else
            {
                if (! audioProcessor.readPeerSpectrum (row.id, peerSpectrum, rate))
                    peerSpectrum.clear();
                spectrum = &peerSpectrum;
            }
        }
        row.hasTrace = spectrum != nullptr && spectrum->size() >= 2
            && *std::max_element (spectrum->begin(), spectrum->end()) > -105.0f;
        row.overlap.fill (0.0f);
        if (row.hasTrace)
        {
            const auto profile = spectrum == active ? activeProfile : sampleAnalyzerProfile (*spectrum, rate);
            for (size_t i = 0; i < row.levels.size(); ++i)
            {
                const auto x = static_cast<double> (i) / static_cast<double> (row.levels.size() - 1);
                const auto hz = analyzerPreviewFrequency (x);
                const auto db = profile[i] + ProQ3AudioProcessor::spectrumTiltDb (hz) + static_cast<float> (tilt * std::log2 (hz / 1000.0));
                row.levels[i] = juce::jlimit (0.0f, 1.0f, 1.0f + db / range);
            }
            if (compare)
                row.overlap = measureAnalyzerOverlaps (localProfile, profile);
        }
        analyzerPanel.sourceList.repaintRow (static_cast<int> (rowIndex));
    }
}

ProQ3AudioProcessorEditor::InstanceOverview::InstanceOverview (ProQ3AudioProcessorEditor& owner)
    : editor (owner)
{
    setComponentID ("instance-overview");
    setWantsKeyboardFocus (true);
    search.setComponentID ("instance-search");
    search.setTextToShowWhenEmpty ("Search tracks", panelMuted);
    search.onTextChange = [this] { refresh(); };
    search.onEscapeKey = [this] { editor.setInstanceOverviewOpen (false); };
    addAndMakeVisible (search);
    size.setComponentID ("instance-graph-size");
    size.setTitle ("Graph size");
    size.setTooltip ("Increase or decrease the overview graphs");
    size.setSliderStyle (juce::Slider::LinearHorizontal);
    size.setTextBoxStyle (juce::Slider::NoTextBox, false, 0, 0);
    size.setRange (0.42, 1.0, 0.01);
    size.setValue (0.68, juce::dontSendNotification);
    size.onValueChange = [this]
    {
        rows.setRowHeight (juce::roundToInt (size.getValue() * 202.0));
        rows.repaint();
    };
    addAndMakeVisible (size);
    close.setComponentID ("instance-overview-close");
    close.onClick = [this] { editor.setInstanceOverviewOpen (false); };
    addAndMakeVisible (close);
    rows.setComponentID ("instance-list");
    rows.setModel (this);
    rows.setRowHeight (juce::roundToInt (size.getValue() * 202.0));
    rows.setOutlineThickness (0);
    rows.setColour (juce::ListBox::backgroundColourId, juce::Colours::transparentBlack);
    addAndMakeVisible (rows);
}

ProQ3AudioProcessorEditor::InstanceOverview::~InstanceOverview()
{
    rows.setModel (nullptr);
}

void ProQ3AudioProcessorEditor::InstanceOverview::paint (juce::Graphics& g)
{
    const auto area = getLocalBounds().toFloat();
    g.setColour (juce::Colour (0xff201c25));
    g.fillRoundedRectangle (area, 12.0f);
    g.setColour (juce::Colour (0xff50425a));
    g.drawRoundedRectangle (area.reduced (0.5f), 12.0f, 1.0f);
    g.setFont (juce::FontOptions (20.0f, juce::Font::bold));
    g.setColour (panelText);
    g.drawText ("Track overview", 23, 11, 185, 30, juce::Justification::centredLeft);
    g.setFont (juce::FontOptions (11.0f));
    g.setColour (panelMuted);
    g.drawText ("Graph size", size.getX(), size.getBottom() - 2, size.getWidth(), 15, juce::Justification::centred);
    if (tracks.empty())
        g.drawText ("No tracks match your search", 20, 78, getWidth() - 40, 46, juce::Justification::centred);
}

void ProQ3AudioProcessorEditor::InstanceOverview::resized()
{
    const auto width = getWidth();
    close.setBounds (width - 94, 15, 75, 24);
    search.setBounds (width - 278, 15, 168, 24);
    size.setBounds (width - 442, 13, 140, 20);
    rows.setBounds (16, 59, width - 32, getHeight() - 74);
}

juce::String ProQ3AudioProcessorEditor::InstanceOverview::getNameForRow (int row)
{
    return juce::isPositiveAndBelow (row, getNumRows()) ? tracks[static_cast<size_t> (row)].name : juce::String();
}

int ProQ3AudioProcessorEditor::InstanceOverview::getNumRows()
{
    return static_cast<int> (tracks.size());
}

void ProQ3AudioProcessorEditor::InstanceOverview::refresh()
{
    auto& processor = editor.audioProcessor;
    const auto peers = processor.getSpectrumPeers();
    const auto query = search.getText().trim();
    const auto now = juce::Time::getMillisecondCounterHiRes();
    if (processor.readPostSpectrum (generation, localSpectrum))
        lastLocalSpectrumMs = now;
    if (now - lastLocalSpectrumMs > 280.0)
        localSpectrum.clear();

    const auto localRate = processor.getCurrentSampleRate();
    int referenceId = editor.analyzerExternalId > 0 ? editor.analyzerExternalId : 0;
    auto referenceRate = localRate;
    if (referenceId != 0 && ! processor.readPeerSpectrum (referenceId, externalReference, referenceRate))
        referenceId = 0;
    const auto& reference = referenceId == 0 ? localSpectrum : externalReference;
    const bool showOverlap = ! reference.empty()
        && processor.apvts.getRawParameterValue ("analyzer_overlap")->load() >= 0.5f;
    const auto referenceProfile = showOverlap ? sampleAnalyzerProfile (reference, referenceRate) : AnalyzerPreview {};
    auto previous = std::move (tracks);
    tracks.clear();
    tracks.reserve (peers.size() + 1);
    const auto add = [&] (int id, const juce::String& name)
    {
        if (query.isNotEmpty() && ! name.containsIgnoreCase (query))
            return;
        const auto found = std::find_if (previous.begin(), previous.end(), [id] (const auto& t) { return t.id == id; });
        const auto index = static_cast<int> (tracks.size());
        auto& track = tracks.emplace_back (found == previous.end() ? Track {} : std::move (*found));
        track.id = id;
        track.name = name;
        track.isReference = id == referenceId;
        if (rows.getRowPosition (index, true).intersects (rows.getLocalBounds()) || index == 0)
        {
            processor.readOverviewCurve (id, track.response);
            if (id == 0)
            {
                track.sampleRate = localRate;
                track.spectrum = localSpectrum;
            }
            else if (track.isReference)
            {
                track.sampleRate = referenceRate;
                track.spectrum = externalReference;
            }
            else if (! processor.readPeerSpectrum (id, track.spectrum, track.sampleRate))
                track.spectrum.clear();
            track.overlap = showOverlap && ! track.isReference && ! track.spectrum.empty()
                ? measureAnalyzerOverlaps (referenceProfile, sampleAnalyzerProfile (track.spectrum, track.sampleRate))
                : AnalyzerPreview {};
        }
    };
    add (0, processor.getSpectrumInstanceName());
    for (const auto& peer : peers)
        add (peer.id, peer.name);
    rows.updateContent();
    rows.repaint();
    repaint();
}

void ProQ3AudioProcessorEditor::InstanceOverview::paintListBoxItem (int index, juce::Graphics& g, int width, int height, bool selected)
{
    if (! juce::isPositiveAndBelow (index, getNumRows()))
        return;
    const auto& track = tracks[static_cast<size_t> (index)];
    const juce::Rectangle<int> row (4, 4, width - 8, height - 8);
    g.setColour (juce::Colour (selected ? 0xff383041 : 0xff292330));
    g.fillRoundedRectangle (row.toFloat(), 8.0f);
    auto labels = row.reduced (13, 8).removeFromLeft (133);
    const auto nameBounds = labels.removeFromTop (24);
    g.setColour (track.id == 0 ? juce::Colour (0xff72d6a1) : panelText);
    g.setFont (juce::FontOptions (13.0f, juce::Font::bold));
    g.drawFittedText (track.name, nameBounds, juce::Justification::centredLeft, 1);
    g.setColour (panelMuted);
    g.setFont (juce::FontOptions (10.5f));
    g.drawText (track.isReference ? "Comparison reference" : track.id == 0 ? "This instance" : "Double-click to compare",
                labels.removeFromTop (18), juce::Justification::centredLeft, true);

    const auto available = row.withTrimmedLeft (147).reduced (8, 6);
    const auto plot = available.withWidth (juce::roundToInt (available.getWidth() * size.getValue())).toFloat();
    if (plot.isEmpty())
        return;
    const juce::Graphics::ScopedSaveState state (g);
    g.reduceClipRegion (plot.toNearestInt());
    g.setColour (juce::Colour (0xff1d1923));
    g.fillRect (plot);
    g.setColour (juce::Colour (0xff3c3444));
    for (const auto hz : { 40.0, 80.0, 160.0, 320.0, 640.0, 1250.0, 2500.0, 5000.0, 10000.0 })
    {
        const auto x = plot.getX() + static_cast<float> (std::log (hz / 20.0) / std::log (1000.0)) * plot.getWidth();
        g.drawVerticalLine (juce::roundToInt (x), plot.getY(), plot.getBottom());
    }
    g.drawHorizontalLine (juce::roundToInt (plot.getCentreY()), plot.getX(), plot.getRight());

    const auto steps = static_cast<double> (track.overlap.size() - 1);
    const auto previewX = [&] (double step)
    {
        const auto hz = analyzerPreviewFrequency (step / steps);
        return plot.getX() + plot.getWidth() * static_cast<float> (std::log (hz / 20.0) / std::log (1000.0));
    };
    for (size_t point = 0; point < track.overlap.size(); ++point)
    {
        const auto opacity = track.overlap[point] * 0.26f;
        if (opacity > 0.015f)
        {
            const auto x = previewX (static_cast<double> (point) - 0.5);
            const auto next = previewX (static_cast<double> (point) + 0.5);
            g.setColour (overlapColour.withAlpha (opacity));
            g.fillRect (x, plot.getY(), next - x, plot.getHeight());
        }
    }

    const auto drawLine = [&g] (const juce::Path& path, juce::Colour colour, float thickness)
    {
        g.setColour (colour);
        g.strokePath (path, juce::PathStrokeType (thickness, juce::PathStrokeType::curved));
    };
    if (! track.spectrum.empty())
    {
        juce::Path trace;
        for (int point = 0; point <= 96; ++point)
        {
            const auto portion = static_cast<float> (point) / 96.0f;
            const auto hz = 20.0 * std::pow (1000.0, portion);
            const auto db = sampleSpectrum (track.spectrum, hz, track.sampleRate);
            const auto y = plot.getBottom() - plot.getHeight() * juce::jlimit (0.0f, 1.0f, 1.0f + db / 105.0f);
            const auto x = plot.getX() + portion * plot.getWidth();
            if (point == 0) trace.startNewSubPath (x, y);
            else trace.lineTo (x, y);
        }
        auto fill = trace;
        fill.lineTo (plot.getBottomRight());
        fill.lineTo (plot.getBottomLeft());
        fill.closeSubPath();
        g.setColour (juce::Colour (0x30a2a7bd));
        g.fillPath (fill);
        drawLine (trace, juce::Colour (0x9eb6b7cb), 1.0f);
    }
    const auto& response = track.response;
    using Target = ProQ3AudioProcessor::SignalTarget;
    const auto getSignalColour = [] (Target target)
    {
        switch (target)
        {
            case Target::transient: return juce::Colour (0xff78de8e);
            case Target::tonal: return juce::Colour (0xff65bafb);
            default: return juce::Colour (0xffe2e3e9);
        }
    };
    const auto pointForGain = [&] (size_t point, size_t count, float db)
    {
        const auto portion = static_cast<float> (point) / static_cast<float> (count - 1);
        return juce::Point<float> (plot.getX() + portion * plot.getWidth(),
            plot.getCentreY() - plot.getHeight() * juce::jlimit (-0.48f, 0.48f, db / 30.0f));
    };
    const auto drawEq = [&] (const auto& primary, const auto* side, juce::Colour colour)
    {
        juce::Path curve;
        for (size_t point = 0; point < primary.size(); ++point)
        {
            const auto position = pointForGain (point, primary.size(), primary[point] + (side != nullptr ? (*side)[point] : 0.0f));
            if (point == 0) curve.startNewSubPath (position);
            else curve.lineTo (position);
        }
        drawLine (curve, colour, 1.3f);
    };
    if (response.hasSplit)
    {
        const auto& attacks = response.split[0];
        const auto& sustained = response.split[1];
        const decltype (response.common)* noSide = nullptr;
        drawEq (attacks, noSide, getSignalColour (Target::transient));
        drawEq (sustained, noSide, getSignalColour (Target::tonal));
        juce::Path shared;
        bool previousMatches = false;
        for (size_t point = 0; point < attacks.size(); ++point)
        {
            const bool matches = std::abs (attacks[point] - sustained[point]) < 0.10f;
            if (matches)
            {
                const auto position = pointForGain (point, attacks.size(), 0.5f * (attacks[point] + sustained[point]));
                if (previousMatches) shared.lineTo (position);
                else shared.startNewSubPath (position);
            }
            previousMatches = matches;
        }
        drawLine (shared, getSignalColour (Target::both), 1.4f);
    }
    else
    {
        if (response.hasLeft)
            drawEq (response.common, &response.left, juce::Colour (0xff70da75));
        if (response.hasRight)
            drawEq (response.common, &response.right, juce::Colour (0xffff626b));
        if (! response.hasLeft && ! response.hasRight)
            drawEq (response.common, static_cast<const decltype (response.common)*> (nullptr), panelGold);
    }

    for (size_t i = 0; i < track.response.markerCount; ++i)
    {
        const auto& marker = track.response.markers[i];
        if (marker.frequency < 20.0f || marker.frequency > 20000.0f)
            continue;
        const auto position = static_cast<float> (std::log (marker.frequency / 20.0) / std::log (1000.0));
        const auto x = plot.getX() + plot.getWidth() * position;
        const auto y = plot.getCentreY() - plot.getHeight() * juce::jlimit (-0.48f, 0.48f, marker.gain / 30.0f);
        const auto colour = response.hasSplit ? getSignalColour (marker.signalTarget)
            : juce::Colour (marker.placement == 2 ? 0xffff686b : 0xff83df94);
        const auto radius = size.getValue() >= 0.70 ? 4.2f : 3.0f;
        const auto dot = juce::Rectangle<float> (radius * 2.0f, radius * 2.0f).withCentre ({ x, y });
        g.setColour (colour.withAlpha (0.22f));
        g.fillEllipse (dot.expanded (2.0f));
        g.setColour (colour);
        g.fillEllipse (dot);
        g.setColour (juce::Colour (0xff282334));
        g.drawEllipse (dot, 0.8f);
    }
}

void ProQ3AudioProcessorEditor::InstanceOverview::listBoxItemDoubleClicked (int index, const juce::MouseEvent&)
{
    if (! juce::isPositiveAndBelow (index, getNumRows()))
        return;
    const auto id = tracks[static_cast<size_t> (index)].id;
    editor.setInstanceOverviewOpen (false);
    editor.refreshAnalyzerPanel();
    editor.selectAnalyzerSource (id);
}

void ProQ3AudioProcessorEditor::configureInstanceOverview()
{
    instanceButton.setComponentID ("instance-overview-button");
    instanceButton.getProperties().set ("toolbar", true);
    instanceButton.setTitle ("Track overview");
    instanceButton.setTooltip ("Show the EQ curves and spectra of linked NX Audio tracks");
    instanceButton.onClick = [this] { setInstanceOverviewOpen (true); };
    addAndMakeVisible (instanceButton);
    addChildComponent (instanceOverview);
}

void ProQ3AudioProcessorEditor::setInstanceOverviewOpen (bool open)
{
    if (open)
    {
        finishSpectrumGrab();
        dismissAnalyzerPanel();
        closeMatchPanel();
        outputPanel.setVisible (false);
        instanceOverview.refresh();
        lastOverviewMs = juce::Time::getMillisecondCounterHiRes();
    }
    instanceOverview.setVisible (open);
    if (open)
        instanceOverview.toFront (true);
    repaint();
}

void ProQ3AudioProcessorEditor::updateInstanceOverview (double now)
{
    if (now - lastOverviewMs < 150.0)
        return;
    lastOverviewMs = now;

    auto name = audioProcessor.getSpectrumInstanceName();
    if (name.length() > 18)
        name = name.substring (0, 16) + "...";
    if (instanceButton.getButtonText() != name)
        instanceButton.setButtonText (name);
    if (instanceOverview.isVisible())
        instanceOverview.refresh();
}
