#include "PluginEditor.h"
#include <cmath>

namespace
{
    constexpr int inputReference = 1;
    constexpr int externalReference = 2;
    constexpr int saveReference = 3;
    constexpr int firstSavedReference = 100;
    const juce::Colour referenceColour { 0xffc396e3 };
    const juce::Colour matchColour { 0xfff1bd55 };

    bool hasSpectrumSignal (const std::vector<float>& spectrum)
    {
        return ! spectrum.empty() && *std::max_element (spectrum.begin(), spectrum.end()) > -70.0f;
    }
}

void ProQ3AudioProcessorEditor::MatchPanel::paint (juce::Graphics& g)
{
    const auto frame = getLocalBounds().toFloat().reduced (1.0f);
    juce::ColourGradient glass (juce::Colour (0xd02e273b), frame.getTopLeft(),
                                 juce::Colour (0xd41c1a23), frame.getBottomLeft(), false);
    g.setGradientFill (glass);
    g.fillRoundedRectangle (frame, 10.0f);
    g.setColour (juce::Colour (0xc35c4968));
    g.drawRoundedRectangle (frame, 10.0f, 1.0f);
    g.setColour (matchColour);
    const auto spark = juce::Rectangle<float> (14.0f, 15.0f, 9.0f, 9.0f);
    g.drawEllipse (spark, 1.3f);
    g.drawEllipse (spark.translated (4.0f, 3.0f), 1.3f);
    g.setColour (juce::Colour (0xffede5f1));
    g.setFont (juce::FontOptions (15.0f, juce::Font::bold));
    g.drawText ("EQ Match", 33, 8, 156, 26, juce::Justification::centredLeft);
}

double ProQ3AudioProcessorEditor::spectrumBandPower (const std::vector<float>& spectrum, double centre, double rate)
{
    if (spectrum.size() < 2 || rate <= 0.0)
        return 0.0;

    const auto lastBin = static_cast<int> (spectrum.size() - 1);
    const auto binWidth = 0.5 * rate / lastBin;
    constexpr double halfOctaveWindow = 1.30;
    const auto first = juce::jmax (1, static_cast<int> (std::ceil (centre / (halfOctaveWindow * binWidth))));
    const auto last = juce::jmin (lastBin - 1, static_cast<int> (std::floor (centre * halfOctaveWindow / binWidth)));

    if (last < first)
    {
        const auto level = sampleSpectrum (spectrum, centre, rate) - ProQ3AudioProcessor::spectrumTiltDb (centre);
        return std::pow (10.0, 0.1 * level);
    }

    double power = 0.0;
    for (int bin = first; bin <= last; ++bin)
    {
        const auto frequency = bin * binWidth;
        const auto level = spectrum[static_cast<size_t> (bin)] - ProQ3AudioProcessor::spectrumTiltDb (frequency);
        power += std::pow (10.0, 0.1 * level);
    }
    // A normalized Hann window spreads a centred tone over 1.5 bins of power.
    return power / 1.5;
}

void ProQ3AudioProcessorEditor::configureMatchPanel()
{
    auto& panel = matchPanel;
    panel.setComponentID ("eq-match-panel");
    addChildComponent (panel);
    panel.reference.setComponentID ("match-reference");
    panel.reference.setTextWhenNothingSelected ("Choose a reference");
    panel.reference.setBounds (124, 44, 229, 26);
    panel.reference.onChange = [this]
    {
        const auto source = matchPanel.reference.getSelectedId();
        if (source == saveReference)
        {
            savingMatchReference = true;
            matchPanel.referenceName.setText ("", false);
            refreshMatchControls();
            matchPanel.referenceName.grabKeyboardFocus();
            return;
        }

        selectedMatchSource = source;
        matchReference = {};
        if (source >= firstSavedReference)
        {
            const auto index = static_cast<size_t> (source - firstSavedReference);
            if (index < savedMatchReferences.size())
            {
                matchReference.power = savedMatchReferences[index].power;
                matchReference.frames = 5;
            }
        }
        else if (source == inputReference || source == externalReference)
        {
            matchReference.recording = true;
            if (source == inputReference)
                matchInput.recording = false;
        }
        refreshMatchControls();
    };
    panel.addAndMakeVisible (panel.reference);

    panel.input.onClick = [this]
    {
        matchInput.recording = ! matchInput.recording;
        if (matchInput.recording && selectedMatchSource == inputReference)
            matchReference.recording = false;
        refreshMatchControls();
    };
    panel.resetInput.onClick = [this]
    {
        matchInput = {};
        matchInput.recording = true;
        if (selectedMatchSource == inputReference)
            matchReference.recording = false;
        refreshMatchControls();
        repaint (graphBounds);
    };
    panel.recordReference.onClick = [this]
    {
        matchReference.recording = ! matchReference.recording;
        if (matchReference.recording && selectedMatchSource == inputReference)
            matchInput.recording = false;
        refreshMatchControls();
    };
    panel.preview.onClick = [this] { buildMatchPreview(); };
    panel.finish.onClick = [this] { applyMatchPreview(); };
    panel.close.onClick = [this] { closeMatchPanel(); };
    panel.save.onClick = [this] { saveMatchReference(); };
    panel.back.onClick = [this]
    {
        showingMatchPreview = false;
        savingMatchReference = false;
        refreshMatchReferenceMenu();
        refreshMatchControls();
        repaint (graphBounds);
    };
    panel.input.setBounds (14, 44, 102, 26);
    panel.resetInput.setBounds (14, 80, 102, 26);
    panel.preview.setBounds (266, 80, 87, 26);
    panel.recordReference.setBounds (124, 80, 134, 26);
    panel.back.setBounds (14, 80, 94, 26);
    panel.finish.setBounds (241, 80, 112, 26);
    panel.close.setBounds (297, 9, 56, 23);
    panel.referenceName.setBounds (14, 44, 241, 26);
    panel.save.setBounds (266, 44, 87, 26);

    for (auto* button : { &panel.input, &panel.resetInput, &panel.recordReference, &panel.preview, &panel.finish, &panel.back, &panel.close, &panel.save })
    {
        panel.addAndMakeVisible (*button);
        button->getProperties().set ("spectrumControl", true);
    }
    panel.reference.getProperties().set ("spectrumControl", true);
    panel.referenceName.setTextToShowWhenEmpty ("Name this reference", juce::Colour (0xffb5a9bf));
    panel.referenceName.setInputRestrictions (64);
    panel.referenceName.onReturnKey = [this] { saveMatchReference(); };
    panel.referenceName.onEscapeKey = panel.back.onClick;
    panel.addChildComponent (panel.referenceName);

    panel.bandCount.setComponentID ("match-band-count");
    panel.bandCount.setSliderStyle (juce::Slider::LinearHorizontal);
    panel.bandCount.setTextBoxStyle (juce::Slider::TextBoxRight, false, 39, 22);
    panel.bandCount.setTooltip ("Choose how many bands to preview and apply");
    panel.bandCount.onValueChange = [this] { repaint (graphBounds); };
    panel.bandCount.setBounds (14, 43, 339, 28);
    panel.addChildComponent (panel.bandCount);
    panel.status.setFont (juce::FontOptions (11.5f));
    panel.status.setColour (juce::Label::textColourId, juce::Colour (0xffc9bfce));
    panel.status.setJustificationType (juce::Justification::centredLeft);
    panel.status.setBounds (12, 112, 344, 38);
    panel.status.setInterceptsMouseClicks (false, false);
    panel.addAndMakeVisible (panel.status);
}

void ProQ3AudioProcessorEditor::openMatchPanel()
{
    dismissAnalyzerPanel();
    analyzerPanel.freeze.setToggleState (false, juce::dontSendNotification);
    savedMatchReferences = loadMatchLibrary();
    if (matchExternalId != analyzerExternalId && selectedMatchSource == externalReference)
    {
        matchReference = {};
        if (analyzerExternalId == 0)
            selectedMatchSource = 0;
    }
    matchExternalId = analyzerExternalId;
    showingMatchPreview = false;
    savingMatchReference = false;
    if (! matchInput.ready() && selectedMatchSource != inputReference)
        matchInput.recording = true;
    if ((selectedMatchSource == inputReference || selectedMatchSource == externalReference) && ! matchReference.ready())
        matchReference.recording = true;
    refreshMatchReferenceMenu();
    refreshMatchControls();
    matchPanel.setVisible (true);
    matchPanel.toFront (false);
    repaint (graphBounds);
}

void ProQ3AudioProcessorEditor::closeMatchPanel()
{
    matchInput.recording = false;
    matchReference.recording = false;
    showingMatchPreview = false;
    savingMatchReference = false;
    matchPanel.setVisible (false);
    repaint (graphBounds);
}

void ProQ3AudioProcessorEditor::refreshMatchReferenceMenu()
{
    auto& list = matchPanel.reference;
    list.clear (juce::dontSendNotification);
    list.addItem ("Input (record a reference)", inputReference);
    if (analyzerExternalId != 0)
        list.addItem ("External: " + getAnalyzerSourceName(), externalReference);
    if (! savedMatchReferences.empty())
    {
        list.addSeparator();
        for (size_t i = 0; i < savedMatchReferences.size(); ++i)
            list.addItem (savedMatchReferences[i].name, firstSavedReference + static_cast<int> (i));
    }
    list.addSeparator();
    list.addItem ("Save Input as Reference…", saveReference);
    list.setItemEnabled (saveReference, matchInput.ready());
    list.setSelectedId (selectedMatchSource, juce::dontSendNotification);
}

void ProQ3AudioProcessorEditor::refreshMatchControls()
{
    auto& panel = matchPanel;
    const bool capture = ! showingMatchPreview && ! savingMatchReference;
    const bool recordable = selectedMatchSource == inputReference || selectedMatchSource == externalReference;
    panel.input.setVisible (capture);
    panel.resetInput.setVisible (capture);
    panel.resetInput.setEnabled (matchInput.frames > 0);
    panel.reference.setVisible (capture);
    panel.recordReference.setVisible (capture && recordable);
    panel.preview.setVisible (capture);
    panel.preview.setEnabled (matchInput.ready() && matchReference.ready());
    panel.reference.setItemEnabled (saveReference, matchInput.ready());
    panel.input.setButtonText (matchInput.recording ? "Pause Input" : "Record Input");
    panel.input.setToggleState (matchInput.recording, juce::dontSendNotification);
    panel.recordReference.setButtonText (matchReference.recording ? "Pause Reference" : "Record Reference");
    panel.recordReference.setToggleState (matchReference.recording, juce::dontSendNotification);
    panel.bandCount.setVisible (showingMatchPreview);
    panel.finish.setVisible (showingMatchPreview);
    panel.back.setVisible (! capture);
    panel.referenceName.setVisible (savingMatchReference);
    panel.save.setVisible (savingMatchReference);
    if (savingMatchReference || showingMatchPreview)
        return;

    juce::String status;
    if (matchInput.ready() && matchReference.ready())
        status = "Both spectra ready. Select Match to preview.";
    else if (matchInput.recording && ! matchInput.ready())
        status = "Playing audio builds the input spectrum.";
    else if (matchReference.recording && ! matchReference.ready())
        status = "Play the reference signal to capture its spectrum.";
    else if (matchInput.ready())
        status = "Input ready. Choose or record a reference.";
    else
        status = "Select Record Input and play your audio.";
    if (status != panel.status.getText())
    {
        const auto current = panel.status.getText();
        const bool keepNotice = matchInput.ready() && matchReference.ready() && ! matchInput.recording && ! matchReference.recording
            && (current == "Too little frequency content in common." || current == "All EQ band slots are in use."
                || current == "The spectra already have a similar balance.");
        if (! keepNotice)
            panel.status.setText (status, juce::dontSendNotification);
    }
}

void ProQ3AudioProcessorEditor::updateMatchCapture (const std::vector<float>& spectrum, double sampleRate, bool sidechain)
{
    const auto record = [] (MatchCapture& capture, const std::vector<float>& frame, double rate)
    {
        if (! capture.recording || ! hasSpectrumSignal (frame))
            return;
        const auto count = static_cast<double> (juce::jmin (++capture.frames, 600));
        for (size_t band = 0; band < matchFrequencies.size(); ++band)
        {
            const auto power = spectrumBandPower (frame, matchFrequencies[band], rate);
            capture.power[band] += (power - capture.power[band]) / count;
        }
    };

    if (sidechain)
    {
        if (selectedMatchSource == externalReference && analyzerExternalId == -1)
            record (matchReference, spectrum, sampleRate);
        return;
    }

    record (matchInput, spectrum, sampleRate);
    if (selectedMatchSource == inputReference)
        record (matchReference, spectrum, sampleRate);
    else if (selectedMatchSource == externalReference && analyzerExternalId > 0)
        record (matchReference, externalSpectrumDb, externalSampleRate);
}

void ProQ3AudioProcessorEditor::buildMatchPreview()
{
    if (! matchInput.ready() || ! matchReference.ready())
        return;
    matchInput.recording = false;
    matchReference.recording = false;

    MatchPowers residual {};
    std::array<bool, matchFrequencies.size()> compatible {};
    double average = 0.0;
    int usable = 0;
    for (size_t i = 0; i < residual.size(); ++i)
    {
        if (matchInput.power[i] <= 1.0e-7 || matchReference.power[i] <= 1.0e-7)
            continue;
        compatible[i] = true;
        residual[i] = 10.0 * std::log10 (matchReference.power[i] / matchInput.power[i]);
        average += residual[i];
        ++usable;
    }
    if (usable < 2)
    {
        matchPanel.status.setText ("Too little frequency content in common.", juce::dontSendNotification);
        return;
    }
    average /= usable;
    for (auto& db : residual)
        db -= average;

    matchPreview.clear();
    const auto available = getAvailableBandSlots();

    for (int candidate = 0; candidate < juce::jmin (available, 12); ++candidate)
    {
        size_t index = residual.size();
        double strongest = 1.15;
        for (size_t i = 0; i < residual.size(); ++i)
        {
            if (compatible[i] && std::abs (residual[i]) > strongest)
            {
                strongest = std::abs (residual[i]);
                index = i;
            }
        }
        if (index == residual.size())
            break;

        ProQ3AudioProcessor::BandParameters band;
        band.used = true;
        band.freqHz = matchFrequencies[index];
        band.gainDb = juce::jlimit (-6.0, 6.0, 0.8 * residual[index]);
        band.q = 2.0;
        matchPreview.push_back (band);
        compatible[index] = false;
        const auto response = audioProcessor.makeBandResponse (band);
        for (size_t i = 0; i < residual.size(); ++i)
            residual[i] -= response.magnitudeDbAtFrequency (matchFrequencies[i]);
    }
    if (matchPreview.empty())
    {
        matchPanel.status.setText (available == 0 ? "All EQ band slots are in use." : "The spectra already have a similar balance.",
                                   juce::dontSendNotification);
        return;
    }
    const auto count = static_cast<int> (matchPreview.size());
    matchPanel.bandCount.setRange (1, juce::jmax (2, count), 1);
    matchPanel.bandCount.setEnabled (count > 1);
    matchPanel.bandCount.setValue (juce::jmin (6, count), juce::dontSendNotification);
    showingMatchPreview = true;
    matchPanel.status.setText ("Preview active. Choose the number of bands, then apply.", juce::dontSendNotification);
    refreshMatchControls();
    repaint (graphBounds);
}

void ProQ3AudioProcessorEditor::applyMatchPreview()
{
    if (! showingMatchPreview || matchPreview.empty())
        return;

    audioProcessor.undoManager.beginNewTransaction ("Apply EQ Match");
    const auto count = juce::jmin (static_cast<int> (matchPreview.size()), juce::roundToInt (matchPanel.bandCount.getValue()));
    for (int i = 0; i < count; ++i)
    {
        const auto& band = matchPreview[static_cast<size_t> (i)];
        if (audioProcessor.activateFirstFreeBand (static_cast<float> (band.freqHz), static_cast<float> (band.gainDb),
                                                  static_cast<float> (band.q), band.shape, 0.0f, false) < 0)
            break;
    }
    closeMatchPanel();
}

juce::File ProQ3AudioProcessorEditor::getMatchLibraryFile()
{
    return juce::File::getSpecialLocation (juce::File::userApplicationDataDirectory)
        .getChildFile ("NX Audio").getChildFile ("EQ").getChildFile ("spectrum-references.xml");
}

std::vector<ProQ3AudioProcessorEditor::MatchReference> ProQ3AudioProcessorEditor::loadMatchLibrary()
{
    std::vector<MatchReference> profiles;
    const auto file = getMatchLibraryFile();
    if (! file.existsAsFile() || file.getSize() > 1024 * 1024)
        return profiles;
    const auto document = juce::XmlDocument::parse (file);
    if (document == nullptr || ! document->hasTagName ("FabproSpectrumReferences"))
        return profiles;
    for (auto* element : document->getChildWithTagNameIterator ("Reference"))
    {
        if (profiles.size() == 128)
            break;
        MatchReference reference;
        reference.name = element->getStringAttribute ("name").trim().substring (0, 64);
        bool valid = ! reference.name.isEmpty();
        for (size_t i = 0; i < reference.power.size(); ++i)
        {
            const auto value = element->getDoubleAttribute ("b" + juce::String (static_cast<int> (i)), -1.0);
            valid = valid && std::isfinite (value) && value >= 0.0 && value <= 100.0;
            reference.power[i] = value;
        }
        if (valid)
            profiles.push_back (std::move (reference));
    }
    return profiles;
}

void ProQ3AudioProcessorEditor::saveMatchReference()
{
    const auto name = matchPanel.referenceName.getText().trim().substring (0, 64);
    if (! matchInput.ready() || name.isEmpty())
    {
        matchPanel.status.setText ("Enter a name for the captured input.", juce::dontSendNotification);
        return;
    }
    juce::InterProcessLock lock ("NX-Audio-EQ-Spectrum-References");
    if (! lock.enter (250))
    {
        matchPanel.status.setText ("Reference library is busy. Try again.", juce::dontSendNotification);
        return;
    }

    auto profiles = loadMatchLibrary();
    bool saved = false;
    if (profiles.size() < 128)
    {
        auto uniqueName = name;
        for (int suffix = 2; std::any_of (profiles.begin(), profiles.end(),
                                          [&] (const auto& ref) { return ref.name.equalsIgnoreCase (uniqueName); }); ++suffix)
            uniqueName = name.substring (0, 56) + " (" + juce::String (suffix) + ")";
        profiles.push_back ({ uniqueName, matchInput.power });
        juce::XmlElement document ("FabproSpectrumReferences");
        for (const auto& profile : profiles)
        {
            auto* element = document.createNewChildElement ("Reference");
            element->setAttribute ("name", profile.name);
            for (size_t i = 0; i < profile.power.size(); ++i)
                element->setAttribute ("b" + juce::String (static_cast<int> (i)), profile.power[i]);
        }

        const auto file = getMatchLibraryFile();
        if (file.getParentDirectory().createDirectory().wasOk())
        {
            const juce::TemporaryFile temporary (file);
            saved = document.writeTo (temporary.getFile()) && temporary.overwriteTargetFileWithTemporary();
        }
    }
    lock.exit();

    if (! saved)
    {
        matchPanel.status.setText ("Could not save the reference profile.", juce::dontSendNotification);
        return;
    }
    savedMatchReferences = std::move (profiles);
    selectedMatchSource = firstSavedReference + static_cast<int> (savedMatchReferences.size()) - 1;
    matchReference = { matchInput.power, 5, false };
    savingMatchReference = false;
    refreshMatchReferenceMenu();
    refreshMatchControls();
    repaint (graphBounds);
}

void ProQ3AudioProcessorEditor::drawMatchSpectra (juce::Graphics& g, juce::Rectangle<int> bounds)
{
    if (! matchPanel.isVisible())
        return;
    const juce::Graphics::ScopedSaveState saved (g);
    g.reduceClipRegion (bounds);
    const auto drawProfile = [&] (const MatchCapture& capture, juce::Colour colour, float opacity)
    {
        if (capture.frames == 0)
            return;
        juce::Path line;
        for (size_t i = 0; i < matchFrequencies.size(); ++i)
        {
            const auto frequency = matchFrequencies[i];
            const auto x = frequencyToX (frequency);
            const auto y = analyzerDbToY (10.0 * std::log10 (juce::jmax (1.0e-14, capture.power[i]))
                                          + ProQ3AudioProcessor::spectrumTiltDb (frequency));
            if (i == 0) line.startNewSubPath (x, y);
            else        line.lineTo (x, y);
        }
        auto fill = line;
        fill.lineTo (frequencyToX (matchFrequencies.back()), static_cast<float> (bounds.getBottom()));
        fill.lineTo (frequencyToX (matchFrequencies.front()), static_cast<float> (bounds.getBottom()));
        fill.closeSubPath();
        g.setColour (colour.withAlpha (opacity));
        g.fillPath (fill);
        g.setColour (colour.withAlpha (0.85f));
        g.strokePath (line, juce::PathStrokeType (1.35f, juce::PathStrokeType::curved));
    };
    drawProfile (matchInput, juce::Colour (0xffc4c2ce), 0.07f);
    drawProfile (matchReference, referenceColour, 0.14f);
    if (! showingMatchPreview)
        return;

    const auto count = juce::jmin (matchPreview.size(), static_cast<size_t> (juce::roundToInt (matchPanel.bandCount.getValue())));
    drawCorrectionPreview (g, bounds, matchPreview, count, matchColour);
}

void ProQ3AudioProcessorEditor::drawCorrectionPreview (juce::Graphics& g, juce::Rectangle<int> bounds,
                                                       const std::vector<ProQ3AudioProcessor::BandParameters>& bands,
                                                       size_t count, juce::Colour colour)
{
    const juce::Graphics::ScopedSaveState saved (g);
    g.reduceClipRegion (bounds);

    std::vector<ProQ3AudioProcessor::BandResponse> responses;
    responses.reserve (count);
    for (size_t i = 0; i < count; ++i)
        responses.push_back (audioProcessor.makeBandResponse (bands[i]));
    juce::Path correction;
    for (int x = bounds.getX(); x < bounds.getRight(); x += 3)
    {
        double gain = 0.0;
        const auto frequency = xToFrequency (static_cast<float> (x));
        for (const auto& response : responses)
            gain += response.magnitudeDbAtFrequency (frequency);
        if (x == bounds.getX()) correction.startNewSubPath (static_cast<float> (x), gainDbToY (gain));
        else                   correction.lineTo (static_cast<float> (x), gainDbToY (gain));
    }
    constexpr float dashes[] { 5.0f, 4.0f };
    juce::Path dotted;
    juce::PathStrokeType (1.6f).createDashedStroke (dotted, correction, dashes, 2);
    g.setColour (colour);
    g.fillPath (dotted);
}
