#include "PluginEditor.h"
#include <cmath>
#include <map>

namespace
{
    const juce::Colour kBgDark           { 0xff232328 };
    const juce::Colour kGridLineMajor    { 0xff28282d };
    const juce::Colour kGridLineMinor    { 0xff232327 };
    const juce::Colour kGridZeroLine     { 0xffe5a920 };
    const juce::Colour kTextMuted        { 0xff7e7e86 };
    const juce::Colour kTextBright       { 0xffd8d8dc };
    const juce::Colour kControlAccent    { 0xff7de1d2 };
    const juce::Colour kEqGold           { 0xfff5b82e };
    const juce::Colour kCutGradientTint  { 0xffedb372 };
    const juce::Colour kEqGlow       { 0x20f5b82e };
    const juce::Colour kPanelGreen       { 0xff78de8e };
    const juce::Colour kFloatingBorder   { 0xff4a5c68 };
    const juce::Colour kBypassRed        { 0xffd94343 };
    const juce::Colour kDynRedArc        { 0xffc8282e };
    const juce::Colour kDynYellowLive    { 0xffffc626 };

    juce::Colour getBandColour (int bandIndex, int stereoMode = 0) noexcept
    {
        if (stereoMode == 1) return juce::Colour (0xff70da75);
        if (stereoMode == 2) return juce::Colour (0xffff626b);
        static constexpr std::array<juce::uint32, ProQ3AudioProcessor::kMaxBands> palette {
            0xffff667e, 0xff4aa3ff, 0xff66d936, 0xffc850e8, 0xffff83c1, 0xff55d9d8,
            0xffed9081, 0xff8da5ff, 0xffa5d58f, 0xffdd8dec, 0xff68c7a7, 0xff9bc5ec,
            0xffdd768e, 0xff5da4d5, 0xff8bd9c1, 0xffbba4ed, 0xffe3a0c1, 0xff83d7f1,
            0xfff5a6a0, 0xff7893e1, 0xff7fba91, 0xffca88d4, 0xff55afad, 0xffb2c9eb
        };
        return juce::Colour (palette[static_cast<size_t> (bandIndex)]);
    }

    juce::Colour stereoPlacementColour (int mode) noexcept
    {
        switch (mode)
        {
            case 1: return juce::Colour (0xff70da75);
            case 2: return juce::Colour (0xffff626b);
            case 3: return juce::Colour (0xff62d7b5);
            case 4: return juce::Colour (0xff70bbee);
            default: return kEqGold;
        }
    }

    juce::Colour bandPanelAccent (int stereoMode) noexcept
    {
        return stereoMode == 2 ? stereoPlacementColour (2) : kPanelGreen;
    }

    juce::Path placementGlyph()
    {
        juce::Path rings;
        rings.addEllipse (0.5f, 1.5f, 7.0f, 7.0f);
        rings.addEllipse (4.8f, 1.5f, 7.0f, 7.0f);
        juce::Path glyph;
        juce::PathStrokeType (1.15f).createStrokedPath (glyph, rings);
        glyph.addEllipse (15.2f, 3.5f, 3.1f, 3.1f);
        return glyph;
    }

    std::unique_ptr<juce::DrawablePath> makePlacementIcon (int mode)
    {
        auto icon = std::make_unique<juce::DrawablePath>();
        icon->setPath (placementGlyph());
        icon->setFill (stereoPlacementColour (mode));
        return icon;
    }

    juce::Path filterShapeGlyph (int shape)
    {
        using Filter = ProQ3AudioProcessor;
        juce::Path path;
        switch (shape)
        {
            case Filter::kShapeBell:
                path.startNewSubPath (0.0f, 8.0f);
                path.cubicTo (4.0f, 8.0f, 4.0f, 2.0f, 8.0f, 2.0f);
                path.cubicTo (12.0f, 2.0f, 12.0f, 8.0f, 16.0f, 8.0f);
                break;
            case Filter::kShapeLowShelf:
            case Filter::kShapeHighShelf:
                path.startNewSubPath (0.0f, 3.0f);
                path.lineTo (4.5f, 3.0f);
                path.cubicTo (8.0f, 3.0f, 8.0f, 9.0f, 11.5f, 9.0f);
                path.lineTo (16.0f, 9.0f);
                if (shape == Filter::kShapeHighShelf) path.applyTransform (juce::AffineTransform (-1.0f, 0.0f, 16.0f, 0.0f, 1.0f, 0.0f));
                break;
            case Filter::kShapeLowCut:
            case Filter::kShapeHighCut:
                path.startNewSubPath (0.0f, 11.0f);
                path.cubicTo (5.0f, 9.0f, 5.0f, 3.0f, 10.0f, 3.0f);
                path.lineTo (16.0f, 3.0f);
                if (shape == Filter::kShapeHighCut) path.applyTransform (juce::AffineTransform (-1.0f, 0.0f, 16.0f, 0.0f, 1.0f, 0.0f));
                break;
            case Filter::kShapeNotch:
                path.startNewSubPath (0.0f, 3.0f);
                path.cubicTo (5.0f, 3.0f, 6.5f, 3.0f, 8.0f, 11.0f);
                path.cubicTo (9.5f, 3.0f, 11.0f, 3.0f, 16.0f, 3.0f);
                break;
            case Filter::kShapeBandPass:
                path.startNewSubPath (0.0f, 11.0f);
                path.cubicTo (3.0f, 11.0f, 3.5f, 2.0f, 8.0f, 2.0f);
                path.cubicTo (12.5f, 2.0f, 13.0f, 11.0f, 16.0f, 11.0f);
                break;
            case Filter::kShapeTiltShelf:
                path.startNewSubPath (0.0f, 10.0f);
                path.cubicTo (7.0f, 10.0f, 9.0f, 2.0f, 16.0f, 2.0f);
                break;
            case Filter::kShapeFlatTilt:
                path.startNewSubPath (0.0f, 10.0f);
                path.lineTo (16.0f, 2.0f);
                break;
            default:
                path.startNewSubPath (0.0f, 6.0f);
                path.lineTo (6.0f, 6.0f);
                path.lineTo (9.5f, 1.0f);
                path.lineTo (9.5f, 11.0f);
                path.lineTo (13.0f, 6.0f);
                path.lineTo (16.0f, 6.0f);
                break;
        }
        return path;
    }

    std::unique_ptr<juce::DrawablePath> makeShapeIcon (int shape, juce::Colour colour)
    {
        auto icon = std::make_unique<juce::DrawablePath>();
        icon->setPath (filterShapeGlyph (shape));
        icon->setFill (juce::Colours::transparentBlack);
        icon->setStrokeType (juce::PathStrokeType (1.5f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
        icon->setStrokeFill (colour);
        return icon;
    }

    void drawBandDial (juce::Graphics& g, juce::Point<float> centre, float radius, float angle,
                       juce::Colour accent, bool enabled, bool highlighted)
    {
        const auto face = juce::Rectangle<float> (radius * 2.0f, radius * 2.0f).withCentre (centre);
        g.setColour (juce::Colour (0x922b2932));
        g.fillEllipse (face);
        g.setColour (juce::Colour (0xae100f16));
        g.drawEllipse (face.expanded (1.2f), 1.4f);
        g.setColour (accent.withAlpha (highlighted ? 0.57f : 0.21f));
        g.drawEllipse (face.reduced (0.6f), 1.0f);

        const auto point = centre.getPointOnCircumference (radius - 3.5f, angle);
        const auto inset = centre.getPointOnCircumference (radius - 7.7f, angle);
        g.setColour (accent.withAlpha (enabled ? 0.94f : 0.23f));
        g.drawLine (point.x, point.y, inset.x, inset.y, 1.55f);
    }

    constexpr double kMinFreqHz = 10.0;
    constexpr double kMaxFreqHz = 30000.0;
    constexpr double kPeakHoldMs = 240.0;
    const juce::Identifier spectrumControl { "spectrumControl" };
    const auto kExternalTrace = juce::Colour (0xffba91dc);
    const auto kSpectrumOverlapColour = juce::Colour (0xffee2e41);

    int graphEdgeFilterShape (float x, juce::Rectangle<int> graph) noexcept
    {
        const auto edgeWidth = static_cast<float> (graph.getWidth()) * 0.15f;
        if (x < graph.getX() + edgeWidth)
            return ProQ3AudioProcessor::kShapeLowCut;
        if (x >= graph.getRight() - edgeWidth)
            return ProQ3AudioProcessor::kShapeHighCut;
        return ProQ3AudioProcessor::kShapeBell;
    }

    constexpr float  kRotaryStartAngle = juce::MathConstants<float>::pi * 1.25f;
    constexpr float  kRotaryEndAngle   = juce::MathConstants<float>::pi * 2.75f;
}

float ProQ3AudioProcessorEditor::sampleSpectrum (const std::vector<float>& spectrum, double frequency, double sampleRate)
{
    if (spectrum.size() < 2 || sampleRate <= 0.0 || frequency > sampleRate * 0.5)
        return -160.0f;
    const auto last = static_cast<int> (spectrum.size()) - 1;
    const auto bin = juce::jlimit (0.0, static_cast<double> (last),
                                 frequency * (2.0 * last) / sampleRate);
    const auto low = juce::jmin (last - 1, static_cast<int> (bin));
    const auto a = spectrum[static_cast<size_t> (low)];
    const auto b = spectrum[static_cast<size_t> (low + 1)];
    return a + static_cast<float> (bin - low) * (b - a);
}


//==============================================================================
// LookAndFeel customizado estilo FabFilter Pro-Q 3 (Fiel à imagem de referência)
//==============================================================================
ProQ3LookAndFeel::ProQ3LookAndFeel()
{
    setColour (juce::Slider::textBoxTextColourId, kTextBright);
    setColour (juce::Slider::textBoxOutlineColourId, juce::Colours::transparentBlack);
    setColour (juce::ComboBox::backgroundColourId, juce::Colour (0xff2c2f38));
    setColour (juce::ComboBox::textColourId, kTextBright);
    setColour (juce::ComboBox::outlineColourId, juce::Colour (0xff434754));
    setColour (juce::PopupMenu::backgroundColourId, juce::Colour (0xff1f2229));
    setColour (juce::PopupMenu::textColourId, kTextBright);
    setColour (juce::PopupMenu::highlightedBackgroundColourId, juce::Colour (0xff363c48));
    setColour (juce::TooltipWindow::backgroundColourId, juce::Colour (0xf121242c));
    setColour (juce::TooltipWindow::textColourId, juce::Colour (0xffe4e8e4));
    setColour (juce::TooltipWindow::outlineColourId, juce::Colour (0xff50735d));
}

void ProQ3LookAndFeel::drawRotarySlider (juce::Graphics& g,
                                         int x, int y, int width, int height,
                                         float sliderPos,
                                         float rotaryStartAngle,
                                         float rotaryEndAngle,
                                         juce::Slider& slider)
{
    const auto bounds = juce::Rectangle<int> (x, y, width, height).toFloat().reduced (3.0f);
    const float radius = juce::jmin (bounds.getWidth(), bounds.getHeight()) * 0.5f;
    const auto centre = bounds.getCentre();
    const float rx = centre.x - radius;
    const float ry = centre.y - radius;
    const float rw = radius * 2.0f;
    const float angle = rotaryStartAngle + sliderPos * (rotaryEndAngle - rotaryStartAngle);
    const auto id = slider.getComponentID();
    if (id == "band-frequency" || id == "band-q")
    {
        const auto accent = slider.findColour (juce::Slider::rotarySliderFillColourId);
        drawBandDial (g, centre, radius - 1.0f, angle, accent, slider.isEnabled(), slider.isMouseOverOrDragging());
        if (id == "band-frequency" && slider.isEnabled() && sliderPos > 0.015f)
        {
            juce::Path position;
            position.addCentredArc (centre.x, centre.y, radius - 3.8f, radius - 3.8f,
                                   0.0f, rotaryStartAngle, angle, true);
            g.setColour (accent.withAlpha (slider.isMouseOverOrDragging() ? 0.94f : 0.67f));
            g.strokePath (position, juce::PathStrokeType (1.8f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
        }
        return;
    }

    // Sombra circular externa do knob
    g.setColour (juce::Colour (0xff15161a));
    g.fillEllipse (rx, ry, rw, rw);

    const bool outputKnob = slider.getComponentID() == "output-level";
    const bool outputActive = outputKnob && slider.isMouseOverOrDragging();
    if (outputKnob)
    {
        const auto ringRadius = radius - 0.75f;
        juce::Path rim;
        rim.addCentredArc (centre.x, centre.y, ringRadius, ringRadius, 0.0f, rotaryStartAngle, rotaryEndAngle, true);
        g.setColour (juce::Colour (0xff514859));
        g.strokePath (rim, juce::PathStrokeType (2.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
        if (angle - rotaryStartAngle > 0.01f)
        {
            juce::Path position;
            position.addCentredArc (centre.x, centre.y, ringRadius, ringRadius, 0.0f, rotaryStartAngle, angle, true);
            g.setColour (kEqGold.withAlpha (outputActive ? 0.85f : 0.43f));
            g.strokePath (position, juce::PathStrokeType (1.5f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
        }
    }
    juce::ColourGradient knobGrad (juce::Colour (outputActive ? 0xfff1c765 : 0xff565963), centre.x, ry,
                                   juce::Colour (outputActive ? 0xffad761b : 0xff34373e), centre.x, ry + rw, false);
    g.setGradientFill (knobGrad);
    g.fillEllipse (rx + 2.5f, ry + 2.5f, rw - 5.0f, rw - 5.0f);

    g.setColour (juce::Colour (0xff676b76));
    g.drawEllipse (rx + 2.5f, ry + 2.5f, rw - 5.0f, rw - 5.0f, 1.0f);

    // Chanfro claro em gota ao redor do ponteiro (característico do knob do Pro-Q 3)
    juce::Path capWedge;
    const float capRadius = radius - 3.0f;
    capWedge.addPieSegment (centre.x - capRadius, centre.y - capRadius,
                            capRadius * 2.0f, capRadius * 2.0f,
                            angle - 0.32f, angle + 0.32f, 0.25f);
    g.setColour (slider.isEnabled() ? juce::Colour (0xffeeedeb) : juce::Colour (0xff6d707a));
    g.fillPath (capWedge);

    // Traço escuro central do ponteiro dentro da gota clara
    juce::Path pointerLine;
    pointerLine.addRoundedRectangle (-0.9f, -capRadius + 3.5f, 1.8f, capRadius * 0.42f, 0.8f);
    pointerLine.applyTransform (juce::AffineTransform::rotation (angle).translated (centre.x, centre.y));
    g.setColour (juce::Colour (0xff23252b));
    g.fillPath (pointerLine);

    if (slider.isColourSpecified (juce::Slider::rotarySliderFillColourId) && ! outputKnob)
    {
        juce::Path lit;
        lit.addCentredArc (centre.x, centre.y, radius - 0.7f, radius - 0.7f,
                           0.0f, rotaryStartAngle, angle, true);
        g.setColour (slider.findColour (juce::Slider::rotarySliderFillColourId));
        g.strokePath (lit, juce::PathStrokeType (1.9f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
    }
}

void ProQ3LookAndFeel::drawLinearSlider (juce::Graphics& g, int x, int y, int width, int height,
                                         float position, float minPosition, float maxPosition,
                                         juce::Slider::SliderStyle style, juce::Slider& slider)
{
    if (slider.getComponentID() == "instance-graph-size")
    {
        const auto bounds = juce::Rectangle<float> (static_cast<float> (x), static_cast<float> (y),
                                                     static_cast<float> (width), static_cast<float> (height));
        const auto track = bounds.withSizeKeepingCentre (bounds.getWidth(), 4.0f);
        g.setColour (juce::Colour (0xff52495a));
        g.fillRoundedRectangle (track, 2.0f);
        g.setColour (kEqGold.withAlpha (slider.isMouseOverOrDragging() ? 0.91f : 0.72f));
        g.fillRoundedRectangle (track.withRight (juce::jlimit (track.getX(), track.getRight(), position)), 2.0f);
        g.setColour (kTextBright);
        g.fillEllipse (position - 4.0f, track.getCentreY() - 4.0f, 8.0f, 8.0f);
        return;
    }

    if (slider.getComponentID() == "output-balance")
    {
        const auto cy = static_cast<float> (y) + static_cast<float> (height) * 0.5f;
        const auto left = static_cast<float> (x);
        const auto right = static_cast<float> (x + width);
        const auto middle = (left + right) * 0.5f;
        g.setColour (juce::Colour (0xc6191822));
        g.fillRoundedRectangle (left, cy - 3.5f, static_cast<float> (width), 7.0f, 3.0f);
        g.setColour (juce::Colour (0x997dacbb));
        g.fillRoundedRectangle (juce::jmin (middle, position), cy - 2.0f, std::abs (position - middle), 4.0f, 2.0f);
        g.setColour (juce::Colour (0xffa89fb1));
        g.drawLine (middle, cy - 5.0f, middle, cy + 5.0f, 1.0f);
        g.setColour (slider.isMouseOverOrDragging() ? kControlAccent : kTextBright);
        g.fillEllipse (position - 3.5f, cy - 3.5f, 7.0f, 7.0f);
        return;
    }
    if (slider.getComponentID() != "dynamic-threshold")
    {
        juce::LookAndFeel_V4::drawLinearSlider (g, x, y, width, height, position, minPosition, maxPosition, style, slider);
        return;
    }

    const auto centre = static_cast<float> (x) + static_cast<float> (width) * 0.5f;
    const juce::Rectangle<float> thumb (centre - 9.0f, position - 3.5f, 18.0f, 7.0f);
    g.setColour (slider.isMouseOverOrDragging() ? kEqGold : juce::Colour (0xffdedbea));
    g.fillRoundedRectangle (thumb, 2.5f);
    g.setColour (juce::Colour (0xff1f202a));
    g.drawRoundedRectangle (thumb, 2.5f, 1.0f);
}

void ProQ3LookAndFeel::drawToggleButton (juce::Graphics& g, juce::ToggleButton& button, bool highlighted, bool down)
{
    const auto id = button.getComponentID();
    const bool power = id == "eq-band-power" || id == "eq-dynamics-power";
    if (! power && id != "eq-gain-q")
    {
        juce::LookAndFeel_V4::drawToggleButton (g, button, highlighted, down);
        return;
    }

    const auto bounds = button.getLocalBounds().toFloat().reduced (0.75f);
    if (highlighted || down)
    {
        g.setColour (juce::Colour (down ? 0xff171821 : 0xff3b3845));
        g.fillRoundedRectangle (bounds, 4.0f);
    }
    const auto centre = bounds.getCentre();
    const auto colour = button.getToggleState() ? kControlAccent : kTextMuted;
    g.setColour (button.isEnabled() ? colour : colour.withMultipliedAlpha (0.4f));

    juce::Path symbol;
    if (power)
    {
        symbol.addCentredArc (centre.x, centre.y + 0.5f, 4.3f, 4.3f, 0.0f, 0.67f,
                              juce::MathConstants<float>::twoPi - 0.67f, true);
        symbol.startNewSubPath (centre.x, centre.y - 6.0f);
        symbol.lineTo (centre.x, centre.y - 0.4f);
    }
    else
    {
        symbol.addEllipse (centre.x - 2.0f, centre.y - 2.0f, 4.0f, 4.0f);
        for (int tooth = 0; tooth < 8; ++tooth)
        {
            const auto angle = juce::MathConstants<float>::pi * static_cast<float> (tooth) / 4.0f;
            const juce::Point<float> direction (std::sin (angle), std::cos (angle));
            symbol.startNewSubPath (centre + direction * 3.2f);
            symbol.lineTo (centre + direction * 5.5f);
        }
    }
    g.strokePath (symbol, juce::PathStrokeType (1.25f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
}

void ProQ3LookAndFeel::drawButtonText (juce::Graphics& g, juce::TextButton& button, bool highlighted, bool down)
{
    const auto id = button.getComponentID();
    if (id == "eq-sketch")
    {
        const auto p = button.getLocalBounds().toFloat().getCentre();
        juce::Path nib;
        nib.startNewSubPath (p.x - 5.0f, p.y + 5.0f);
        nib.lineTo (p.x - 4.0f, p.y + 0.9f);
        nib.lineTo (p.x + 2.8f, p.y - 5.5f);
        nib.lineTo (p.x + 5.5f, p.y - 2.8f);
        nib.lineTo (p.x - 1.1f, p.y + 4.2f);
        nib.closeSubPath();
        g.setColour (button.getToggleState() ? kPanelGreen : highlighted ? kEqGold : kTextMuted);
        g.strokePath (nib, juce::PathStrokeType (1.2f, juce::PathStrokeType::curved));
        return;
    }
    if (id == "band-options-shortcut")
    {
        const auto p = button.getLocalBounds().toFloat().getCentre();
        juce::Path chevron;
        chevron.startNewSubPath (p.x - 3.2f, p.y - 1.4f);
        chevron.lineTo (p.x, p.y + 2.0f);
        chevron.lineTo (p.x + 3.2f, p.y - 1.4f);
        g.setColour (highlighted ? kPanelGreen : kTextBright);
        g.strokePath (chevron, juce::PathStrokeType (1.25f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
        return;
    }
    if (id == "instance-overview-button")
    {
        auto area = button.getLocalBounds().reduced (7, 1);
        const auto icon = area.removeFromLeft (17).toFloat().getCentre();
        g.setColour (highlighted ? kPanelGreen : juce::Colour (0xff94c4d4));
        g.drawRoundedRectangle ({ icon.x - 6.0f, icon.y - 5.5f, 10.0f, 7.0f }, 1.5f, 1.0f);
        g.drawRoundedRectangle ({ icon.x - 3.0f, icon.y - 1.5f, 10.0f, 7.0f }, 1.5f, 1.0f);
        g.setColour (kTextBright);
        g.setFont (juce::FontOptions (11.0f));
        g.drawFittedText (button.getButtonText(), area.withTrimmedLeft (3), juce::Justification::centredLeft, 1);
        return;
    }
    if (id != "analyzer-settings")
    {
        juce::LookAndFeel_V4::drawButtonText (g, button, highlighted, down);
        return;
    }

    auto area = button.getLocalBounds().reduced (3, 2);
    const auto prefix = area.removeFromLeft (48);
    g.setFont (juce::FontOptions (11.1f));
    g.setColour (kTextMuted);
    g.drawText ("Analyzer", prefix, juce::Justification::centredLeft);
    const auto capsule = area.reduced (1, 0).toFloat();
    const bool open = button.getToggleState();
    g.setColour (open || highlighted ? juce::Colour (0xbf4a3d50) : juce::Colour (0x88352e3b));
    g.fillRoundedRectangle (capsule, 4.0f);
    g.setColour (open ? kEqGold.withAlpha (0.54f) : juce::Colour (0x995c4c64));
    g.drawRoundedRectangle (capsule.reduced (0.5f), 4.0f, 1.0f);
    g.setColour (open ? kEqGold : kTextBright);
    const auto value = button.getButtonText().fromFirstOccurrenceOf (": ", false, false);
    g.drawFittedText (value, area.reduced (5, 0), juce::Justification::centred, 1);
}

void ProQ3LookAndFeel::drawButtonBackground (juce::Graphics& g,
                                             juce::Button& button,
                                             const juce::Colour& /*backgroundColour*/,
                                             bool isHighlighted,
                                             bool isDown)
{
    auto bounds = button.getLocalBounds().toFloat().reduced (0.5f);
    const bool toggled = button.getToggleState();
    const juce::String txt = button.getButtonText();
    const bool isBypassBtn = (txt == "Bypass");
    const bool isAutoBtn   = (txt == "Auto");

    if (button.getProperties().contains ("toolbar"))
    {
        if (isHighlighted || isDown || button.hasKeyboardFocus (false))
        {
            g.setColour (juce::Colour (isDown ? 0xff302a32 : 0xff2b2630));
            g.fillRoundedRectangle (bounds, 4.0f);
        }
        if (button.getComponentID() == "midi-learn")
        {
            g.setColour (toggled ? kEqGold : kTextMuted.withAlpha (0.65f));
            g.fillEllipse (5.0f, bounds.getCentreY() - 2.0f, 4.0f, 4.0f);
        }
        if (button.getComponentID() == "undo-edit" || button.getComponentID() == "redo-edit")
        {
            const auto centre = bounds.getCentre();
            const float direction = button.getComponentID() == "undo-edit" ? 1.0f : -1.0f;
            const float left = centre.x - 5.0f * direction;
            juce::Path arrow;
            arrow.startNewSubPath (centre.x + 5.0f * direction, centre.y + 2.5f);
            arrow.quadraticTo (centre.x + 4.0f * direction, centre.y - 4.0f, left, centre.y - 0.5f);
            arrow.startNewSubPath (left + 2.5f * direction, centre.y - 4.0f);
            arrow.lineTo (left, centre.y - 0.5f);
            arrow.lineTo (left + 4.0f * direction, centre.y + 1.0f);
            g.setColour (button.isEnabled() ? kTextBright : kTextMuted.withAlpha (0.5f));
            g.strokePath (arrow, juce::PathStrokeType (1.25f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
        }
        if (button.getComponentID() == "expand-editor")
        {
            const auto icon = bounds.withSizeKeepingCentre (11.0f, 11.0f);
            constexpr float arm = 3.6f;
            juce::Path corners;
            for (const float dx : { -1.0f, 1.0f })
            {
                for (const float dy : { -1.0f, 1.0f })
                {
                    const float x = icon.getCentreX() + dx * icon.getWidth() * 0.5f;
                    const float y = icon.getCentreY() + dy * icon.getHeight() * 0.5f;
                    corners.startNewSubPath (x - dx * arm, y);
                    corners.lineTo (x, y);
                    corners.lineTo (x, y - dy * arm);
                }
            }
            g.setColour (kTextBright);
            g.strokePath (corners, juce::PathStrokeType (1.1f));
        }
        return;
    }

    const auto outputId = button.getComponentID();
    if (outputId == "output-polarity" || outputId == "output-auto-gain" || outputId == "output-options")
    {
        const auto accent = outputId == "output-auto-gain" ? kEqGold : kControlAccent;
        g.setColour (toggled ? accent.withAlpha (0.25f) : juce::Colour (isHighlighted || isDown ? 0xb73d3546 : 0x8f292631));
        g.fillRoundedRectangle (bounds, 4.0f);
        g.setColour (toggled ? accent.withAlpha (0.75f) : juce::Colour (0xa16b6074));
        g.drawRoundedRectangle (bounds, 4.0f, 1.0f);
        const auto c = bounds.getCentre();
        g.setColour (toggled ? accent : kTextBright);
        if (outputId == "output-polarity")
        {
            g.drawEllipse (c.x - 4.4f, c.y - 4.4f, 8.8f, 8.8f, 1.3f);
            g.drawLine (c.x - 5.3f, c.y + 5.3f, c.x + 5.3f, c.y - 5.3f, 1.3f);
        }
        else if (outputId == "output-options")
        {
            for (const float dy : { -3.5f, 0.0f, 3.5f })
                g.drawLine (c.x - 5.0f, c.y + dy, c.x + 5.0f, c.y + dy, 1.15f);
        }
        return;
    }

    if (button.getProperties().contains (spectrumControl))
    {
        g.setColour (toggled ? juce::Colour (0xa3483c57)
                             : isDown ? juce::Colour (0xbb1c1922) : juce::Colour (isHighlighted ? 0xb13c3546 : 0x78272131));
        g.fillRoundedRectangle (bounds, 5.0f);
        const auto accent = button.getProperties().contains ("spectrumFeed") ? kEqGold : kExternalTrace;
        g.setColour (toggled ? accent.withAlpha (0.70f) : juce::Colour (0x88534b61));
        g.drawRoundedRectangle (bounds, 5.0f, 1.0f);
        if (toggled)
            g.fillRoundedRectangle (bounds.reduced (4.0f, 6.0f).withWidth (2.0f), 1.0f);
        return;
    }

    juce::Colour bg = juce::Colour (0xff2b2e37);
    if (isAutoBtn)
        bg = toggled ? juce::Colour (0xff2f333e) : juce::Colour (0xff423820);
    else if (toggled)
        bg = isBypassBtn ? juce::Colour (0xff6e2222) : juce::Colour (0xff3c414f);
    else if (isDown)
        bg = juce::Colour (0xff1d2026);
    else if (isHighlighted)
        bg = juce::Colour (0xff353945);

    g.setColour (bg);
    g.fillRoundedRectangle (bounds, 4.0f);

    juce::Colour border = juce::Colour (0xff464b59);
    if (isAutoBtn)
        border = toggled ? juce::Colour (0xff585e70) : kControlAccent;
    else if (toggled)
        border = isBypassBtn ? kBypassRed : kControlAccent;
    else if (isHighlighted)
        border = juce::Colour (0xff646b7e);

    g.setColour (border);
    g.drawRoundedRectangle (bounds, 4.0f, 1.0f);
}

void ProQ3LookAndFeel::drawComboBox (juce::Graphics& g,
                                     int width, int height,
                                     bool /*isButtonDown*/,
                                     int /*buttonX*/, int /*buttonY*/, int /*buttonW*/, int /*buttonH*/,
                                     juce::ComboBox& box)
{
    auto bounds = juce::Rectangle<int> (0, 0, width, height).toFloat().reduced (0.5f);
    const auto id = box.getComponentID();
    const bool shape = id == "band-filter-shape";
    const bool placement = id == "band-stereo-mode";
    if (box.getProperties().contains ("bandPanelControl"))
    {
        g.setColour (juce::Colour (box.isMouseOver() || box.isPopupActive() ? 0xa33b3948 : 0x782c2a35));
        g.fillRoundedRectangle (bounds, 5.0f);
        g.setColour (juce::Colour (0x7b53515e));
        g.drawRoundedRectangle (bounds, 5.0f, 1.0f);
    }
    else if (box.getProperties().contains ("toolbar"))
    {
        if (box.isMouseOver() || box.hasKeyboardFocus (true) || box.isPopupActive())
        {
            g.setColour (juce::Colour (0xff342e38));
            g.fillRoundedRectangle (bounds, 4.0f);
        }
    }
    else
    {
        g.setColour (box.getProperties().contains (spectrumControl)
                        ? juce::Colour (box.isMouseOver() ? 0xb13c3546 : 0x78272131)
                        : juce::Colour (box.isMouseOver() ? 0xff383c47 : 0xff2d3039));
        g.fillRoundedRectangle (bounds, 4.0f);
        g.setColour (juce::Colour (0xff474c5a));
        g.drawRoundedRectangle (bounds, 4.0f, 1.0f);
    }

    if (placement)
    {
        const auto accent = stereoPlacementColour (box.getSelectedId() - 1);
        g.setColour (accent.withAlpha (0.24f));
        g.drawRoundedRectangle (bounds, 5.0f, 1.0f);
        g.setColour (accent);
        g.fillPath (placementGlyph(), juce::AffineTransform::translation (6.0f, bounds.getCentreY() - 5.0f));
    }
    else if (shape)
    {
        const auto glyph = filterShapeGlyph (juce::jmax (0, box.getSelectedItemIndex()));
        g.setColour (box.isEnabled() ? kEqGold : kTextMuted);
        g.strokePath (glyph, juce::PathStrokeType (1.5f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded),
                      juce::AffineTransform::translation (8.0f, bounds.getCentreY() - 6.0f));
    }

    const auto x = static_cast<float> (width) - 10.0f;
    const auto y = bounds.getCentreY();
    const auto direction = shape || placement ? -1.0f : 1.0f;
    juce::Path arrow;
    arrow.startNewSubPath (x - 3.0f, y - direction * 1.5f);
    arrow.lineTo (x, y + direction * 2.0f);
    arrow.lineTo (x + 3.0f, y - direction * 1.5f);
    g.setColour (kTextMuted);
    g.strokePath (arrow, juce::PathStrokeType (1.25f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
}

void ProQ3LookAndFeel::positionComboBoxText (juce::ComboBox& box, juce::Label& label)
{
    const auto id = box.getComponentID();
    if (id == "band-filter-shape")
        label.setBounds (0, 0, 0, 0);
    else if (id == "band-stereo-mode")
    {
        label.setBounds (29, 0, juce::jmax (0, box.getWidth() - 45), box.getHeight());
        label.setFont (getComboBoxFont (box));
    }
    else
        juce::LookAndFeel_V4::positionComboBoxText (box, label);
}

juce::PopupMenu::Options ProQ3LookAndFeel::getOptionsForComboBoxPopupMenu (juce::ComboBox& box, juce::Label& label)
{
    auto options = juce::LookAndFeel_V4::getOptionsForComboBoxPopupMenu (box, label);
    if (box.getComponentID() == "band-filter-shape" || box.getComponentID() == "band-stereo-mode"
        || box.getComponentID() == "output-character")
        options = options.withPreferredPopupDirection (juce::PopupMenu::Options::PopupDirection::upwards)
                         .withParentComponent (box.getParentComponent())
                         .withMinimumWidth (132)
                         .withStandardItemHeight (22);
    return options;
}

void ProQ3LookAndFeel::drawPopupMenuItem (juce::Graphics& g,
                                          const juce::Rectangle<int>& area,
                                          bool isSeparator, bool isActive,
                                          bool isHighlighted, bool isTicked,
                                          bool hasSubMenu,
                                          const juce::String& text,
                                          const juce::String& /*shortcutKeyText*/,
                                          const juce::Drawable* icon,
                                          const juce::Colour* /*textColourToUse*/)
{
    if (isSeparator)
    {
        g.setColour (juce::Colour (0xff323640));
        g.fillRect (area.reduced (6, 0).withHeight (1));
        return;
    }

    if (isHighlighted && isActive)
    {
        g.setColour (juce::Colour (0xff343946));
        g.fillRoundedRectangle (area.reduced (2, 1).toFloat(), 3.0f);
    }

    g.setColour (isTicked ? kControlAccent : (isActive ? kTextBright : kTextMuted));
    g.setFont (juce::FontOptions (13.0f));
    auto textArea = area.reduced (10, 0);
    if (icon != nullptr)
        icon->drawWithin (g, textArea.removeFromLeft (20).toFloat().reduced (2.0f, 5.0f),
                          juce::RectanglePlacement::centred | juce::RectanglePlacement::onlyReduceInSize,
                          isActive ? 1.0f : 0.4f);
    else if (isTicked)
        g.drawText ("v", textArea.removeFromLeft (14), juce::Justification::centredLeft, false);
    if (hasSubMenu)
    {
        const auto arrow = textArea.removeFromRight (12).toFloat().getCentre();
        juce::Path chevron;
        chevron.startNewSubPath (arrow.x - 2.0f, arrow.y - 3.0f);
        chevron.lineTo (arrow.x + 1.5f, arrow.y);
        chevron.lineTo (arrow.x - 2.0f, arrow.y + 3.0f);
        g.strokePath (chevron, juce::PathStrokeType (1.2f));
    }
    g.drawText (text, textArea, juce::Justification::centredLeft, true);
}

//==============================================================================
// Implementação do Knob Concêntrico Duplo GAIN + ANEL DINÂMICO (Fiel à image_435802.png)
//==============================================================================
ConcentricGainDynamicsComponent::ConcentricGainDynamicsComponent()
{
    setRepaintsOnMouseActivity (true);
}

void ConcentricGainDynamicsComponent::bindParameters (juce::RangedAudioParameter* staticGainParam,
                                                      juce::RangedAudioParameter* dynamicRangeParam,
                                                      juce::UndoManager* undoMgr)
{
    gainParam = staticGainParam;
    dynRangeParam = dynamicRangeParam;
    undoManager = undoMgr;
    repaint();
}

void ConcentricGainDynamicsComponent::setLiveDynamicModulationDb (float modDb) noexcept
{
    if (liveDynamicModDb != modDb)
    {
        liveDynamicModDb = modDb;
        repaint();
    }
}

void ConcentricGainDynamicsComponent::setDynamicsActiveAndSupported (bool isSupported, bool isDynBypassed) noexcept
{
    if (shapeSupportsDynamics != isSupported || dynamicsBypassed != isDynBypassed)
    {
        shapeSupportsDynamics = isSupported;
        dynamicsBypassed = isDynBypassed;
        repaint();
    }
}

float ConcentricGainDynamicsComponent::getStaticGainDb() const noexcept
{
    if (gainParam == nullptr) return 0.0f;
    return gainParam->convertFrom0to1 (gainParam->getValue());
}

float ConcentricGainDynamicsComponent::getDynamicRangeDb() const noexcept
{
    if (dynRangeParam == nullptr) return 0.0f;
    return dynRangeParam->convertFrom0to1 (dynRangeParam->getValue());
}

void ConcentricGainDynamicsComponent::setStaticGainDb (float newDb)
{
    if (gainParam == nullptr) return;
    const float clamped = juce::jlimit (-30.0f, 30.0f, newDb);
    gainParam->setValueNotifyingHost (gainParam->convertTo0to1 (clamped));
    repaint();
}

void ConcentricGainDynamicsComponent::setDynamicRangeDb (float newDb)
{
    if (dynRangeParam == nullptr) return;
    const float clamped = juce::jlimit (-30.0f, 30.0f, newDb);
    dynRangeParam->setValueNotifyingHost (dynRangeParam->convertTo0to1 (clamped));
    repaint();
}

bool ConcentricGainDynamicsComponent::hitTestOuterRing (juce::Point<float> pt) const noexcept
{
    const auto centre = getLocalBounds().toFloat().getCentre();
    const float maxR  = juce::jmin (getWidth(), getHeight()) * 0.5f - 2.0f;
    const float innerR = maxR * 0.72f;
    const float dist = pt.getDistanceFrom (centre);
    return (dist >= innerR && dist <= maxR + 4.0f);
}

void ConcentricGainDynamicsComponent::paint (juce::Graphics& g)
{
    const auto bounds = getLocalBounds().toFloat();
    const auto centre = bounds.getCentre();
    const float maxR  = juce::jmin (bounds.getWidth(), bounds.getHeight()) * 0.5f - 3.0f;
    const float ringMidR = maxR - 4.5f;
    const float ringThickness = 7.5f;
    const float innerR = maxR * 0.70f;

    const float staticGainDb = getStaticGainDb();
    const float dynRangeDb   = getDynamicRangeDb();
    const float zeroAngle    = kRotaryStartAngle + 0.5f * (kRotaryEndAngle - kRotaryStartAngle);

    auto dbToAngle = [] (float db) noexcept
    {
        const float norm = juce::jlimit (0.0f, 1.0f, (db + 30.0f) / 60.0f);
        return kRotaryStartAngle + norm * (kRotaryEndAngle - kRotaryStartAngle);
    };

    const float gainAngle = dbToAngle (staticGainDb);
    const float dynTargetDb = juce::jlimit (-30.0f, 30.0f, staticGainDb + dynRangeDb);
    const float dynAngle = dbToAngle (dynTargetDb);

    // 1. Trilha escura do anel externo de faixa dinâmica (Dynamic Range Ring)
    juce::Path outerTrack;
    outerTrack.addCentredArc (centre.x, centre.y, ringMidR, ringMidR,
                              0.0f, kRotaryStartAngle, kRotaryEndAngle, true);
    g.setColour (juce::Colour (0x9b14161b));
    g.strokePath (outerTrack, juce::PathStrokeType (ringThickness + 2.0f, juce::PathStrokeType::curved, juce::PathStrokeType::butt));

    // Halo bordô sutil na metade direita do anel como na imagem image_435802.png
    juce::Path rightHaloArc;
    rightHaloArc.addCentredArc (centre.x, centre.y, ringMidR, ringMidR,
                                0.0f, zeroAngle, kRotaryEndAngle, true);
    g.setColour (juce::Colour (0x38982832));
    g.strokePath (rightHaloArc, juce::PathStrokeType (ringThickness, juce::PathStrokeType::curved, juce::PathStrokeType::butt));

    // 2. Arco da Faixa Dinâmica Configurada (vermelho/coral como na imagem image_435802.png)
    if (std::abs (dynRangeDb) > 0.05f)
    {
        juce::Path configuredDynArc;
        configuredDynArc.addCentredArc (centre.x, centre.y, ringMidR, ringMidR,
                                        0.0f, gainAngle, dynAngle, true);

        const float alpha = (shapeSupportsDynamics && ! dynamicsBypassed) ? 0.92f : 0.35f;
        g.setColour (kDynRedArc.withAlpha (alpha));
        g.strokePath (configuredDynArc, juce::PathStrokeType (ringThickness, juce::PathStrokeType::curved, juce::PathStrokeType::butt));

        // Traço fino branco/claro no limite da faixa dinâmica configurada (exatamente como na imagem)
        juce::Path tickMark;
        tickMark.addRoundedRectangle (-0.9f, -ringMidR - ringThickness * 0.5f, 1.8f, ringThickness + 1.0f, 0.5f);
        tickMark.applyTransform (juce::AffineTransform::rotation (dynAngle).translated (centre.x, centre.y));
        g.setColour (juce::Colours::white.withAlpha (alpha));
        g.fillPath (tickMark);
    }

    // 3. Barra Amarela em Tempo Real (Live Dynamic Gain Change inside the ring, Manual p. 13:
    // "The current dynamic gain change is shown as a yellow bar inside the ring, on top of the dynamic range")
    if (shapeSupportsDynamics && ! dynamicsBypassed && std::abs (liveDynamicModDb) > 0.03f)
    {
        const float liveTargetDb = juce::jlimit (-30.0f, 30.0f, staticGainDb + liveDynamicModDb);
        const float liveAngle = dbToAngle (liveTargetDb);

        juce::Path liveYellowArc;
        liveYellowArc.addCentredArc (centre.x, centre.y, ringMidR, ringMidR,
                                     0.0f, gainAngle, liveAngle, true);
        g.setColour (kDynYellowLive);
        g.strokePath (liveYellowArc, juce::PathStrokeType (ringThickness, juce::PathStrokeType::curved, juce::PathStrokeType::butt));
    }
    else if (std::abs (staticGainDb) > 0.05f)
    {
        // Arco amarelo do ganho estático do centro (0 dB) até o ponteiro do knob
        juce::Path staticArc;
        staticArc.addCentredArc (centre.x, centre.y, ringMidR, ringMidR,
                                 0.0f, zeroAngle, gainAngle, true);
        g.setColour (kDynYellowLive.withAlpha (0.90f));
        g.strokePath (staticArc, juce::PathStrokeType (ringThickness, juce::PathStrokeType::curved, juce::PathStrokeType::butt));
    }

    // Realce de hover no anel dinâmico externo
    if (hoveringRing || draggingOuterRing)
    {
        g.setColour (kControlAccent.withAlpha (0.45f));
        g.drawEllipse (centre.x - maxR, centre.y - maxR, maxR * 2.0f, maxR * 2.0f, 1.3f);
    }

    const auto accent = isColourSpecified (juce::Slider::rotarySliderFillColourId)
        ? findColour (juce::Slider::rotarySliderFillColourId) : kPanelGreen;
    drawBandDial (g, centre, innerR, gainAngle, accent, isEnabled(), hoveringInner || draggingInnerKnob);
}

void ConcentricGainDynamicsComponent::mouseMove (const juce::MouseEvent& e)
{
    const bool onRing = hitTestOuterRing (e.position);
    const bool onInner = ! onRing && (e.position.getDistanceFrom (getLocalBounds().toFloat().getCentre()) < juce::jmin (getWidth(), getHeight()) * 0.36f);

    if (onRing != hoveringRing || onInner != hoveringInner)
    {
        hoveringRing = onRing;
        hoveringInner = onInner;
        repaint();
    }
}

void ConcentricGainDynamicsComponent::mouseExit (const juce::MouseEvent&)
{
    hoveringRing = false;
    hoveringInner = false;
    repaint();
}

void ConcentricGainDynamicsComponent::mouseDown (const juce::MouseEvent& e)
{
    dragStartY = e.position.y;

    if (hitTestOuterRing (e.position) || e.mods.isAltDown())
    {
        draggingOuterRing = true;
        draggingInnerKnob = false;
        dragStartValueDb  = getDynamicRangeDb();
        if (undoManager != nullptr)
            undoManager->beginNewTransaction ("Adjust Dynamic Range Ring");
    }
    else
    {
        draggingInnerKnob = true;
        draggingOuterRing = false;
        dragStartValueDb  = getStaticGainDb();
        if (undoManager != nullptr)
            undoManager->beginNewTransaction ("Adjust Static Gain Knob");
    }
    repaint();
}

void ConcentricGainDynamicsComponent::mouseDrag (const juce::MouseEvent& e)
{
    const float sensitivity = e.mods.isShiftDown() ? 0.08f : 0.38f;
    const float deltaDb = (dragStartY - e.position.y) * sensitivity;

    if (draggingOuterRing)
    {
        setDynamicRangeDb (dragStartValueDb + deltaDb);
    }
    else if (draggingInnerKnob)
    {
        setStaticGainDb (dragStartValueDb + deltaDb);
    }
}

void ConcentricGainDynamicsComponent::mouseUp (const juce::MouseEvent&)
{
    draggingOuterRing = false;
    draggingInnerKnob = false;
    repaint();
}

void ConcentricGainDynamicsComponent::mouseDoubleClick (const juce::MouseEvent& e)
{
    if (hitTestOuterRing (e.position))
    {
        if (undoManager != nullptr)
            undoManager->beginNewTransaction ("Reset Dynamic Range");
        setDynamicRangeDb (0.0f);
    }
    else
    {
        if (undoManager != nullptr)
            undoManager->beginNewTransaction ("Reset Static Gain");
        setStaticGainDb (0.0f);
    }
}

void ConcentricGainDynamicsComponent::mouseWheelMove (const juce::MouseEvent& e, const juce::MouseWheelDetails& wheel)
{
    const float step = (e.mods.isShiftDown() ? 0.25f : 1.0f) * wheel.deltaY * 5.0f;
    if (hitTestOuterRing (e.position) || e.mods.isAltDown())
        setDynamicRangeDb (getDynamicRangeDb() + step);
    else
        setStaticGainDb (getStaticGainDb() + step);
}

//==============================================================================
// Parser de Frequência e Notas Musicais ("2k", "A4", "C#3 + 13", "50%", Manual p. 6 & p. 18)
//==============================================================================
double ProQ3AudioProcessorEditor::parseFrequencyTextInput (const juce::String& text, double currentFreqHz) noexcept
{
    juce::String s = text.trim();
    if (s.isEmpty())
        return currentFreqHz;

    // Porcentagem ("50%" -> posição central logarítmica = ~547.7 Hz)
    if (s.endsWithChar ('%'))
    {
        const double pct = juce::jlimit (0.0, 100.0, s.dropLastCharacters (1).getDoubleValue()) * 0.01;
        return kMinFreqHz * std::pow (kMaxFreqHz / kMinFreqHz, pct);
    }

    // Multiplicador "k" ou "kHz" (ex: "2k" -> 2000 Hz, "6.5k" -> 6500 Hz)
    const juce::String lower = s.toLowerCase();
    if (lower.contains ("k"))
    {
        const double val = lower.upToFirstOccurrenceOf ("k", false, false).trim().getDoubleValue();
        if (val > 0.0)
            return juce::jlimit (kMinFreqHz, kMaxFreqHz, val * 1000.0);
    }

    // Nota musical (ex: "A4" -> 440 Hz, "C#3 + 13", "Bb2")
    const juce::juce_wchar firstChar = s[0];
    if ((firstChar >= 'A' && firstChar <= 'G') || (firstChar >= 'a' && firstChar <= 'g'))
    {
        int semitoneFromC = 0;
        switch (juce::CharacterFunctions::toUpperCase (firstChar))
        {
            case 'C': semitoneFromC = 0; break;
            case 'D': semitoneFromC = 2; break;
            case 'E': semitoneFromC = 4; break;
            case 'F': semitoneFromC = 5; break;
            case 'G': semitoneFromC = 7; break;
            case 'A': semitoneFromC = 9; break;
            case 'B': semitoneFromC = 11; break;
            default: break;
        }

        int pos = 1;
        if (pos < s.length())
        {
            if (s[pos] == '#') { semitoneFromC += 1; ++pos; }
            else if (s[pos] == 'b') { semitoneFromC -= 1; ++pos; }
        }

        juce::String rest = s.substring (pos).trim();
        int octave = 4;
        double centsOffset = 0.0;

        int signPos = rest.indexOfAnyOf ("+-", 1);
        if (signPos > 0)
        {
            octave = rest.substring (0, signPos).trim().getIntValue();
            centsOffset = rest.substring (signPos).removeCharacters (" ").getDoubleValue();
        }
        else if (rest.isNotEmpty())
        {
            octave = rest.getIntValue();
        }

        const double midiNote = static_cast<double> ((octave + 1) * 12 + semitoneFromC) + (centsOffset / 100.0);
        const double freq = 440.0 * std::pow (2.0, (midiNote - 69.0) / 12.0);
        return juce::jlimit (kMinFreqHz, kMaxFreqHz, freq);
    }

    const double numericVal = s.getDoubleValue();
    if (numericVal > 0.0)
        return juce::jlimit (kMinFreqHz, kMaxFreqHz, numericVal);

    return currentFreqHz;
}

//==============================================================================
// Editor Principal do FabFilter Pro-Q 3
//==============================================================================
ProQ3AudioProcessorEditor::ProQ3AudioProcessorEditor (ProQ3AudioProcessor& p)
    : AudioProcessorEditor (&p), audioProcessor (p)
{
    setLookAndFeel (&lookAndFeel);
    setWantsKeyboardFocus (true);

    setResizable (true, true);
    setResizeLimits (780, 460, 2560, 1440);

    //---- Top Bar Buttons ----
    for (auto* button : { &undoButton, &redoButton, &abButton, &copyButton, &prevPresetButton,
                          &presetNameButton, &nextPresetButton, &helpButton, &expandButton })
    {
        button->getProperties().set ("toolbar", true);
        button->setColour (juce::TextButton::textColourOffId, kTextBright);
    }
    addAndMakeVisible (undoButton);
    undoButton.onClick = [this] { audioProcessor.undoManager.undo(); refreshFactoryPresetName(); repaint(); };

    addAndMakeVisible (redoButton);
    redoButton.onClick = [this] { audioProcessor.undoManager.redo(); refreshFactoryPresetName(); repaint(); };

    addAndMakeVisible (abButton);
    abButton.onClick = [this]
    {
        audioProcessor.toggleABState();
        refreshFactoryPresetName();
        abButton.setButtonText (audioProcessor.isStateBActive() ? "B/A" : "A/B");
        attachFloatingControlsToBand (audioProcessor.getSelectedBandIndex());
        repaint();
    };

    addAndMakeVisible (copyButton);
    copyButton.onClick = [this] { audioProcessor.copyActiveToInactiveState(); };

    addAndMakeVisible (prevPresetButton);
    prevPresetButton.onClick = [this] { stepFactoryPreset (-1); };

    addAndMakeVisible (presetNameButton);
    presetNameButton.onClick = [this] { showFactoryPresetMenu(); };
    refreshFactoryPresetName();

    addAndMakeVisible (nextPresetButton);
    nextPresetButton.onClick = [this] { stepFactoryPreset (1); };

    addAndMakeVisible (helpButton);
    helpButton.setClickingTogglesState (true);
    helpButton.setTooltip ("Show interaction help");
    helpButton.onClick = [this] { showHelpOverlay = helpButton.getToggleState(); repaint(); };
    undoButton.setComponentID ("undo-edit");
    undoButton.setTitle ("Undo");
    undoButton.setButtonText ({});
    undoButton.setTooltip ("Undo the last edit");
    redoButton.setComponentID ("redo-edit");
    redoButton.setTitle ("Redo");
    redoButton.setButtonText ({});
    redoButton.setTooltip ("Redo the last undone edit");
    prevPresetButton.setTooltip ("Previous preset");
    nextPresetButton.setTooltip ("Next preset");
    abButton.setTooltip ("Switch between A and B settings");
    copyButton.setTooltip ("Copy the active settings to the other slot");

    addAndMakeVisible (expandButton);
    expandButton.setComponentID ("expand-editor");
    expandButton.setTitle ("Expand editor");
    expandButton.setTooltip ("Expand editor");
    expandButton.onClick = [this] { toggleExpandedView(); };

    //---- Floating Band Controls Pill (Fiel à imagem image_435802.png) ----
    addAndMakeVisible (bandBypassButton);
    bandBypassButton.setComponentID ("eq-band-power");
    bandBypassButton.setTitle ("Band Power");
    bandBypassButton.setTooltip ("Enable / Bypass Selected EQ Band (Alt+Click band dot)");

    bandShapeBox.setComponentID ("band-filter-shape");
    addAndMakeVisible (bandShapeBox);
    bandShapeBox.setTitle ("Filter shape");
    bandShapeBox.setTooltip ("Choose the filter shape. Bell affects a region around the center frequency. Shelves adjust one side, cuts remove one side, and All Pass changes phase without changing magnitude.");
    bandShapeBox.getProperties().set ("bandPanelControl", true);
    auto filterShapes = audioProcessor.apvts.getParameter ("band01_shape")->getAllValueStrings();
    filterShapes.add ("All Pass");
    for (int i = 0; i < filterShapes.size(); ++i)
        bandShapeBox.getRootMenu()->addItem (i + 1, filterShapes[i], true, false, makeShapeIcon (i, kEqGold));
    bandShapeBox.onChange = [this]
    {
        const auto shape = bandShapeBox.getSelectedItemIndex();
        const auto band = audioProcessor.getBandParameters (attachedBandIndex);
        if (band.used && shape >= 0 && shape != band.shape)
            applyBandOption (attachedBandIndex, 100 + shape);
    };

    addAndMakeVisible (bandSlopeBox);
    bandSlopeBox.getProperties().set ("bandPanelControl", true);
    bandSlopeBox.setTooltip ("Choose the filter slope in dB per octave.");
    bandSlopeBox.addItemList ({
        "6 dB/oct", "12 dB/oct", "18 dB/oct", "24 dB/oct",
        "30 dB/oct", "36 dB/oct", "48 dB/oct", "72 dB/oct",
        "96 dB/oct", "Brickwall"
    }, 1);

    // Knob FREQ (com suporte a atalhos "2k", "A4", "C#3")
    freqSlider.setComponentID ("band-frequency");
    freqSlider.setTooltip ("Adjust the center frequency. Double-click FREQ to enter a value in Hz or a note such as A4.");
    freqSlider.setSliderStyle (juce::Slider::RotaryHorizontalVerticalDrag);
    freqSlider.setTextBoxStyle (juce::Slider::NoTextBox, false, 0, 0);
    freqSlider.setVelocityBasedMode (true);
    freqSlider.setDoubleClickReturnValue (true, 1000.0);
    addAndMakeVisible (freqSlider);

    // Knob Central Concêntrico GAIN + Anel Dinâmico Independente
    concentricGainKnob.setTitle ("Band gain and dynamic range");
    concentricGainKnob.setTooltip ("Drag the center to change gain. Drag the outer ring to set the amount of dynamic gain change.");
    addAndMakeVisible (concentricGainKnob);

    spectralButton.setComponentID ("band-spectral");
    spectralButton.setTitle ("Spectral dynamics");
    spectralButton.setTooltip ("Switch this band between broadband and spectral dynamics.");
    spectralButton.onClick = [this] { applyBandOption (attachedBandIndex, 7); };
    addChildComponent (spectralButton);

    spectralTiltButton.setComponentID ("band-spectral-tilt");
    spectralTiltButton.setTooltip ("Tilt the spectral detector by 3 dB per octave toward high frequencies.");
    spectralTiltButton.setClickingTogglesState (true);
    addChildComponent (spectralTiltButton);

    spectralDensitySlider.setComponentID ("band-spectral-density");
    spectralDensitySlider.setTitle ("Spectral density");
    spectralDensitySlider.setTooltip ("Increase spectral density to narrow the affected frequency regions.");
    spectralDensitySlider.setSliderStyle (juce::Slider::LinearHorizontal);
    spectralDensitySlider.setTextBoxStyle (juce::Slider::NoTextBox, false, 0, 0);
    addChildComponent (spectralDensitySlider);

    // Knob Q
    qSlider.setComponentID ("band-q");
    qSlider.setTooltip ("Adjust bandwidth. Higher Q narrows the affected frequency range.");
    qSlider.setSliderStyle (juce::Slider::RotaryHorizontalVerticalDrag);
    qSlider.setTextBoxStyle (juce::Slider::NoTextBox, false, 0, 0);
    qSlider.setVelocityBasedMode (true);
    qSlider.setDoubleClickReturnValue (true, 1.0);
    addAndMakeVisible (qSlider);

    gainQInterButton.setComponentID ("eq-gain-q");
    gainQInterButton.setTitle ("Gain-Q Interaction");
    addAndMakeVisible (gainQInterButton);
    gainQInterButton.setTooltip ("Gain-Q Interaction");

    // Botões do Arco Dinâmico acima do Knob GAIN (como na imagem image_435802.png):
    juce::Path dynamicsIcon;
    dynamicsIcon.startNewSubPath (0.0f, 7.0f);
    dynamicsIcon.lineTo (3.5f, 7.0f);
    dynamicsIcon.lineTo (6.0f, 2.0f);
    dynamicsIcon.lineTo (9.0f, 12.0f);
    dynamicsIcon.lineTo (11.5f, 7.0f);
    dynamicsIcon.lineTo (15.0f, 7.0f);
    juce::DrawablePath normalIcon, hoveredIcon;
    for (auto* icon : { &normalIcon, &hoveredIcon })
    {
        icon->setPath (dynamicsIcon);
        icon->setFill (juce::Colours::transparentBlack);
        icon->setStrokeType (juce::PathStrokeType (1.35f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
    }
    normalIcon.setStrokeFill (kTextBright);
    hoveredIcon.setStrokeFill (kEqGold);
    bandDynamicsShortcut.setImages (&normalIcon, &hoveredIcon, &hoveredIcon);
    bandDynamicsShortcut.setEdgeIndent (3);
    bandDynamicsShortcut.setComponentID ("band-open-dynamics");
    bandDynamicsShortcut.setTooltip ("Open Dynamic EQ controls for this band");
    bandDynamicsShortcut.onClick = [this]
    {
        const auto band = hoveredBandIndex;
        const auto bp = audioProcessor.getBandParameters (band);
        if (! bp.used || ! ProQ3AudioProcessor::doesShapeSupportDynamics (bp.shape))
            return;
        attachFloatingControlsToBand (band);
        expandedDynamicsBand = band;
        updateFloatingControlsVisibilityAndValues();
        repaint (graphBounds);
    };
    bandDynamicsShortcut.addMouseListener (this, false);
    addChildComponent (bandDynamicsShortcut);
    bandShapeShortcut.setComponentID ("band-shape-shortcut");
    bandShapeShortcut.setTooltip ("Choose the filter shape. Bell adjusts a region around the center, Shelf and Cut affect one side, and All Pass changes phase without changing magnitude.");
    bandShapeShortcut.setEdgeIndent (3);
    bandShapeShortcut.onClick = [this]
    {
        shapeQuickBand = shapeQuickBand == hoveredBandIndex ? -1 : hoveredBandIndex;
        updateBandShortcuts();
        repaint (graphBounds);
    };
    shapeQuickRail.setComponentID ("band-shape-rail");
    addChildComponent (shapeQuickRail);
    for (int i = 0; i < filterShapes.size(); ++i)
    {
        auto button = std::make_unique<juce::DrawableButton> (filterShapes[i], juce::DrawableButton::ImageOnButtonBackground);
        button->setTooltip (filterShapes[i]);
        button->setEdgeIndent (5);
        const auto normal = makeShapeIcon (i, kTextMuted);
        const auto selected = makeShapeIcon (i, kEqGold);
        button->setImages (normal.get(), selected.get(), selected.get(), nullptr, selected.get());
        button->onClick = [this, i]
        {
            const auto band = shapeQuickBand;
            shapeQuickBand = -1;
            applyBandOption (band, i + 100);
        };
        shapeQuickRail.addAndMakeVisible (*button);
        shapeQuickButtons[static_cast<size_t> (i)] = std::move (button);
    }
    bandOptionsShortcut.setComponentID ("band-options-shortcut");
    bandOptionsShortcut.setTitle ("Band options");
    bandOptionsShortcut.setTooltip ("Open band options to change shape, slope or stereo placement, make the band dynamic or spectral, or cut, copy, paste, split or delete it.");
    bandOptionsShortcut.onClick = [this] { showBandOptions (hoveredBandIndex, &bandOptionsShortcut); };
    bandPowerShortcut.setComponentID ("eq-band-power");
    bandPowerShortcut.setTitle ("Band power");
    bandPowerShortcut.setTooltip ("Enable or disable this band");
    bandPowerShortcut.onClick = [this] { applyBandOption (hoveredBandIndex, 1); };
    bandDeleteShortcut.setComponentID ("band-delete-shortcut");
    bandDeleteShortcut.setTooltip ("Delete this band");
    bandDeleteShortcut.onClick = [this] { applyBandOption (hoveredBandIndex, 99); };
    for (auto* control : std::array<juce::Button*, 4> { &bandShapeShortcut, &bandOptionsShortcut, &bandPowerShortcut, &bandDeleteShortcut })
        addChildComponent (*control);

    // 1. 'x' (Clear Dynamics): zera a faixa dinâmica sem excluir a banda
    addAndMakeVisible (clearDynamicsButton);
    clearDynamicsButton.setTooltip ("Clear Dynamics (reset Dynamic Range to 0 dB without deleting the band)");
    clearDynamicsButton.onClick = [this]
    {
        if (attachedBandIndex >= 0)
        {
            audioProcessor.undoManager.beginNewTransaction ("Clear Band Dynamics");
            if (auto* pd = audioProcessor.apvts.getParameter (ProQ3AudioProcessor::getBandParamID (attachedBandIndex, "dyn_range")))
                pd->setValueNotifyingHost (pd->convertTo0to1 (0.0f));
            repaint();
        }
    };

    // 2. Power/Bypass Dynamics: suspende somente a dinâmica, preservando o ganho estático e a faixa dinâmica
    addAndMakeVisible (bypassDynamicsButton);
    bypassDynamicsButton.setComponentID ("eq-dynamics-power");
    bypassDynamicsButton.setTitle ("Dynamic EQ Power");
    bypassDynamicsButton.setTooltip ("Bypass Dynamics (suspend dynamic processing while preserving static gain and dynamic range)");

    // 3. Botão Auto Threshold: alterna entre Auto e Manual Threshold (exibindo slider manual + medidor + botão Sidechain)
    addAndMakeVisible (autoThresholdButton);
    autoThresholdButton.setTooltip ("Toggle Auto Threshold / Manual Threshold Slider + External Sidechain");

    manualThresholdSlider.setSliderStyle (juce::Slider::LinearVertical);
    manualThresholdSlider.setTextBoxStyle (juce::Slider::NoTextBox, false, 0, 0);
    manualThresholdSlider.setName ("Dynamic Threshold");
    manualThresholdSlider.setComponentID ("dynamic-threshold");
    manualThresholdSlider.setTooltip ("Drag to set Manual Threshold. The meter shows the detector level in dB.");
    addAndMakeVisible (manualThresholdSlider);
    manualThresholdValue.setJustificationType (juce::Justification::centred);
    manualThresholdValue.setFont (juce::FontOptions (11.0f));
    manualThresholdValue.setColour (juce::Label::textColourId, kTextBright);
    manualThresholdValue.setEditable (false, true, false);
    manualThresholdValue.setTooltip ("Double-click to enter the threshold in dB");
    manualThresholdValue.onTextChange = [this]
    {
        if (attachedBandIndex < 0)
            return;
        const auto text = manualThresholdValue.getText().trim();
        if (text.containsAnyOf ("0123456789"))
            manualThresholdSlider.setValue (juce::jlimit (-60.0, 0.0, text.getDoubleValue()), juce::sendNotificationSync);
    };
    addAndMakeVisible (manualThresholdValue);

    addAndMakeVisible (externalSidechainButton);
    externalSidechainButton.setTooltip ("Trigger Dynamic EQ from External Side Chain Input");

    auto setupLabel = [this] (juce::Label& lbl, const juce::String& text, float fontSize, bool bold, juce::Colour col)
    {
        lbl.setText (text, juce::dontSendNotification);
        lbl.setJustificationType (juce::Justification::centred);
        lbl.setFont (juce::FontOptions (fontSize, bold ? juce::Font::bold : juce::Font::plain));
        lbl.setColour (juce::Label::textColourId, col);
        addAndMakeVisible (lbl);
    };

    setupLabel (freqRangeHintLabel, "10 Hz     30 kHz", 10.5f, false, kTextMuted);
    setupLabel (gainRangeHintLabel, "-30         +30",  10.5f, false, kTextMuted);
    setupLabel (qRangeHintLabel,    "0.025        40",  10.5f, false, kTextMuted);

    setupLabel (freqTitleLabel, "FREQ", 12.0f, true, kTextMuted);
    setupLabel (gainTitleLabel, "GAIN", 12.0f, true, kTextMuted);
    setupLabel (qTitleLabel,    "Q",    12.0f, true, kTextMuted);

    // Duplo clique no título FREQ permite digitar "2k", "A4", "C#3", etc.
    freqTitleLabel.setEditable (true, true, false);
    freqTitleLabel.onTextChange = [this]
    {
        if (attachedBandIndex >= 0)
        {
            const auto bp = audioProcessor.getBandParameters (attachedBandIndex);
            const double parsed = parseFrequencyTextInput (freqTitleLabel.getText(), bp.freqHz);
            if (auto* pf = audioProcessor.apvts.getParameter (ProQ3AudioProcessor::getBandParamID (attachedBandIndex, "freq")))
                pf->setValueNotifyingHost (pf->convertTo0to1 (static_cast<float> (parsed)));
        }
        freqTitleLabel.setText ("FREQ", juce::dontSendNotification);
        repaint();
    };

    addAndMakeVisible (prevBandButton);
    prevBandButton.onClick = [this] { stepSelectedBand (-1); };

    bandNumberLabel.setJustificationType (juce::Justification::centred);
    bandNumberLabel.setFont (juce::FontOptions (12.5f, juce::Font::bold));
    bandNumberLabel.setColour (juce::Label::textColourId, kTextBright);
    addAndMakeVisible (bandNumberLabel);

    addAndMakeVisible (nextBandButton);
    nextBandButton.onClick = [this] { stepSelectedBand (1); };

    // 'X' no canto superior direito do painel flutuante: exclui a banda
    addAndMakeVisible (deleteBandButton);
    deleteBandButton.setTooltip ("Delete Selected EQ Band");
    deleteBandButton.onClick = [this]
    {
        const int sel = audioProcessor.getSelectedBandIndex();
        if (sel >= 0)
        {
            audioProcessor.deactivateBand (sel);
            attachFloatingControlsToBand (audioProcessor.getSelectedBandIndex());
            repaint();
        }
    };

    stereoModeBox.setComponentID ("band-stereo-mode");
    addAndMakeVisible (stereoModeBox);
    stereoModeBox.getProperties().set ("bandPanelControl", true);
    stereoModeBox.setTitle ("Stereo placement");
    stereoModeBox.setTooltip ("Choose Left, Right, Stereo, Mid or Side for this band.");
    const auto placements = audioProcessor.apvts.getParameter ("band01_stereo")->getAllValueStrings();
    for (const auto i : { 1, 2, 0, 3, 4 })
        stereoModeBox.getRootMenu()->addItem (i + 1, placements[i], true, false, makePlacementIcon (i));
    stereoModeBox.onChange = [this]
    {
        const int mode = stereoModeBox.getSelectedId() - 1;
        const auto band = audioProcessor.getBandParameters (attachedBandIndex);
        if (band.used && mode >= 0 && mode != band.stereoMode && stereoModeAttachment != nullptr)
            stereoModeAttachment->setValueAsCompleteGesture (static_cast<float> (mode));
        updateFloatingControlsVisibilityAndValues();
        repaint (graphBounds);
    };

    addAndMakeVisible (soloBandButton);
    addChildComponent (bandSoloShortcut);

    // Botão Split (tesoura na imagem image_435802.png: divide a banda selecionada em Left/Right ou Mid/Side, Manual p. 12 & p. 19)
    addAndMakeVisible (splitStereoButton);
    splitStereoButton.setTooltip ("Split Band into Left/Right or Mid/Side Pair");
    splitStereoButton.onClick = [this] { splitBand (attachedBandIndex); };

    //---- Bottom Bar Controls ----
    addAndMakeVisible (processingModeBox);
    processingModeBox.getProperties().set ("toolbar", true);
    processingModeBox.setTooltip ("Processing mode");
    processingModeBox.addItemList ({ "Zero Latency", "Natural Phase", "Linear Phase" }, 1);
    processingModeAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment> (
        audioProcessor.apvts, "processing_mode", processingModeBox);

    for (auto* button : { &analyzerButton, &midiLearnButton })
    {
        addAndMakeVisible (*button);
        button->getProperties().set ("toolbar", true);
        button->setColour (juce::TextButton::textColourOffId, kTextBright);
        button->setColour (juce::TextButton::textColourOnId, kTextBright);
    }
    analyzerButton.setComponentID ("analyzer-settings");
    analyzerButton.setTooltip ("Hover for spectrum sources. Click to keep the panel open.");
    analyzerButton.onClick = [this] { showAnalyzerMenu(); };
    configureAnalyzerPanel();
    configureInstanceOverview();
    characterBox.setComponentID ("output-character");
    characterBox.getProperties().set ("toolbar", true);
    characterBox.setTitle ("Character");
    characterBox.setTooltip ("Choose Clean for transparent EQ, Subtle for light saturation, or Warm for stronger asymmetric saturation.");
    characterBox.addItemList (audioProcessor.apvts.getParameter ("output_character")->getAllValueStrings(), 1);
    addAndMakeVisible (characterBox);
    characterAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment> (
        audioProcessor.apvts, "output_character", characterBox);

    eqSketchButton.setComponentID ("eq-sketch");
    eqSketchButton.setTitle ("EQ Sketch");
    eqSketchButton.setTooltip ("Draw across the graph from left to right. Move back to revise the sketch and release to create the bands.");
    eqSketchButton.setClickingTogglesState (true);
    eqSketchButton.getProperties().set ("toolbar", true);
    eqSketchButton.onClick = [this]
    {
        if (eqSketchButton.getToggleState())
            finishSpectrumGrab();
        else if (sketching)
            finishEqSketch (false);
        repaint (graphBounds);
    };
    addAndMakeVisible (eqSketchButton);
    configureMatchPanel();
    midiLearnButton.setComponentID ("midi-learn");
    midiLearnButton.setTooltip ("Assign a MIDI controller to an output control");
    midiLearnButton.onClick = [this] { showMidiLearnMenu(); };

    addAndMakeVisible (pianoToggleButton);
    pianoDisplayAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment> (
        audioProcessor.apvts, "piano_display", pianoToggleButton);

    addAndMakeVisible (displayRangeButton);
    displayRangeButton.setComponentID ("display-range");
    displayRangeButton.setTooltip ("Cycle display range: 12, 6, 3, and 30 dB");
    displayRangeButton.setColour (juce::TextButton::textColourOffId, kEqGold);
    displayRangeButton.onClick = [this]
    {
        constexpr std::array<int, 4> nextRange { 3, 0, 1, 2 };
        const auto index = juce::jlimit (0, 3, juce::roundToInt (audioProcessor.apvts.getRawParameterValue ("display_range")->load()));
        setParameterFromEditor ("display_range", static_cast<float> (nextRange[static_cast<size_t> (index)]));
        refreshStatusControls();
        repaint (graphBounds);
    };
    refreshStatusControls();

    configureOutputControls();

    addAndMakeVisible (globalBypassButton);
    globalBypassAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment> (
        audioProcessor.apvts, "global_bypass", globalBypassButton);

    attachFloatingControlsToBand (audioProcessor.getSelectedBandIndex());

    setSize (900, 540);
    startTimerHz (60);
}

ProQ3AudioProcessorEditor::~ProQ3AudioProcessorEditor()
{
    stopTimer();
    outputControlButton.removeMouseListener (this);
    stopBandSolo();
    setLookAndFeel (nullptr);
}

ProQ3AudioProcessorEditor::SoloButton::SoloButton (ProQ3AudioProcessorEditor& owner, bool card)
    : juce::Button ("Band Solo"), editor (owner), onBandCard (card)
{
    setComponentID (card ? "band-solo-shortcut" : "band-solo");
    setTooltip ("Hold to audition this band. Drag to change frequency and listening level. Ctrl or Command-drag vertically to adjust Q.");
}

void ProQ3AudioProcessorEditor::SoloButton::paintButton (juce::Graphics& g, bool highlighted, bool)
{
    const auto active = editor.heldSoloButton == this;
    const auto bounds = getLocalBounds().toFloat().reduced (0.5f);
    const auto red = juce::Colour (0xffff5964);
    const auto icon = active || highlighted ? red : juce::Colour (0xffc7c3ce);
    g.setColour (active ? juce::Colour (0xffa52332)
                        : juce::Colour (highlighted ? 0xdb56303d : 0xbc2c2935));
    g.fillRoundedRectangle (bounds, 4.0f);
    g.setColour (icon.withAlpha (active || highlighted ? 0.86f : 0.23f));
    g.drawRoundedRectangle (bounds, 4.0f, 1.0f);

    juce::Path headband;
    headband.startNewSubPath (-5.0f, 2.5f);
    headband.lineTo (-5.0f, -0.7f);
    headband.cubicTo (-5.0f, -7.0f, 5.0f, -7.0f, 5.0f, -0.7f);
    headband.lineTo (5.0f, 2.5f);
    const auto centre = bounds.getCentre();
    g.setColour (icon.withMultipliedAlpha (isEnabled() ? 1.0f : 0.42f));
    g.strokePath (headband, juce::PathStrokeType (1.4f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded),
                  juce::AffineTransform::translation (centre.x, centre.y));
    g.fillRoundedRectangle (centre.x - 6.1f, centre.y - 0.45f, 2.8f, 5.1f, 1.0f);
    g.fillRoundedRectangle (centre.x + 3.3f, centre.y - 0.45f, 2.8f, 5.1f, 1.0f);
}

void ProQ3AudioProcessorEditor::SoloButton::mouseDown (const juce::MouseEvent& event)
{
    juce::Button::mouseDown (event);
    if (isEnabled() && event.mods.isLeftButtonDown())
        editor.startBandSolo (*this, event);
}

void ProQ3AudioProcessorEditor::SoloButton::mouseDrag (const juce::MouseEvent& event)
{
    juce::Button::mouseDrag (event);
    if (editor.heldSoloButton == this)
        editor.dragBandSolo (event);
}

void ProQ3AudioProcessorEditor::SoloButton::mouseUp (const juce::MouseEvent& event)
{
    juce::Button::mouseUp (event);
    if (editor.heldSoloButton == this)
        editor.stopBandSolo();
}

void ProQ3AudioProcessorEditor::startBandSolo (SoloButton& button, const juce::MouseEvent& event)
{
    const auto bandIndex = button.onBandCard ? hoveredBandIndex : attachedBandIndex;
    const auto band = audioProcessor.getBandParameters (bandIndex);
    if (! band.used || audioProcessor.apvts.getRawParameterValue ("global_bypass")->load() >= 0.5f)
        return;

    stopBandSolo();
    heldSoloButton = &button;
    soloControlBand = bandIndex;
    soloDragOrigin = event.getEventRelativeTo (this).position;
    soloStartFrequency = band.freqHz;
    soloStartQ = band.q;
    soloStartLevel = soloListeningLevel;
    audioProcessor.setSoloBandIndex (soloControlBand, soloListeningLevel);
    updateBandShortcuts();
    repaint (graphBounds);
}

void ProQ3AudioProcessorEditor::dragBandSolo (const juce::MouseEvent& event)
{
    const auto delta = event.getEventRelativeTo (this).position - soloDragOrigin;
    const auto update = [this] (juce::RangedAudioParameter*& gesture, const char* parameter, float value)
    {
        if (gesture == nullptr)
        {
            if (soloFrequencyGesture == nullptr && soloQGesture == nullptr)
                audioProcessor.undoManager.beginNewTransaction ("Adjust Solo Band");
            gesture = audioProcessor.apvts.getParameter (ProQ3AudioProcessor::getBandParamID (soloControlBand, parameter));
            gesture->beginChangeGesture();
        }
        gesture->setValueNotifyingHost (gesture->convertTo0to1 (value));
    };

    if (std::abs (delta.x) >= 1.0f || soloFrequencyGesture != nullptr)
    {
        const auto ratio = std::pow (kMaxFreqHz / kMinFreqHz, delta.x * frequencyViewSpan / graphBounds.getWidth());
        update (soloFrequencyGesture, "freq", static_cast<float> (juce::jlimit (kMinFreqHz, kMaxFreqHz, soloStartFrequency * ratio)));
    }
    if (event.mods.isCtrlDown() || event.mods.isCommandDown())
    {
        if (std::abs (delta.y) >= 1.0f || soloQGesture != nullptr)
            update (soloQGesture, "q", static_cast<float> (juce::jlimit (0.025, 40.0, soloStartQ * std::exp (-delta.y * 0.015))));
    }
    else
    {
        soloListeningLevel = juce::jlimit (-36.0f, 6.0f, soloStartLevel - 0.20f * delta.y);
        audioProcessor.setSoloBandIndex (soloControlBand, soloListeningLevel);
    }
    updateBandShortcuts();
    repaint (graphBounds);
}

void ProQ3AudioProcessorEditor::stopBandSolo()
{
    if (heldSoloButton == nullptr)
        return;

    audioProcessor.setSoloBandIndex (-1);
    for (auto* gesture : { soloFrequencyGesture, soloQGesture })
        if (gesture != nullptr)
            gesture->endChangeGesture();
    soloFrequencyGesture = soloQGesture = nullptr;
    soloControlBand = -1;
    heldSoloButton->repaint();
    heldSoloButton = nullptr;
    repaint (graphBounds);
}

ProQ3AudioProcessorEditor::PianoButton::PianoButton() : juce::Button ("Piano")
{
    setClickingTogglesState (true);
    setTooltip ("Show or hide the piano keyboard");
}

void ProQ3AudioProcessorEditor::PianoButton::paintButton (juce::Graphics& g, bool highlighted, bool down)
{
    const bool active = getToggleState();
    if (highlighted || down || active || hasKeyboardFocus (false))
    {
        g.setColour (juce::Colour (active ? 0xff403a45 : 0xff342f38));
        g.fillRoundedRectangle (getLocalBounds().toFloat().reduced (2.0f), 4.0f);
    }

    const auto keys = getLocalBounds().toFloat().withSizeKeepingCentre (20.0f, 13.0f);
    g.setColour (juce::Colour (active ? 0xffbdc0c8 : 0x9eb4b6be));
    g.drawRoundedRectangle (keys, 1.4f, 1.0f);
    for (int key = 1; key < 5; ++key)
    {
        const auto x = keys.getX() + static_cast<float> (key) * 4.0f;
        g.drawLine (x, keys.getY() + 1.0f, x, keys.getBottom() - 0.5f, 0.7f);
        if (key != 3)
            g.fillRect (x - 0.85f, keys.getY() + 0.6f, 1.7f, 6.5f);
    }
}

void ProQ3AudioProcessorEditor::OutputPanel::paint (juce::Graphics& g)
{
    const auto frame = getLocalBounds().toFloat().reduced (1.0f);
    juce::ColourGradient body (juce::Colour (0xca35303f), frame.getX(), frame.getY(),
                               juce::Colour (0xd5201d29), frame.getX(), frame.getBottom(), false);
    g.setGradientFill (body);
    g.fillRoundedRectangle (frame, 8.0f);
    g.setColour (juce::Colour (0xc06c6076));
    g.drawRoundedRectangle (frame, 8.0f, 1.0f);
    g.drawHorizontalLine (106, frame.getX() + 11.0f, frame.getRight() - 11.0f);
}

void ProQ3AudioProcessorEditor::configureOutputControls()
{
    using State = juce::AudioProcessorValueTreeState;

    addAndMakeVisible (outputControlButton);
    outputControlButton.setComponentID ("output-readout");
    outputControlButton.setColour (juce::TextButton::textColourOffId, kTextBright);
    outputControlButton.setTooltip ("Output Level and Gain Scale");
    outputControlButton.addMouseListener (this, false);
    outputControlButton.onClick = [this]
    {
        outputPanelKeyboardAccess = true;
        showOutputPanel();
        outputGainSlider.grabKeyboardFocus();
    };

    addChildComponent (outputPanel);
    outputPanel.setComponentID ("output-panel");
    for (auto* label : { &outputLevelLabel, &outputScaleLabel, &outputBalanceLabel })
    {
        label->setColour (juce::Label::textColourId, kTextBright);
        label->setFont (juce::FontOptions (11.5f));
        outputPanel.addAndMakeVisible (*label);
    }
    outputLevelLabel.setFont (juce::FontOptions (13.0f, juce::Font::bold));
    outputLevelLabel.setJustificationType (juce::Justification::centred);

    outputGainSlider.setComponentID ("output-level");
    outputGainSlider.setSliderStyle (juce::Slider::RotaryHorizontalVerticalDrag);
    outputGainSlider.setTextBoxStyle (juce::Slider::TextBoxBelow, false, 64, 18);
    outputGainSlider.setTextValueSuffix (" dB");
    outputGainSlider.setDoubleClickReturnValue (true, 0.0);
    outputGainSlider.setTooltip ("Output Level");
    outputGainSlider.setWantsKeyboardFocus (true);
    outputPanel.addAndMakeVisible (outputGainSlider);
    outputGainAttachment = std::make_unique<State::SliderAttachment> (audioProcessor.apvts, "global_output_gain", outputGainSlider);

    for (auto* slider : { &outputScaleSlider, &outputBalanceSlider })
    {
        slider->setSliderStyle (juce::Slider::LinearHorizontal);
        slider->setColour (juce::Slider::trackColourId, kControlAccent);
        slider->setColour (juce::Slider::thumbColourId, kTextBright);
        outputPanel.addAndMakeVisible (*slider);
    }

    outputScaleSlider.setComponentID ("output-gain-scale");
    outputScaleSlider.setTextBoxStyle (juce::Slider::TextBoxRight, false, 46, 18);
    outputScaleSlider.setTextValueSuffix ("%");
    outputScaleSlider.setDoubleClickReturnValue (true, 100.0);
    outputScaleSlider.setTooltip ("Scale the gain of EQ bands");
    outputScaleAttachment = std::make_unique<State::SliderAttachment> (audioProcessor.apvts, "global_gain_scale", outputScaleSlider);

    outputBalanceSlider.setComponentID ("output-balance");
    outputBalanceSlider.setTextBoxStyle (juce::Slider::NoTextBox, false, 0, 0);
    outputBalanceSlider.setTooltip ("Drag to balance L/R or M/S. Double-click to centre.");
    outputBalanceSlider.setDoubleClickReturnValue (true, 0.0);
    outputBalanceSlider.setPopupDisplayEnabled (true, true, &outputPanel);
    outputBalanceAttachment = std::make_unique<State::SliderAttachment> (audioProcessor.apvts, "global_output_balance", outputBalanceSlider);

    outputBalanceModeBox.setComponentID ("output-balance-mode");
    outputBalanceModeBox.setTooltip ("Left/Right or Mid/Side balance");
    outputBalanceModeBox.addItemList ({ "L/R", "M/S" }, 1);
    outputPanel.addAndMakeVisible (outputBalanceModeBox);
    outputBalanceModeAttachment = std::make_unique<State::ComboBoxAttachment> (audioProcessor.apvts, "global_output_balance_mode", outputBalanceModeBox);

    outputPolarityButton.setComponentID ("output-polarity");
    outputAutoGainButton.setComponentID ("output-auto-gain");
    outputOptionsButton.setComponentID ("output-options");
    outputPolarityButton.setButtonText ("");
    outputOptionsButton.setButtonText ("");
    outputPolarityButton.setTitle ("Invert Polarity");
    outputAutoGainButton.setTitle ("Auto Gain");
    outputOptionsButton.setTitle ("Output Options");
    outputPolarityButton.setTooltip ("Invert output polarity");
    outputAutoGainButton.setTooltip ("Automatically compensate EQ gain");
    outputOptionsButton.setTooltip ("Output options");
    for (auto* button : { &outputPolarityButton, &outputAutoGainButton, &outputOptionsButton })
    {
        button->setColour (juce::TextButton::textColourOffId, kTextBright);
        outputPanel.addAndMakeVisible (*button);
    }
    outputPolarityButton.setClickingTogglesState (true);
    outputAutoGainButton.setClickingTogglesState (true);
    outputPolarityAttachment = std::make_unique<State::ButtonAttachment> (audioProcessor.apvts, "global_phase_invert", outputPolarityButton);
    outputAutoGainAttachment = std::make_unique<State::ButtonAttachment> (audioProcessor.apvts, "global_auto_gain", outputAutoGainButton);
    outputOptionsButton.onClick = [this] { showOutputOptions(); };

    outputGainSlider.onValueChange = [this] { updateOutputReadout(); };
    outputScaleSlider.onValueChange = [this] { updateOutputReadout(); };
    updateOutputReadout();
}

void ProQ3AudioProcessorEditor::setParameterFromEditor (const char* id, float value)
{
    if (auto* parameter = audioProcessor.apvts.getParameter (id))
    {
        parameter->beginChangeGesture();
        parameter->setValueNotifyingHost (parameter->convertTo0to1 (value));
        parameter->endChangeGesture();
    }
}

void ProQ3AudioProcessorEditor::showMidiLearnMenu()
{
    juce::PopupMenu menu;
    if (audioProcessor.isMidiLearnArmed())
        menu.addSectionHeader ("Move a MIDI CC control to finish learning");
    menu.addItem (1, "Learn Output Level");
    menu.addItem (2, "Learn Gain Scale");
    menu.addItem (3, "Clear MIDI Assignments",
                  audioProcessor.isMidiLearnArmed() || audioProcessor.hasMidiOutputMapping());
    menu.showMenuAsync (juce::PopupMenu::Options().withTargetComponent (&midiLearnButton),
                        [editor = juce::Component::SafePointer<ProQ3AudioProcessorEditor> (this)] (int item)
                        {
                            if (editor == nullptr || item == 0)
                                return;
                            using Target = ProQ3AudioProcessor::MidiOutputTarget;
                            if (item == 3)
                                editor->audioProcessor.clearMidiLearn();
                            else
                                editor->audioProcessor.armMidiLearn (item == 1 ? Target::outputLevel : Target::gainScale);
                            editor->refreshStatusControls();
                        });
}

void ProQ3AudioProcessorEditor::toggleExpandedView()
{
    if (! compactEditorBounds.isEmpty())
    {
        setSize (compactEditorBounds.getWidth(), compactEditorBounds.getHeight());
        compactEditorBounds = {};
        expandButton.setTooltip ("Expand editor");
        return;
    }

    const auto* display = juce::Desktop::getInstance().getDisplays().getDisplayForRect (getScreenBounds());
    if (display == nullptr)
        return;

    const auto available = display->userArea.reduced (24);
    const int width = juce::jmin (1280, available.getWidth());
    const int height = juce::jmin (800, available.getHeight());
    if (width < getWidth() || height < getHeight() || (width == getWidth() && height == getHeight()))
        return;

    compactEditorBounds = getLocalBounds();
    setSize (width, height);
    expandButton.setTooltip ("Restore editor size");
}

void ProQ3AudioProcessorEditor::refreshStatusControls()
{
    const auto isOn = [this] (const char* id)
    {
        return audioProcessor.apvts.getRawParameterValue (id)->load (std::memory_order_relaxed) > 0.5f;
    };

    const bool pre = isOn ("analyzer_pre");
    const bool post = isOn ("analyzer_post");
    const bool sidechain = isOn ("analyzer_sc");
    constexpr const char* states[] { "Off", "Pre", "Post", "Pre+Post", "Sidechain", "Pre+SC", "Post+SC", "Pre+Post+SC" };
    const auto state = (pre ? 1 : 0) + (post ? 2 : 0) + (sidechain ? 4 : 0);
    const auto analyzerText = juce::String ("Analyzer: ") + states[state] + (analyzerExternalId > 0 ? "+" + getAnalyzerSourceName() : "");
    if (analyzerButton.getButtonText() != analyzerText)
        analyzerButton.setButtonText (analyzerText);

    constexpr const char* ranges[] { "3 dB", "6 dB", "12 dB", "30 dB" };
    const auto range = juce::jlimit (0, 3, juce::roundToInt (audioProcessor.apvts.getRawParameterValue ("display_range")->load()));
    if (displayRangeButton.getButtonText() != ranges[range])
        displayRangeButton.setButtonText (ranges[range]);

    const bool learning = audioProcessor.isMidiLearnArmed();
    midiLearnButton.setToggleState (learning || audioProcessor.hasMidiOutputMapping(), juce::dontSendNotification);
    const auto* midiTooltip = learning ? "Move a MIDI CC control now" : "Assign a MIDI controller to an output control";
    if (midiLearnButton.getTooltip() != midiTooltip)
        midiLearnButton.setTooltip (midiTooltip);
}

void ProQ3AudioProcessorEditor::updateOutputReadout()
{
    const auto gain = outputGainSlider.getValue();
    outputControlButton.setButtonText (juce::String (juce::roundToInt (outputScaleSlider.getValue()))
                                      + "%   " + (gain > 0.0 ? "+" : "") + juce::String (gain, 1) + " dB");
}

void ProQ3AudioProcessorEditor::showOutputPanel()
{
    outputPanelLastInteraction = juce::Time::getMillisecondCounterHiRes();
    if (! outputPanel.isVisible())
    {
        outputPanel.setVisible (true);
        outputPanel.toFront (false);
    }
}

void ProQ3AudioProcessorEditor::updateOutputPanelVisibility()
{
    if (! outputPanel.isVisible())
        return;

    const bool keepKeyboardFocus = outputPanelKeyboardAccess
        && (outputControlButton.hasKeyboardFocus (false) || outputPanel.hasKeyboardFocus (true));
    const auto now = juce::Time::getMillisecondCounterHiRes();
    if (outputControlButton.isMouseOver() || outputPanel.isMouseOver (true) || keepKeyboardFocus
        || outputOptionsOpen || outputBalanceModeBox.isPopupActive()
        || juce::Desktop::getInstance().getMainMouseSource().isDragging())
    {
        outputPanelLastInteraction = now;
    }
    else if (now - outputPanelLastInteraction >= 220.0)
    {
        outputPanelKeyboardAccess = false;
        outputPanel.setVisible (false);
    }
}

void ProQ3AudioProcessorEditor::showOutputOptions()
{
    juce::PopupMenu menu;
    menu.addItem (1, "Reset Output Level");
    menu.addItem (2, "Reset Gain Scale");
    menu.addItem (3, "Centre Balance");
    outputOptionsOpen = true;
    menu.showMenuAsync (juce::PopupMenu::Options().withTargetComponent (&outputOptionsButton),
                        [editor = juce::Component::SafePointer<ProQ3AudioProcessorEditor> (this)] (int item)
                        {
                            if (editor == nullptr)
                                return;
                            editor->outputOptionsOpen = false;
                            editor->outputPanelLastInteraction = juce::Time::getMillisecondCounterHiRes();
                            if (item == 1)
                                editor->outputGainSlider.setValue (0.0, juce::sendNotificationSync);
                            else if (item == 2)
                                editor->outputScaleSlider.setValue (100.0, juce::sendNotificationSync);
                            else if (item == 3)
                                editor->outputBalanceSlider.setValue (0.0, juce::sendNotificationSync);
                        });
}

//==============================================================================
// Conversões Geométricas
//==============================================================================
double ProQ3AudioProcessorEditor::getCurrentDisplayRangeDb() const noexcept
{
    const int idx = static_cast<int> (std::lround (
        audioProcessor.apvts.getRawParameterValue ("display_range")->load (std::memory_order_relaxed)));

    switch (idx)
    {
        case 0: return 3.0;
        case 1: return 6.0;
        case 2: return 12.0;
        case 3: return 30.0;
        default: return 12.0;
    }
}

float ProQ3AudioProcessorEditor::frequencyToX (double freqHz) const noexcept
{
    const double clamped = juce::jlimit (kMinFreqHz, kMaxFreqHz, freqHz);
    const double norm = std::log (clamped / kMinFreqHz) / std::log (kMaxFreqHz / kMinFreqHz);
    return static_cast<float> (graphBounds.getX())
        + static_cast<float> ((norm - frequencyViewStart) * graphBounds.getWidth() / frequencyViewSpan);
}

double ProQ3AudioProcessorEditor::xToFrequency (float x) const noexcept
{
    if (graphBounds.getWidth() <= 1)
        return 1000.0;

    const double norm = juce::jlimit (0.0, 1.0,
        static_cast<double> (x - static_cast<float> (graphBounds.getX())) / static_cast<double> (graphBounds.getWidth()));
    return kMinFreqHz * std::pow (kMaxFreqHz / kMinFreqHz, frequencyViewStart + norm * frequencyViewSpan);
}

bool ProQ3AudioProcessorEditor::isOverFrequencyStrip (juce::Point<int> position) const noexcept
{
    return pianoBounds.contains (position)
        && audioProcessor.apvts.getRawParameterValue ("piano_display")->load() < 0.5f;
}

void ProQ3AudioProcessorEditor::updateFrequencyView (double anchor, double zoom, double position)
{
    frequencyViewSpan = juce::jlimit (0.12, 1.0, zoom);
    frequencyViewStart = juce::jlimit (0.0, 1.0 - frequencyViewSpan, anchor - position * frequencyViewSpan);
    layoutBandControls();
    updateBandShortcuts();
    repaint (graphBounds);
}

float ProQ3AudioProcessorEditor::gainDbToY (double gainDb) const noexcept
{
    const double maxDb = getCurrentDisplayRangeDb();
    const auto norm = juce::jlimit (0.0, 1.0, 0.35 - (0.31 * gainDb / maxDb));
    return static_cast<float> (graphBounds.getY() + norm * graphBounds.getHeight());
}

double ProQ3AudioProcessorEditor::yToGainDb (float y) const noexcept
{
    if (graphBounds.getHeight() <= 1)
        return 0.0;

    const double norm = juce::jlimit (0.0, 1.0,
        static_cast<double> (y - static_cast<float> (graphBounds.getY())) / static_cast<double> (graphBounds.getHeight()));
    return juce::jlimit (-30.0, 30.0, (0.35 - norm) * getCurrentDisplayRangeDb() / 0.31);
}

int ProQ3AudioProcessorEditor::getSpectrumDisplayRange() const noexcept
{
    constexpr std::array<int, 4> ranges { 60, 90, 100, 120 };
    return ranges[static_cast<size_t> (juce::jlimit (0, 3, analyzerPanel.range.getSelectedId() - 1))];
}

float ProQ3AudioProcessorEditor::analyzerDbToY (double analyzerDb) const noexcept
{
    // Use one dBFS axis for the spectrum, meter bars and meter labels.
    const auto top = graphBounds.getY() + 22;
    const auto height = graphBounds.getBottom() - top - 12;
    const auto norm = -analyzerDb / getSpectrumDisplayRange();
    return static_cast<float> (juce::jlimit (static_cast<double> (top),
                                            static_cast<double> (graphBounds.getBottom()), top + norm * height));
}

juce::String ProQ3AudioProcessorEditor::frequencyToMusicalNoteName (double freqHz)
{
    if (freqHz <= 0.0)
        return {};

    static const char* noteNames[12] = { "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B" };
    const double midiExact = 69.0 + 12.0 * std::log2 (freqHz / 440.0);
    const int midiNearest = static_cast<int> (std::lround (midiExact));
    const int cents = static_cast<int> (std::lround ((midiExact - static_cast<double> (midiNearest)) * 100.0));

    const int noteIdx = ((midiNearest % 12) + 12) % 12;
    const int octave  = (midiNearest / 12) - 1;

    juce::String s = juce::String (noteNames[noteIdx]) + juce::String (octave);
    if (cents != 0)
        s += (cents > 0 ? " +" : " ") + juce::String (cents);
    return s;
}

double ProQ3AudioProcessorEditor::snapFrequencyToNearestSemitone (double freqHz) noexcept
{
    const double midiExact = 69.0 + 12.0 * std::log2 (juce::jmax (10.0, freqHz) / 440.0);
    const double midiRound = std::round (midiExact);
    return 440.0 * std::pow (2.0, (midiRound - 69.0) / 12.0);
}

//==============================================================================
// Conexão do Painel Flutuante (Floating Band Controls Pill) à Banda Selecionada
//==============================================================================
void ProQ3AudioProcessorEditor::refreshFactoryPresetName()
{
    const auto name = audioProcessor.getFactoryPresetName (audioProcessor.getFactoryPresetIndex());
    presetNameButton.setButtonText (name.isEmpty() ? juce::String ("Presets") : name);
    presetNameButton.setTooltip (name);
}

void ProQ3AudioProcessorEditor::loadFactoryPreset (int index)
{
    audioProcessor.loadFactoryPreset (index);
    refreshFactoryPresetName();
    attachFloatingControlsToBand (audioProcessor.getSelectedBandIndex());
    repaint();
}

void ProQ3AudioProcessorEditor::stepFactoryPreset (int delta)
{
    const int count = audioProcessor.getFactoryPresetCount();
    const int current = audioProcessor.getFactoryPresetIndex();
    const int next = current < 0 ? (delta < 0 ? count - 1 : 0) : (current + delta + count) % count;
    loadFactoryPreset (next);
}

void ProQ3AudioProcessorEditor::showFactoryPresetMenu()
{
    juce::PopupMenu menu;
    std::map<juce::String, juce::PopupMenu> categories;
    const int current = audioProcessor.getFactoryPresetIndex();
    for (int index = 0; index < audioProcessor.getFactoryPresetCount(); ++index)
    {
        const auto category = audioProcessor.getFactoryPresetCategory (index);
        auto& section = category.isEmpty() ? menu : categories[category];
        section.addItem (index + 1, audioProcessor.getFactoryPresetName (index), true, index == current);
    }

    juce::PopupMenu dynamic;
    for (const auto& [category, presets] : categories)
        dynamic.addSubMenu (category, presets);
    menu.addSeparator();
    menu.addSubMenu ("Dynamic", dynamic);

    menu.showMenuAsync (juce::PopupMenu::Options().withTargetComponent (&presetNameButton),
                        [editor = juce::Component::SafePointer<ProQ3AudioProcessorEditor> (this)] (int item)
                        {
                            if (editor != nullptr && item != 0)
                                editor->loadFactoryPreset (item - 1);
                        });
}

void ProQ3AudioProcessorEditor::attachFloatingControlsToBand (int bandIndex)
{
    if (bandIndex != attachedBandIndex || ! audioProcessor.getBandParameters (bandIndex).used)
        expandedDynamicsBand = -1;
    bandEnabledAttachment.reset();
    bandShapeAttachment.reset();
    allPassAttachment.reset();
    bandSlopeAttachment.reset();
    freqAttachment.reset();
    qAttachment.reset();
    gainQInterAttachment.reset();
    bypassDynamicsAttachment.reset();
    autoThresholdAttachment.reset();
    manualThresholdAttachment.reset();
    externalSidechainAttachment.reset();
    stereoModeAttachment.reset();
    spectralTiltAttachment.reset();
    spectralDensityAttachment.reset();

    if (bandIndex < 0 || bandIndex >= ProQ3AudioProcessor::kMaxBands || ! audioProcessor.getBandParameters (bandIndex).used)
    {
        attachedBandIndex = -1;
        concentricGainKnob.bindParameters (nullptr, nullptr, nullptr);
        updateFloatingControlsVisibilityAndValues();
        return;
    }

    attachedBandIndex = bandIndex;
    audioProcessor.setSelectedBandIndex (bandIndex);
    layoutBandControls();

    bandEnabledAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment> (
        audioProcessor.apvts, ProQ3AudioProcessor::getBandParamID (bandIndex, "enabled"), bandBypassButton);

    const auto syncShape = [this] (float)
    {
        const auto bp = audioProcessor.getBandParameters (attachedBandIndex);
        bandShapeBox.setSelectedItemIndex (bp.shape, juce::dontSendNotification);
        for (juce::PopupMenu::MenuItemIterator item (*bandShapeBox.getRootMenu()); item.next();)
        {
            const auto index = item.getItem().itemID - 1;
            item.getItem().image = makeShapeIcon (index, index == bp.shape ? kEqGold : kTextMuted);
        }
    };
    bandShapeAttachment = std::make_unique<juce::ParameterAttachment> (
        *audioProcessor.apvts.getParameter (ProQ3AudioProcessor::getBandParamID (bandIndex, "shape")), syncShape);
    allPassAttachment = std::make_unique<juce::ParameterAttachment> (
        *audioProcessor.apvts.getParameter (ProQ3AudioProcessor::getBandParamID (bandIndex, "all_pass")), syncShape);
    syncShape (0.0f);

    bandSlopeAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment> (
        audioProcessor.apvts, ProQ3AudioProcessor::getBandParamID (bandIndex, "slope"), bandSlopeBox);

    freqAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (
        audioProcessor.apvts, ProQ3AudioProcessor::getBandParamID (bandIndex, "freq"), freqSlider);

    concentricGainKnob.bindParameters (
        audioProcessor.apvts.getParameter (ProQ3AudioProcessor::getBandParamID (bandIndex, "gain")),
        audioProcessor.apvts.getParameter (ProQ3AudioProcessor::getBandParamID (bandIndex, "dyn_range")),
        &audioProcessor.undoManager);

    qAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (
        audioProcessor.apvts, ProQ3AudioProcessor::getBandParamID (bandIndex, "q"), qSlider);

    gainQInterAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment> (
        audioProcessor.apvts, ProQ3AudioProcessor::getBandParamID (bandIndex, "gain_q"), gainQInterButton);

    bypassDynamicsAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment> (
        audioProcessor.apvts, ProQ3AudioProcessor::getBandParamID (bandIndex, "dyn_enabled"), bypassDynamicsButton);

    autoThresholdAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment> (
        audioProcessor.apvts, ProQ3AudioProcessor::getBandParamID (bandIndex, "dyn_auto"), autoThresholdButton);

    manualThresholdAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (
        audioProcessor.apvts, ProQ3AudioProcessor::getBandParamID (bandIndex, "dyn_thresh"), manualThresholdSlider);

    externalSidechainAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment> (
        audioProcessor.apvts, ProQ3AudioProcessor::getBandParamID (bandIndex, "dyn_ext_sc"), externalSidechainButton);

    stereoModeAttachment = std::make_unique<juce::ParameterAttachment> (
        *audioProcessor.apvts.getParameter (ProQ3AudioProcessor::getBandParamID (bandIndex, "stereo")),
        [this] (float mode)
        {
            stereoModeBox.setSelectedId (juce::roundToInt (mode) + 1, juce::dontSendNotification);
            updateFloatingControlsVisibilityAndValues();
            repaint (graphBounds);
        },
        &audioProcessor.undoManager);
    stereoModeAttachment->sendInitialUpdate();
    spectralTiltAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment> (
        audioProcessor.apvts, ProQ3AudioProcessor::getBandParamID (bandIndex, "spectral_tilt"), spectralTiltButton);
    spectralDensityAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (
        audioProcessor.apvts, ProQ3AudioProcessor::getBandParamID (bandIndex, "spectral_density"), spectralDensitySlider);

    bandNumberLabel.setText (juce::String (bandIndex + 1), juce::dontSendNotification);
    updateFloatingControlsVisibilityAndValues();
}

void ProQ3AudioProcessorEditor::updateFloatingControlsVisibilityAndValues()
{
    const bool visible = ! spectrumGrabActive && audioProcessor.getBandParameters (attachedBandIndex).used;

    bandBypassButton.setVisible (visible);
    bandShapeBox.setVisible (visible);
    bandSlopeBox.setVisible (visible);
    freqSlider.setVisible (visible);
    concentricGainKnob.setVisible (visible);
    qSlider.setVisible (visible);
    gainQInterButton.setVisible (visible);
    freqTitleLabel.setVisible (visible);
    gainTitleLabel.setVisible (visible);
    qTitleLabel.setVisible (visible);
    freqRangeHintLabel.setVisible (visible);
    const auto active = audioProcessor.getBandParameters (attachedBandIndex);
    const bool showSpectral = visible && ProQ3AudioProcessor::doesShapeSupportDynamics (active.shape);
    spectralButton.setVisible (showSpectral);
    spectralButton.setToggleState (active.spectral, juce::dontSendNotification);
    spectralTiltButton.setVisible (showSpectral && active.spectral);
    spectralDensitySlider.setVisible (showSpectral && active.spectral);
    gainRangeHintLabel.setVisible (visible && ! spectralDensitySlider.isVisible());
    qRangeHintLabel.setVisible (visible);
    prevBandButton.setVisible (visible);
    bandNumberLabel.setVisible (visible);
    nextBandButton.setVisible (visible);
    deleteBandButton.setVisible (visible);
    stereoModeBox.setVisible (visible);
    soloBandButton.setVisible (visible);
    splitStereoButton.setVisible (visible);

    if (visible)
    {
        const auto bp = audioProcessor.getBandParameters (attachedBandIndex);
        const bool supportsGain = ProQ3AudioProcessor::doesShapeSupportGain (bp.shape);
        const bool supportsDyn  = ProQ3AudioProcessor::doesShapeSupportDynamics (bp.shape);
        const bool supportsQ    = ProQ3AudioProcessor::doesShapeSupportQ (bp.shape, bp.slopeIndex);
        const bool hasDynRange  = std::abs (bp.dynRangeDb) > 0.05;

        concentricGainKnob.setEnabled (supportsGain);
        concentricGainKnob.setDynamicsActiveAndSupported (supportsDyn, ! bp.dynEnabled);
        const auto liveGain = bp.enabled && bp.dynEnabled && hasDynRange
            ? bandDynamics[static_cast<size_t> (attachedBandIndex)].gainDb : 0.0f;
        concentricGainKnob.setLiveDynamicModulationDb (liveGain);

        const auto accent = bandPanelAccent (bp.stereoMode);
        for (auto* knob : std::array<juce::Component*, 3> { &freqSlider, &concentricGainKnob, &qSlider })
            knob->setColour (juce::Slider::rotarySliderFillColourId, accent);
        qSlider.setEnabled (supportsQ);
        bandSlopeBox.setEnabled (bp.shape != ProQ3AudioProcessor::kShapeFlatTilt);

        // Quando a banda tem Dynamic Range != 0 (ou está em modo Manual Threshold), exibe os botões do topo do anel
        // (clearDynamics 'x', bypassDynamics power, Auto button); quando Auto está desligado, expande o slider de limiar manual e o botão Sidechain (SC)
        const bool showDynTopControls = supportsDyn
            && (hasDynRange || ! bp.dynAutoThresh || expandedDynamicsBand == attachedBandIndex);
        clearDynamicsButton.setVisible (showDynTopControls);
        bypassDynamicsButton.setVisible (showDynTopControls);
        autoThresholdButton.setVisible (supportsDyn);

        const bool showManualThreshControls = showDynTopControls && ! bp.dynAutoThresh;
        manualThresholdSlider.setVisible (showManualThreshControls);
        manualThresholdValue.setVisible (showManualThreshControls);
        if (showManualThreshControls && ! manualThresholdValue.isBeingEdited())
        {
            const auto text = juce::String (bp.dynThresholdDb, 1) + " dB";
            if (manualThresholdValue.getText() != text)
                manualThresholdValue.setText (text, juce::dontSendNotification);
        }
        externalSidechainButton.setVisible (showManualThreshControls);
    }
    else
    {
        clearDynamicsButton.setVisible (false);
        bypassDynamicsButton.setVisible (false);
        autoThresholdButton.setVisible (false);
        manualThresholdSlider.setVisible (false);
        manualThresholdValue.setVisible (false);
        externalSidechainButton.setVisible (false);
    }

}

void ProQ3AudioProcessorEditor::stepSelectedBand (int delta)
{
    std::vector<int> activeBands;
    for (int i = 0; i < ProQ3AudioProcessor::kMaxBands; ++i)
    {
        if (audioProcessor.getBandParameters (i).used)
            activeBands.push_back (i);
    }

    if (activeBands.empty())
        return;

    std::sort (activeBands.begin(), activeBands.end(), [this] (int a, int b)
    {
        return audioProcessor.getBandParameters (a).freqHz < audioProcessor.getBandParameters (b).freqHz;
    });

    int curPos = 0;
    for (size_t i = 0; i < activeBands.size(); ++i)
    {
        if (activeBands[i] == attachedBandIndex)
        {
            curPos = static_cast<int> (i);
            break;
        }
    }

    const int n = static_cast<int> (activeBands.size());
    const int nextPos = ((curPos + delta) % n + n) % n;
    attachFloatingControlsToBand (activeBands[static_cast<size_t> (nextPos)]);
    repaint();
}

int ProQ3AudioProcessorEditor::findBandNodeAtPosition (juce::Point<float> pos, float maxRadiusPx) const noexcept
{
    int bestBand = -1;
    float bestDistSq = maxRadiusPx * maxRadiusPx;

    for (int i = 0; i < ProQ3AudioProcessor::kMaxBands; ++i)
    {
        const auto bp = audioProcessor.getBandParameters (i);
        if (! bp.used)
            continue;

        const float nx = frequencyToX (bp.freqHz);
        const float ny = gainDbToY (bp.gainDb);
        const float d2 = pos.getDistanceSquaredFrom ({ nx, ny });

        if (d2 <= bestDistSq)
        {
            bestDistSq = d2;
            bestBand = i;
        }
    }
    return bestBand;
}

//==============================================================================
// Eventos de Mouse e Teclado (incluindo Alt + Roda para Dynamic Range, Make Dynamic e Invert Gain)
//==============================================================================
void ProQ3AudioProcessorEditor::mouseEnter (const juce::MouseEvent& event)
{
    if (event.eventComponent == &outputControlButton)
        showOutputPanel();
    else if (event.eventComponent == this)
        mouseMove (event);
}

void ProQ3AudioProcessorEditor::mouseExit (const juce::MouseEvent& event)
{
    spectrumGrabPointerInGraph = false;
    spectrumGrabHoverSince = 0.0;
    if (isOverBandTooltip (event.getEventRelativeTo (this).getPosition()))
        return;

    hoveredBandIndex = -1;
    updateBandShortcuts();
    repaint (graphBounds);
}

void ProQ3AudioProcessorEditor::mouseMove (const juce::MouseEvent& event)
{
    const auto position = event.getEventRelativeTo (this).position;
    lastMousePos = position;
    spectrumGrabPointer = position.roundToInt();
    spectrumGrabPointerInGraph = event.eventComponent == this
        && graphBounds.withTrimmedBottom (22).contains (spectrumGrabPointer);

    auto hit = findBandNodeAtPosition (position, 14.0f);
    if (hit < 0 && isOverBandTooltip (position.roundToInt()))
        hit = hoveredBandIndex;
    if (hit != hoveredBandIndex)
    {
        hoveredBandIndex = hit;
        updateBandShortcuts();
        repaint (graphBounds);
    }
    else if (graphBounds.contains (event.getPosition()) || pianoBounds.contains (event.getPosition()))
    {
        repaint();
    }
}

void ProQ3AudioProcessorEditor::mouseDown (const juce::MouseEvent& event)
{
    if (event.eventComponent == &bandDynamicsShortcut)
        return;

    lastMousePos = event.position;

    if (pianoBounds.contains (event.getPosition())
        && audioProcessor.apvts.getRawParameterValue ("piano_display")->load() >= 0.5f)
    {
        const int sel = audioProcessor.getSelectedBandIndex();
        if (sel >= 0 && audioProcessor.getBandParameters (sel).used)
        {
            const double clickedFreq = snapFrequencyToNearestSemitone (xToFrequency (event.position.x));
            if (auto* pf = audioProcessor.apvts.getParameter (ProQ3AudioProcessor::getBandParamID (sel, "freq")))
                pf->setValueNotifyingHost (pf->convertTo0to1 (static_cast<float> (clickedFreq)));
            repaint();
        }
        return;
    }

    if (! graphBounds.contains (event.getPosition()) || event.getNumberOfClicks() > 1)
        return;

    if (event.mods.isLeftButtonDown() && isOverFrequencyStrip (event.getPosition()))
    {
        draggingFrequencyView = true;
        dragStartMousePos = event.position;
        dragStartViewSpan = frequencyViewSpan;
        dragStartViewAnchor = std::log (xToFrequency (event.position.x) / kMinFreqHz) / std::log (kMaxFreqHz / kMinFreqHz);
        return;
    }

    if (spectrumGrabActive && event.mods.isLeftButtonDown() && grabSpectrumPeak (event.position))
        return;

    spectrumPeakHoverActive = false;
    spectrumGrabHoverSince = 0.0;

    if (! spectrumGrabActive && ! event.mods.isPopupMenu() && event.mods.isLeftButtonDown()
        && ! event.mods.isAltDown() && ! event.mods.isCtrlDown() && ! event.mods.isCommandDown())
    {
        bool empty = true;
        for (int band = 0; band < ProQ3AudioProcessor::kMaxBands; ++band)
            if (audioProcessor.getBandParameters (band).used)
                empty = false;
        if (eqSketchButton.getToggleState() || (empty && std::abs (event.position.y - gainDbToY (0.0)) > 7.0f))
        {
            sketching = true;
            sketchPoints.clear();
            extendEqSketch (event.position);
            return;
        }
    }

    // Verifica primeiro se clicou no indicador de Dynamic Range acima/abaixo do nó da banda selecionada (Manual p. 7 & p. 13)
    const int sel = audioProcessor.getSelectedBandIndex();
    if (sel >= 0 && audioProcessor.getBandParameters (sel).used)
    {
        const auto bp = audioProcessor.getBandParameters (sel);
        if (ProQ3AudioProcessor::doesShapeSupportDynamics (bp.shape) && std::abs (bp.dynRangeDb) > 0.05)
        {
            const float nx = frequencyToX (bp.freqHz);
            const float dynY = gainDbToY (bp.gainDb + bp.dynRangeDb);
            if (event.position.getDistanceFrom ({ nx, dynY }) <= 10.0f)
            {
                draggingBandIndex = sel;
                isDraggingDynHandle = true;
                dragStartMousePos = event.position;
                dragStartDynRangeDb = bp.dynRangeDb;
                audioProcessor.undoManager.beginNewTransaction ("Drag Dynamic Range Handle");
                return;
            }
        }
    }

    const int hitBand = findBandNodeAtPosition (event.position, 15.0f);

    if (hitBand >= 0)
    {
        const auto bp = audioProcessor.getBandParameters (hitBand);

        // Alt-click toggles band bypass.
        if (event.mods.isAltDown() && event.mods.isLeftButtonDown())
        {
            audioProcessor.undoManager.beginNewTransaction ("Toggle Band Bypass");
            if (auto* pe = audioProcessor.apvts.getParameter (ProQ3AudioProcessor::getBandParamID (hitBand, "enabled")))
                pe->setValueNotifyingHost (bp.enabled ? 0.0f : 1.0f);
            attachFloatingControlsToBand (hitBand);
            repaint();
            return;
        }

        if (event.mods.isPopupMenu())
        {
            attachFloatingControlsToBand (hitBand);
            showBandOptions (hitBand);
            return;
        }

        attachFloatingControlsToBand (hitBand);
        draggingBandIndex   = hitBand;
        isDraggingNode      = true;
        dragStartMousePos   = event.position;
        dragStartFreqHz     = bp.freqHz;
        dragStartGainDb     = bp.gainDb;
        dragStartDynRangeDb = bp.dynRangeDb;
        dragStartQ          = bp.q;

        audioProcessor.undoManager.beginNewTransaction ("Drag EQ Band " + juce::String (hitBand + 1));
        repaint();
        return;
    }

    if (event.mods.isPopupMenu())
    {
        showBandOptions (-1);
        return;
    }

    // Alt + clique/arraste ou Ctrl + clique cria uma banda (com Alt cria banda já dinâmica, Manual p. 1 & p. 7)
    if (event.mods.isCtrlDown() || event.mods.isCommandDown() || event.mods.isAltDown())
    {
        const float freq = static_cast<float> (xToFrequency (event.position.x));
        const float gain = static_cast<float> (yToGainDb (event.position.y));
        const float initGain = event.mods.isAltDown() ? 0.0f : gain;
        const float initDyn  = event.mods.isAltDown() ? gain : 0.0f;

        ProQ3AudioProcessor::BandParameters band;
        band.freqHz = freq;
        band.gainDb = initGain;
        band.dynRangeDb = initDyn;
        band.spectral = event.mods.isAltDown() && event.mods.isShiftDown();
        if (band.spectral && std::abs (band.dynRangeDb) < 0.05)
            band.dynRangeDb = -6.0;
        const int newIdx = audioProcessor.activateFirstFreeBand (band);
        if (newIdx >= 0)
        {
            attachFloatingControlsToBand (newIdx);
            draggingBandIndex = newIdx;
            isDraggingNode    = true;
            dragStartMousePos = event.position;
            dragStartFreqHz   = freq;
            dragStartGainDb   = initGain;
            dragStartQ        = 1.0;
            repaint();
        }
        return;
    }

    const double cursorFreq = xToFrequency (event.position.x);
    const double curveDbAtCursor = audioProcessor.getTotalMagnitudeDbAtFrequency (cursorFreq, false);
    const float curveY = gainDbToY (curveDbAtCursor);

    if (event.mods.isLeftButtonDown() && std::abs (event.position.y - curveY) <= 7.0f)
    {
        if (graphEdgeFilterShape (event.position.x, graphBounds) != ProQ3AudioProcessor::kShapeBell)
        {
            waitingForEdgeDrag = true;
            dragStartMousePos = event.position;
            return;
        }

        if (startNewCurveBandDrag (event.position))
            return;
    }

    isSelectionRectDragging = true;
    dragStartMousePos = event.position;
    selectionLassoRect = {};
    repaint();
}

bool ProQ3AudioProcessorEditor::grabSpectrumPeak (juce::Point<float> position)
{
    if (! spectrumGrabActive || ! analyzerPanel.grab.getToggleState())
        return false;
    for (size_t i = 0; i < peakTags.size(); ++i)
    {
        if (peakTags[i].isEmpty() || ! peakTags[i].expanded (4.0f, 5.0f).contains (position))
            continue;

        constexpr float initialGain = -3.0f;
        const auto frequency = static_cast<float> (peakTagFrequencies[i]);
        const auto band = audioProcessor.activateFirstFreeBand (frequency, initialGain, 2.0f);
        if (band < 0)
            return false;

        attachFloatingControlsToBand (band);
        draggingBandIndex = band;
        isDraggingNode = true;
        draggingSpectrumPeak = true;
        dragStartMousePos = position;
        dragStartFreqHz = frequency;
        dragStartGainDb = initialGain;
        dragStartQ = 2.0;
        repaint (graphBounds);
        return true;
    }
    return false;
}

bool ProQ3AudioProcessorEditor::startNewCurveBandDrag (juce::Point<float> position)
{
    const auto frequency = static_cast<float> (xToFrequency (position.x));
    const auto gain = static_cast<float> (yToGainDb (position.y));
    const int bandIndex = audioProcessor.activateFirstFreeBand (frequency, gain);
    if (bandIndex < 0)
        return false;

    attachFloatingControlsToBand (bandIndex);
    draggingBandIndex = bandIndex;
    isDraggingNode = true;
    dragStartMousePos = position;
    dragStartFreqHz = frequency;
    dragStartGainDb = gain;
    dragStartQ = 1.0;
    repaint (graphBounds);
    return true;
}

void ProQ3AudioProcessorEditor::mouseDrag (const juce::MouseEvent& event)
{
    if (event.eventComponent == &bandDynamicsShortcut)
        return;

    lastMousePos = event.position;

    if (sketching)
    {
        extendEqSketch (event.position);
        return;
    }

    if (draggingFrequencyView)
    {
        const auto width = static_cast<double> (graphBounds.getWidth());
        const auto anchorPosition = (static_cast<double> (dragStartMousePos.x) - graphBounds.getX()) / width;
        const auto delta = (event.position.x - dragStartMousePos.x) / width;
        const auto zoom = dragStartViewSpan * std::exp ((event.position.y - dragStartMousePos.y) * 0.015);
        updateFrequencyView (dragStartViewAnchor, zoom, anchorPosition + delta);
        return;
    }

    if (waitingForEdgeDrag)
    {
        if (event.position.getDistanceSquaredFrom (dragStartMousePos) < 16.0f)
            return;

        waitingForEdgeDrag = false;
        startNewCurveBandDrag (dragStartMousePos);
    }

    if (isDraggingDynHandle && draggingBandIndex >= 0)
    {
        const auto bp = audioProcessor.getBandParameters (draggingBandIndex);
        const double targetTotalDb = yToGainDb (event.position.y);
        const double newDynRange = juce::jlimit (-30.0, 30.0, targetTotalDb - bp.gainDb);
        if (auto* pd = audioProcessor.apvts.getParameter (ProQ3AudioProcessor::getBandParamID (draggingBandIndex, "dyn_range")))
            pd->setValueNotifyingHost (pd->convertTo0to1 (static_cast<float> (newDynRange)));
        repaint (graphBounds);
        return;
    }

    if (isDraggingNode && draggingBandIndex >= 0 && draggingBandIndex < ProQ3AudioProcessor::kMaxBands)
    {
        const float sensitivity = event.mods.isShiftDown() ? 0.2f : 1.0f;
        const float dx = (event.position.x - dragStartMousePos.x) * sensitivity;
        const float dy = (event.position.y - dragStartMousePos.y) * sensitivity;

        if (event.mods.isCtrlDown() || event.mods.isCommandDown())
        {
            const double qFactor = std::pow (2.0, static_cast<double> (-dy) / 75.0);
            const double newQ = juce::jlimit (0.025, 40.0, dragStartQ * qFactor);
            if (auto* pq = audioProcessor.apvts.getParameter (ProQ3AudioProcessor::getBandParamID (draggingBandIndex, "q")))
                pq->setValueNotifyingHost (pq->convertTo0to1 (static_cast<float> (newQ)));
        }
        else
        {
            bool lockHorizontal = false;
            bool lockVertical   = false;
            if (event.mods.isAltDown())
            {
                if (std::abs (dx) >= std::abs (dy))
                    lockVertical = true;
                else
                    lockHorizontal = true;
            }

            if (! lockHorizontal)
            {
                const float startX = frequencyToX (dragStartFreqHz);
                const double newFreq = xToFrequency (startX + dx);
                if (auto* pf = audioProcessor.apvts.getParameter (ProQ3AudioProcessor::getBandParamID (draggingBandIndex, "freq")))
                    pf->setValueNotifyingHost (pf->convertTo0to1 (static_cast<float> (newFreq)));
                layoutBandControls();
            }

            if (! lockVertical && ProQ3AudioProcessor::doesShapeSupportGain (audioProcessor.getBandParameters (draggingBandIndex).shape))
            {
                const float startY = gainDbToY (dragStartGainDb);
                const double newGain = juce::jlimit (-30.0, 30.0, yToGainDb (startY + dy));
                if (auto* pg = audioProcessor.apvts.getParameter (ProQ3AudioProcessor::getBandParamID (draggingBandIndex, "gain")))
                    pg->setValueNotifyingHost (pg->convertTo0to1 (static_cast<float> (newGain)));
            }
        }

        repaint (graphBounds);
        return;
    }

    if (isSelectionRectDragging)
    {
        selectionLassoRect = juce::Rectangle<float> (dragStartMousePos, event.position);
        for (int i = 0; i < ProQ3AudioProcessor::kMaxBands; ++i)
        {
            const auto bp = audioProcessor.getBandParameters (i);
            if (! bp.used)
                continue;
            const juce::Point<float> pt (frequencyToX (bp.freqHz), gainDbToY (bp.gainDb));
            if (selectionLassoRect.contains (pt))
            {
                attachFloatingControlsToBand (i);
                break;
            }
        }
        repaint (graphBounds);
    }
}

void ProQ3AudioProcessorEditor::mouseUp (const juce::MouseEvent& event)
{
    if (event.eventComponent == &bandDynamicsShortcut)
        return;

    if (sketching)
    {
        extendEqSketch (event.position);
        finishEqSketch (true);
        return;
    }

    if (draggingSpectrumPeak)
    {
        draggingSpectrumPeak = false;
        finishSpectrumGrab();
    }
    draggingFrequencyView = false;
    waitingForEdgeDrag = false;
    isDraggingNode = false;
    isDraggingDynHandle = false;
    draggingBandIndex = -1;
    if (isSelectionRectDragging)
    {
        isSelectionRectDragging = false;
        selectionLassoRect = {};
        repaint();
    }
}

void ProQ3AudioProcessorEditor::mouseDoubleClick (const juce::MouseEvent& event)
{
    if (event.eventComponent == &bandDynamicsShortcut)
        return;

    if (! graphBounds.contains (event.getPosition()) || event.mods.isPopupMenu())
        return;
    if (isOverFrequencyStrip (event.getPosition()))
    {
        updateFrequencyView (0.0, 1.0, 0.0);
        return;
    }
    if (spectrumGrabActive
        && std::any_of (peakTags.begin(), peakTags.end(), [&] (const auto& tag)
                        { return ! tag.isEmpty() && tag.expanded (4.0f, 5.0f).contains (event.position); }))
        return;

    const int hitBand = findBandNodeAtPosition (event.position, 15.0f);
    if (hitBand >= 0)
    {
        attachFloatingControlsToBand (hitBand);
        freqTitleLabel.showEditor();
        return;
    }

    auto suggestion = suggestBand (event.position);
    if (event.mods.isAltDown() && event.mods.isShiftDown())
    {
        suggestion.spectral = true;
        suggestion.shape = ProQ3AudioProcessor::kShapeBell;
        const auto gain = yToGainDb (event.position.y);
        suggestion.dynRangeDb = std::abs (gain) < 0.05 ? -6.0 : gain;
        suggestion.gainDb = 0.0;
    }
    else if (event.mods.isAltDown() && suggestion.shape == ProQ3AudioProcessor::kShapeBell)
    {
        suggestion.dynRangeDb = suggestion.gainDb;
        suggestion.gainDb = 0.0;
    }
    const int newIdx = audioProcessor.activateFirstFreeBand (suggestion);
    if (newIdx >= 0)
    {
        attachFloatingControlsToBand (newIdx);
        repaint();
    }
}

void ProQ3AudioProcessorEditor::mouseWheelMove (const juce::MouseEvent& event, const juce::MouseWheelDetails& wheel)
{
    if (event.eventComponent == &bandDynamicsShortcut)
        return;

    if (! graphBounds.contains (event.getPosition()))
        return;

    if (isOverFrequencyStrip (event.getPosition()))
    {
        const auto position = (static_cast<double> (event.position.x) - graphBounds.getX()) / graphBounds.getWidth();
        const auto anchor = frequencyViewStart + position * frequencyViewSpan;
        updateFrequencyView (anchor, frequencyViewSpan * std::exp (-wheel.deltaY * 1.7), position);
        return;
    }

    int targetBand = findBandNodeAtPosition (event.position, 28.0f);
    if (targetBand < 0)
        targetBand = audioProcessor.getSelectedBandIndex();

    if (targetBand >= 0 && targetBand < ProQ3AudioProcessor::kMaxBands)
    {
        const auto bp = audioProcessor.getBandParameters (targetBand);
        if (! bp.used)
            return;

        // Manual Pro-Q 3 p. 7 & p. 13:
        // "Move the mouse wheel while holding down Alt to adjust the dynamic range setting"
        // "Hold both Alt and Ctrl to perform a linked change, trading gain for dynamic range"
        if (event.mods.isAltDown())
        {
            if (! ProQ3AudioProcessor::doesShapeSupportDynamics (bp.shape))
                return;

            const double deltaDb = static_cast<double> (wheel.deltaY) * (event.mods.isShiftDown() ? 0.8 : 3.0);
            const double newDyn = juce::jlimit (-30.0, 30.0, bp.dynRangeDb + deltaDb);
            if (auto* pd = audioProcessor.apvts.getParameter (ProQ3AudioProcessor::getBandParamID (targetBand, "dyn_range")))
                pd->setValueNotifyingHost (pd->convertTo0to1 (static_cast<float> (newDyn)));

            if (event.mods.isCtrlDown() || event.mods.isCommandDown())
            {
                const double newGain = juce::jlimit (-30.0, 30.0, bp.gainDb - deltaDb);
                if (auto* pg = audioProcessor.apvts.getParameter (ProQ3AudioProcessor::getBandParamID (targetBand, "gain")))
                    pg->setValueNotifyingHost (pg->convertTo0to1 (static_cast<float> (newGain)));
            }

            updateFloatingControlsVisibilityAndValues();
            repaint();
            return;
        }

        // Ctrl + roda do mouse ajusta o ganho estático (Manual p. 7)
        if (event.mods.isCtrlDown() || event.mods.isCommandDown())
        {
            const double deltaDb = static_cast<double> (wheel.deltaY) * (event.mods.isShiftDown() ? 0.5 : 2.0);
            const double newGain = juce::jlimit (-30.0, 30.0, bp.gainDb + deltaDb);
            if (auto* pg = audioProcessor.apvts.getParameter (ProQ3AudioProcessor::getBandParamID (targetBand, "gain")))
                pg->setValueNotifyingHost (pg->convertTo0to1 (static_cast<float> (newGain)));
            repaint();
            return;
        }

        // Roda do mouse padrão ajusta o Q
        const double step = event.mods.isShiftDown() ? 0.04 : 0.16;
        const double factor = std::pow (2.0, static_cast<double> (wheel.deltaY) * step * 4.0);
        const double newQ = juce::jlimit (0.025, 40.0, bp.q * factor);

        if (auto* pq = audioProcessor.apvts.getParameter (ProQ3AudioProcessor::getBandParamID (targetBand, "q")))
            pq->setValueNotifyingHost (pq->convertTo0to1 (static_cast<float> (newQ)));

        repaint();
    }
}

bool ProQ3AudioProcessorEditor::keyPressed (const juce::KeyPress& key)
{
    if (key == juce::KeyPress::escapeKey && instanceOverview.isVisible())
    {
        setInstanceOverviewOpen (false);
        return true;
    }
    if (key == juce::KeyPress::escapeKey && heldSoloButton != nullptr)
    {
        stopBandSolo();
        return true;
    }

    if (key == juce::KeyPress::escapeKey && matchPanel.isVisible())
    {
        closeMatchPanel();
        return true;
    }

    if (key == juce::KeyPress::escapeKey && analyzerPanel.isVisible())
    {
        if (analyzerPanel.settings.isVisible())
        {
            analyzerPanel.settingsButton.setToggleState (false, juce::dontSendNotification);
            analyzerPanel.settings.setVisible (false);
            layoutAnalyzerPanel();
        }
        else
        {
            dismissAnalyzerPanel();
        }
        return true;
    }

    if (key == juce::KeyPress::escapeKey && outputPanel.isVisible())
    {
        outputPanelKeyboardAccess = false;
        outputPanel.setVisible (false);
        return true;
    }

    if (key == juce::KeyPress::escapeKey && (sketching || eqSketchButton.getToggleState()))
    {
        eqSketchButton.setToggleState (false, juce::dontSendNotification);
        finishEqSketch (false);
        return true;
    }

    if (key == juce::KeyPress::escapeKey && shapeQuickBand >= 0)
    {
        shapeQuickBand = -1;
        updateBandShortcuts();
        repaint (graphBounds);
        return true;
    }

    if (key == juce::KeyPress::escapeKey && spectrumGrabActive)
    {
        finishSpectrumGrab();
        return true;
    }

    if (key == juce::KeyPress::deleteKey || key == juce::KeyPress::backspaceKey)
    {
        const int sel = audioProcessor.getSelectedBandIndex();
        if (sel >= 0 && audioProcessor.getBandParameters (sel).used)
        {
            audioProcessor.deactivateBand (sel);
            attachFloatingControlsToBand (audioProcessor.getSelectedBandIndex());
            repaint();
            return true;
        }
    }
    return false;
}

//==============================================================================
// Timer de 60 FPS
//==============================================================================
void ProQ3AudioProcessorEditor::timerCallback()
{
    updateOutputPanelVisibility();
    bool needsRepaint = false;

    const auto now = juce::Time::getMillisecondCounterHiRes();
    updateInstanceOverview (now);
    if (! instanceOverview.isVisible())
        updateAnalyzerHover (now);
    const auto elapsed = lastSpectrumFrameMs == 0.0 ? 1.0 / 60.0
        : juce::jlimit (0.0, 0.15, (now - lastSpectrumFrameMs) * 0.001);
    lastSpectrumFrameMs = now;

    const auto isOn = [this] (const char* id)
    {
        return audioProcessor.apvts.getRawParameterValue (id)->load() >= 0.5f;
    };
    auto source = SpectrumSource::none;
    if (isOn ("analyzer_peak_alerts") || analyzerPanel.grab.getToggleState())
    {
        if (isOn ("analyzer_post"))     source = SpectrumSource::post;
        else if (isOn ("analyzer_pre")) source = SpectrumSource::pre;
        else if (isOn ("analyzer_sc") && isOn ("analyzer_peak_alerts"))
            source = SpectrumSource::sidechain;
    }

    const auto sampleRate = audioProcessor.getCurrentSampleRate();
    if ((analyzerPanel.isVisible() || analyzerExternalId > 0) && now - lastAnalyzerRefreshMs >= 240.0)
    {
        lastAnalyzerRefreshMs = now;
        refreshAnalyzerPanel();
    }
    if (source != peakSource || ! juce::approximatelyEqual (sampleRate, peakSampleRate))
    {
        finishSpectrumGrab();
        spectrumPeaks.fill ({});
        peakSource = source;
        peakSampleRate = sampleRate;
        needsRepaint = true;
    }
    updateSpectrumGrab (now);
    const bool frozen = analyzerPanel.freeze.getToggleState() || spectrumGrabActive;
    updateExternalSpectrum (frozen);
    for (auto& peak : spectrumPeaks)
    {
        if (! frozen && peak.frequency > 0.0 && now - peak.lastSeen >= kPeakHoldMs)
        {
            peak = {};
            needsRepaint = true;
        }
    }

    bool receivedSpectrum = false;
    const auto updateSpectrum = [&] (auto pull, std::vector<float>& display, SpectrumSource stream)
    {
        if (pull (rawSpectrumDb))
        {
            if (matchPanel.isVisible() && stream != SpectrumSource::post)
                updateMatchCapture (rawSpectrumDb, sampleRate, stream == SpectrumSource::sidechain);
            if (frozen)
                return;
            if (source == stream)
                updateSpectrumPeaks (now);
            if (display.size() != rawSpectrumDb.size())
                display = rawSpectrumDb;
            else
            {
                const auto speed = analyzerPanel.speed.getSelectedId();
                const auto falloff = speed == 1 ? 20.0 : speed == 3 ? 72.0 : 38.0;
                for (size_t i = 0; i < display.size(); ++i)
                    display[i] = juce::jmax (rawSpectrumDb[i], display[i] - static_cast<float> (falloff * elapsed));
            }
            receivedSpectrum = true;
            needsRepaint = true;
        }
        else if (! frozen && ! display.empty() && now - spectrumIdleMs > 120.0)
        {
            for (auto& db : display)
                db = juce::jmax (-160.0f, db - static_cast<float> (55.0 * elapsed));
            if (*std::max_element (display.begin(), display.end()) <= -105.0f)
                display.clear();
            needsRepaint = true;
        }
    };
    updateSpectrum ([this] (auto& data) { return audioProcessor.pullNextSidechainFftBlock (data); },
                    smoothedSidechainSpectrumDb, SpectrumSource::sidechain);
    updateSpectrum ([this] (auto& data) { return audioProcessor.pullNextPreFftBlock (data); },
                    smoothedPreSpectrumDb, SpectrumSource::pre);
    updateSpectrum ([this] (auto& data) { return audioProcessor.readPostSpectrum (seenPostSpectrum, data); },
                    smoothedPostSpectrumDb, SpectrumSource::post);
    if (receivedSpectrum)
        spectrumIdleMs = now;
    updateSourcePreviews (now, frozen);
    if (matchPanel.isVisible())
        refreshMatchControls();

    // Latch the detector and the applied gain together for the entire UI frame.
    for (size_t band = 0; band < bandDynamics.size(); ++band)
    {
        const auto current = audioProcessor.getBandDynamicsReading (static_cast<int> (band));
        const auto& previous = bandDynamics[band];
        needsRepaint |= current.gainDb != previous.gainDb
            || (manualThresholdSlider.isVisible() && static_cast<int> (band) == attachedBandIndex
                && current.detectorDb != previous.detectorDb);
        bandDynamics[band] = current;
    }

    const int procSelected = audioProcessor.getSelectedBandIndex();
    if (procSelected != attachedBandIndex)
        attachFloatingControlsToBand (procSelected);

    updateFloatingControlsVisibilityAndValues();
    if (attachedBandIndex >= 0)
    {
        const auto oldPanel = floatingPillBounds;
        layoutBandControls();
        if (oldPanel != floatingPillBounds)
            needsRepaint = true;
    }
    if (heldSoloButton != nullptr
        && (! heldSoloButton->isShowing() || ! juce::Component::isMouseButtonDownAnywhere()
            || audioProcessor.getSoloBandIndex() != soloControlBand
            || ! audioProcessor.getBandParameters (soloControlBand).used
            || isOn ("global_bypass")))
        stopBandSolo();
    soloBandButton.setEnabled (! isOn ("global_bypass"));
    updateBandShortcuts();
    refreshStatusControls();

    undoButton.setEnabled (audioProcessor.undoManager.canUndo());
    redoButton.setEnabled (audioProcessor.undoManager.canRedo());

    if (needsRepaint || manualThresholdSlider.isVisible())
        repaint (graphBounds);
    repaint (meterBounds);
}

void ProQ3AudioProcessorEditor::finishSpectrumGrab()
{
    const bool wasVisible = spectrumGrabActive || spectrumPeakHoverActive;
    spectrumGrabActive = false;
    spectrumPeakHoverActive = false;
    spectrumGrabHoverSince = 0.0;
    peakTags.fill ({});

    if (wasVisible)
    {
        updateFloatingControlsVisibilityAndValues();
        repaint (graphBounds);
    }
}

void ProQ3AudioProcessorEditor::updateSpectrumGrab (double now)
{
    // Once captured, the trace belongs to this gesture. Moving away from the hover
    // point, across nodes, or outside the graph must not discard it.
    if (spectrumGrabActive)
        return;

    const bool internal = peakSource == SpectrumSource::pre || peakSource == SpectrumSource::post;
    const bool grab = internal && analyzerPanel.grab.getToggleState();
    const bool labels = audioProcessor.apvts.getRawParameterValue ("analyzer_peak_alerts")->load() >= 0.5f;
    bool overSpectrum = false;
    if ((grab || labels) && peakSource != SpectrumSource::none
        && spectrumGrabPointerInGraph && hoveredBandIndex < 0 && heldSoloButton == nullptr
        && ! analyzerPanel.isVisible() && ! matchPanel.isVisible() && ! outputPanel.isVisible()
        && ! instanceOverview.isVisible() && ! showHelpOverlay
        && ! isDraggingNode && ! isDraggingDynHandle && ! isSelectionRectDragging && ! draggingFrequencyView
        && ! waitingForEdgeDrag && ! sketching && ! eqSketchButton.getToggleState()
        && (spectrumPeakHoverActive || now - spectrumIdleMs <= 250.0 || analyzerPanel.freeze.getToggleState()))
    {
        const auto& trace = peakSource == SpectrumSource::post ? smoothedPostSpectrumDb
                          : peakSource == SpectrumSource::pre ? smoothedPreSpectrumDb : smoothedSidechainSpectrumDb;
        const auto traceY = analyzerDbToY (spectrumLevelAtX (trace, peakSampleRate,
                                                             static_cast<float> (spectrumGrabPointer.x)));
        overSpectrum = traceY < static_cast<float> (graphBounds.getBottom() - 26)
            && static_cast<float> (spectrumGrabPointer.y) >= traceY - 15.0f;
    }

    if (! overSpectrum)
    {
        finishSpectrumGrab();
        return;
    }

    if (spectrumPeakHoverActive)
        return;

    if (spectrumGrabHoverSince <= 0.0 || spectrumGrabPointer.getDistanceSquaredFrom (spectrumGrabHoverAnchor) > 9)
    {
        spectrumGrabHoverAnchor = spectrumGrabPointer;
        spectrumGrabHoverSince = now;
        return;
    }

    if (now - spectrumGrabHoverSince >= 2000.0
        && std::any_of (spectrumPeaks.begin(), spectrumPeaks.end(), [now] (const auto& peak)
            { return peak.frequency > 0.0 && now - peak.lastSeen <= kPeakHoldMs
                && peak.lastSeen - peak.firstSeen >= peakConfirmationMs; }))
    {
        spectrumGrabActive = grab;
        spectrumPeakHoverActive = ! grab;
        updateFloatingControlsVisibilityAndValues();
        repaint (graphBounds);
    }
}

void ProQ3AudioProcessorEditor::updateSpectrumPeaks (double now)
{
    if (rawSpectrumDb.size() < 12)
        return;

    if (peakSpectrumBins != rawSpectrumDb.size())
    {
        peakSpectrumBins = rawSpectrumDb.size();
        spectrumPeaks.fill ({});
    }
    const auto binWidth = peakSampleRate / (2.0 * static_cast<double> (rawSpectrumDb.size() - 1));
    const auto last = static_cast<int> (rawSpectrumDb.size()) - 1;
    const auto read = [this] (int bin) { return rawSpectrumDb[static_cast<size_t> (bin)]; };
    const auto highest = *std::max_element (rawSpectrumDb.begin() + 1, rawSpectrumDb.end() - 1);

    struct Candidate { double frequency; float level; float score; };
    std::vector<Candidate> candidates;

    for (int bin = 2; bin < last - 1; ++bin)
    {
        const auto hz = bin * binWidth;
        if (hz < 45.0 || hz > 20000.0)
            continue;

        const auto level = read (bin);
        if (level < highest - 28.0f || level - ProQ3AudioProcessor::spectrumTiltDb (hz) < -52.0f
            || level <= read (bin - 1) || level <= read (bin + 1))
            continue;

        // Compare both shoulders of the peak, scaling the neighbourhood with frequency.
        const auto offset = juce::jmax (4, juce::roundToInt (bin * 0.105));
        const auto left = juce::jmax (1, bin - offset);
        const auto right = juce::jmin (last - 1, bin + offset);
        if (bin - left < 3 || right - bin < 3)
            continue;

        const auto shoulder = juce::jmax ((read (left) + read (left + 1) + read (left + 2)) / 3.0f,
                                          (read (right - 2) + read (right - 1) + read (right)) / 3.0f);
        const auto prominence = level - shoulder;
        if (prominence < 7.0f)
            continue;

        // Interpolate the summit between FFT bins for a steadier frequency label.
        const auto previous = read (bin - 1);
        const auto next = read (bin + 1);
        const auto shift = 0.5f * (previous - next) / (previous - 2.0f * level + next);
        candidates.push_back ({ (bin + static_cast<double> (shift)) * binWidth,
                                level, level + 0.4f * juce::jmin (prominence, 22.0f) });
    }

    std::sort (candidates.begin(), candidates.end(),
               [] (const auto& a, const auto& b) { return a.score > b.score; });

    std::array<double, 5> accepted {};
    size_t count = 0;
    for (const auto& candidate : candidates)
    {
        const auto nearAccepted = [&] (double frequency)
        {
            return std::abs (frequency - candidate.frequency) <= juce::jmax (2.0 * binWidth, candidate.frequency * 0.04);
        };
        if (std::any_of (accepted.begin(), accepted.begin() + static_cast<std::ptrdiff_t> (count), nearAccepted))
            continue;

        const auto matchesTrack = [&] (double frequency)
        {
            return frequency > 0.0
                && std::abs (frequency - candidate.frequency) <= juce::jmax (1.5 * binWidth, candidate.frequency * 0.012);
        };
        auto slot = std::find_if (spectrumPeaks.begin(), spectrumPeaks.end(),
                                  [&] (const auto& peak) { return matchesTrack (peak.frequency); });
        if (slot == spectrumPeaks.end())
            slot = std::min_element (spectrumPeaks.begin(), spectrumPeaks.end(),
                                     [] (const auto& a, const auto& b) { return a.lastSeen < b.lastSeen; });

        if (! matchesTrack (slot->frequency) || now - slot->lastSeen > 100.0)
            *slot = { candidate.frequency, candidate.level, now, now };
        else
        {
            slot->frequency += 0.24 * (candidate.frequency - slot->frequency);
            slot->level += 0.45f * (candidate.level - slot->level);
            slot->lastSeen = now;
        }

        accepted[count++] = candidate.frequency;
        if (count == accepted.size())
            break;
    }
}

void ProQ3AudioProcessorEditor::drawSpectrumPeaks (juce::Graphics& g)
{
    peakTags.fill ({});
    if (! spectrumGrabActive && ! spectrumPeakHoverActive)
        return;

    const juce::Graphics::ScopedSaveState saved (g);
    g.reduceClipRegion (graphBounds);
    g.setFont (juce::FontOptions (11.0f, juce::Font::bold));
    const auto usable = graphBounds.reduced (9, 5).withTrimmedRight (43).toFloat();
    std::array<juce::Rectangle<float>, 5> labels {};
    const auto& trace = peakSource == SpectrumSource::post ? smoothedPostSpectrumDb
                      : peakSource == SpectrumSource::pre ? smoothedPreSpectrumDb : smoothedSidechainSpectrumDb;
    size_t count = 0;
    for (const auto& peak : spectrumPeaks)
    {
        if (peak.frequency <= 0.0 || peak.lastSeen - peak.firstSeen < peakConfirmationMs)
            continue;

        const auto x = frequencyToX (peak.frequency);
        if (x < static_cast<float> (graphBounds.getX()) || x > static_cast<float> (graphBounds.getRight()))
            continue;
        // Follow the displayed trace, including its smoothing, at the analyzed peak frequency.
        const auto left = static_cast<float> (graphBounds.getX() + 2 * static_cast<int> ((x - static_cast<float> (graphBounds.getX())) * 0.5f));
        const auto low = analyzerDbToY (spectrumLevelAtX (trace, peakSampleRate, left));
        const auto high = analyzerDbToY (spectrumLevelAtX (trace, peakSampleRate, left + 2.0f));
        const auto y = low + (high - low) * (x - left) * 0.5f;
        const bool useNotes = audioProcessor.apvts.getRawParameterValue ("piano_display")->load() >= 0.5f;
        const auto text = useNotes ? frequencyToMusicalNoteName (peak.frequency)
            : peak.frequency >= 1000.0 ? juce::String (peak.frequency * 0.001, 2) + " kHz"
                                      : juce::String (juce::roundToInt (peak.frequency)) + " Hz";
        const auto width = juce::jlimit (33.0f, 63.0f,
            juce::GlyphArrangement::getStringWidth (g.getCurrentFont(), text) + 10.0f);
        constexpr float height = 16.0f;
        auto tag = juce::Rectangle<float> (juce::jlimit (usable.getX(), usable.getRight() - width, x - width / 2.0f),
                                           juce::jmax (usable.getY(), y - 23.0f), width, height);
        const auto overlapsLabel = [&] (const auto& other) { return tag.expanded (3.0f, 1.0f).intersects (other); };
        const auto end = labels.begin() + static_cast<std::ptrdiff_t> (count);
        while (tag.getY() >= usable.getY() && std::any_of (labels.begin(), end, overlapsLabel))
            tag.translate (0.0f, -18.0f);
        if (tag.getY() < usable.getY())
            continue;

        labels[count] = tag;
        const juce::Rectangle<float> summit (x - 5.0f, y - 4.0f, 10.0f, 8.0f);
        peakTags[count] = tag.getUnion (summit);
        peakTagFrequencies[count++] = peak.frequency;
        g.setColour (kEqGold.withAlpha (0.78f));
        g.drawLine (x, y, juce::jlimit (tag.getX() + 4.0f, tag.getRight() - 4.0f, x), tag.getBottom(), 1.0f);
        g.fillEllipse (x - 2.0f, y - 2.0f, 4.0f, 4.0f);
        g.setColour (juce::Colour (0xffffd452));
        g.fillRoundedRectangle (tag, 4.0f);
        g.setColour (juce::Colour (0xff17130c));
        g.drawFittedText (text, tag.toNearestInt().reduced (2, 0), juce::Justification::centred, 1);
    }
}

//==============================================================================
// Renderização da Interface e do Painel da Banda com Crista Dinâmica ("Auto")
//==============================================================================
void ProQ3AudioProcessorEditor::paint (juce::Graphics& g)
{
    g.fillAll (kBgDark);

    const auto clip = g.getClipBounds();
    if (clip.intersects (topBarBounds))
        drawTopToolbar (g, topBarBounds);

    if (clip.intersects (graphBounds))
    {
        drawEqGridAndScales (g, graphBounds);
        drawSpectrumAnalyzer (g, graphBounds);
        drawCurvePreview (g);
        if (spectrumGrabActive)
        {
            const juce::Graphics::ScopedSaveState saved (g);
            g.reduceClipRegion (graphBounds);
            g.beginTransparencyLayer (0.26f);
            drawEqCurvesAndBandNodes (g, graphBounds);
            g.endTransparencyLayer();
        }
        else
        {
            drawEqCurvesAndBandNodes (g, graphBounds);
        }
        drawMatchSpectra (g, graphBounds);
        drawSpectrumPeaks (g);

        const int tooltipBand = heldSoloButton == &bandSoloShortcut ? soloControlBand
            : draggingBandIndex >= 0 ? draggingBandIndex : bandMenuIndex >= 0 ? bandMenuIndex : hoveredBandIndex;
        if (! spectrumGrabActive && tooltipBand >= 0 && tooltipBand < ProQ3AudioProcessor::kMaxBands)
            drawBandParameterTooltip (g, tooltipBand);

        if (audioProcessor.apvts.getRawParameterValue ("piano_display")->load() >= 0.5f)
            drawPianoRollBar (g, pianoBounds);

        if (! spectrumGrabActive)
            drawFloatingBandControlsBackground (g);
        g.setColour (kFloatingBorder.withAlpha (0.65f));
        g.drawRect (graphBounds, 1);
    }

    if (clip.intersects (meterBounds))
        drawOutputMeter (g, meterBounds);
    if (clip.intersects (bottomBarBounds))
        drawBottomToolbar (g, bottomBarBounds);

    if (showHelpOverlay)
    {
        auto helpBox = graphBounds.reduced (130, 65).toFloat();
        g.setColour (juce::Colour (0xf2181b22));
        g.fillRoundedRectangle (helpBox, 8.0f);
        g.setColour (kControlAccent);
        g.drawRoundedRectangle (helpBox, 8.0f, 1.5f);

        g.setColour (kTextBright);
        g.setFont (juce::FontOptions (15.0f, juce::Font::bold));
        g.drawText ("NX Audio Pro EQ³",
                    helpBox.removeFromTop (34.0f).toNearestInt(), juce::Justification::centred, false);

        g.setFont (juce::FontOptions (12.5f));
        g.setColour (kTextMuted);
        const juce::String helpText =
            "- GAIN Inner Knob: Adjust Static Gain (-30 to +30 dB) | Outer Ring: Independent drag for Dynamic Range (-30 to +30 dB)\n"
            "- Auto Button (top of GAIN ring): Toggle Automatic Threshold vs Manual Threshold slider + detector meter & External Sidechain (SC)\n"
            "- Power Icon near ring: Bypass Dynamics only (keeps static gain) | 'x' near ring: Clear Dynamics to 0 dB without deleting band\n"
            "- Alt + Mouse Wheel over band dot (or 'Make Dynamic' in Right-Click menu): Adjust Dynamic Range directly\n"
            "- 10 Filter Shapes: Bell, Low Shelf, Low Cut, High Shelf, High Cut, Notch, Band Pass, Tilt Shelf, Flat Tilt, All Pass (6-96 dB/oct + Brickwall)\n"
            "- Double-click the left or right edge of the graph to create a Low Cut or High Cut.\n"
            "- Double-Click FREQ label to type exact values with shortcuts: '2k' (2000 Hz), 'A4' (440 Hz), 'C#3 + 13', or '50%'";
        g.drawFittedText (helpText, helpBox.reduced (22.0f, 8.0f).toNearestInt(), juce::Justification::topLeft, 10);
    }
}

void ProQ3AudioProcessorEditor::drawTopToolbar (juce::Graphics& g, juce::Rectangle<int> bounds)
{
    juce::ColourGradient topGrad (juce::Colour (0xff25212a), 0.0f, static_cast<float> (bounds.getY()),
                                  juce::Colour (0xff18151e), 0.0f, static_cast<float> (bounds.getBottom()), false);
    g.setGradientFill (topGrad);
    g.fillRect (bounds);

    g.setColour (juce::Colour (0xff37313c));
    g.drawHorizontalLine (bounds.getBottom() - 1, static_cast<float> (bounds.getX()), static_cast<float> (bounds.getRight()));

    auto presetRail = prevPresetButton.getBounds().getUnion (nextPresetButton.getBounds()).toFloat();
    g.setColour (juce::Colour (0xff201c25));
    g.fillRoundedRectangle (presetRail, 5.0f);
    g.setColour (juce::Colour (0xff332c38));
    g.drawRoundedRectangle (presetRail.reduced (0.5f), 5.0f, 1.0f);

    const float cy = static_cast<float> (bounds.getCentreY());
    const juce::Rectangle<float> emblem (12.0f, cy - 12.0f, 39.0f, 24.0f);
    g.setColour (kEqGold.withAlpha (0.09f));
    g.fillRoundedRectangle (emblem, 6.0f);
    g.setColour (kEqGold.withAlpha (0.34f));
    g.drawRoundedRectangle (emblem, 6.0f, 1.0f);

    juce::Path mark;
    mark.startNewSubPath (18.5f, cy + 5.0f);
    mark.lineTo (18.5f, cy - 5.0f);
    mark.lineTo (28.0f, cy + 5.0f);
    mark.lineTo (28.0f, cy - 5.0f);
    mark.startNewSubPath (34.0f, cy + 5.0f);
    mark.lineTo (44.0f, cy - 5.0f);
    mark.startNewSubPath (34.0f, cy - 5.0f);
    mark.lineTo (44.0f, cy + 5.0f);
    juce::ColourGradient gold (juce::Colour (0xffffdb83), emblem.getTopLeft(),
                                juce::Colour (0xffe5a629), emblem.getBottomRight(), false);
    g.setGradientFill (gold);
    g.strokePath (mark, juce::PathStrokeType (1.65f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
    g.fillEllipse (42.5f, cy - 6.5f, 3.1f, 3.1f);

    g.setColour (juce::Colour (0xffebcf9b));
    g.setFont (juce::FontOptions (14.5f, juce::Font::bold));
    g.drawFittedText ("NX Audio", 59, bounds.getY(), 66, bounds.getHeight(), juce::Justification::centredLeft, 1);

    const juce::Font modelFont { juce::FontOptions (17.0f, juce::Font::bold) };
    const auto baseline = cy + 5.6f;
    juce::GlyphArrangement model;
    model.addLineOfText (modelFont, "Pro EQ", 132.0f, baseline);
    model.addLineOfText (juce::Font { juce::FontOptions (10.0f, juce::Font::bold) }, "3",
                         model.getBoundingBox (0, -1, false).getRight() + 2.0f, baseline - 6.2f);
    g.setColour (kEqGold);
    model.draw (g);
}

void ProQ3AudioProcessorEditor::drawEqGridAndScales (juce::Graphics& g, juce::Rectangle<int> area)
{
    g.saveState();
    g.reduceClipRegion (area);

    juce::ColourGradient canvas (juce::Colour (0xff1a181b), 0.0f, static_cast<float> (area.getY()),
                                  juce::Colour (0xff1d1b1e), 0.0f, static_cast<float> (area.getBottom()), false);
    g.setGradientFill (canvas);
    g.fillRect (area);

    const std::array<double, 27> minorFreqs {
        30.0, 40.0, 60.0, 70.0, 80.0, 90.0,
        150.0, 300.0, 400.0, 600.0, 700.0, 800.0, 900.0,
        1500.0, 3000.0, 4000.0, 6000.0, 7000.0, 8000.0, 9000.0,
        12000.0, 14000.0, 16000.0, 18000.0, 22000.0, 25000.0, 30000.0
    };

    g.setColour (kGridLineMinor);
    for (double f : minorFreqs)
    {
        const float x = std::round (frequencyToX (f));
        g.drawVerticalLine (static_cast<int> (x), static_cast<float> (area.getY()), static_cast<float> (area.getBottom()));
    }

    struct FreqMarker { double freq; const char* label; };
    const std::array<FreqMarker, 10> majorFreqs {{
        { 20.0,    "20"  },
        { 50.0,    "50"  },
        { 100.0,   "100" },
        { 200.0,   "200" },
        { 500.0,   "500" },
        { 1000.0,  "1k"  },
        { 2000.0,  "2k"  },
        { 5000.0,  "5k"  },
        { 10000.0, "10k" },
        { 20000.0, "20k" }
    }};

    g.setFont (juce::FontOptions (11.5f));
    for (const auto& m : majorFreqs)
    {
        const float x = std::round (frequencyToX (m.freq));
        g.setColour (kGridLineMajor);
        g.drawVerticalLine (static_cast<int> (x), static_cast<float> (area.getY()), static_cast<float> (area.getBottom()));

        g.setColour (kTextMuted);
        g.drawText (m.label, static_cast<int> (x) - 18, area.getBottom() - 18, 36, 14, juce::Justification::centred, false);
    }

    const double maxDb = getCurrentDisplayRangeDb();
    double stepDb = 3.0;
    if (maxDb <= 3.1)       stepDb = 1.0;
    else if (maxDb <= 6.1)  stepDb = 2.0;
    else if (maxDb <= 12.1) stepDb = 3.0;
    else                    stepDb = 6.0;

    for (double db = -maxDb; db <= maxDb + 0.01; db += stepDb)
    {
        const float y = std::round (gainDbToY (db));
        const bool isZero = (std::abs (db) < 0.01);

        if (! isZero)
        {
            g.setColour (kGridLineMajor);
            g.drawHorizontalLine (static_cast<int> (y), static_cast<float> (area.getX()), static_cast<float> (area.getRight()));
        }

        juce::String lbl = isZero ? "0" : ((db > 0.0 ? "+" : "") + juce::String (static_cast<int> (std::lround (db))));
        g.setColour (juce::Colour (0xffd9a226));
        g.drawText (lbl, area.getRight() - 40, static_cast<int> (y) - 7, 29, 14, juce::Justification::centredRight, false);
    }

    // Keep the fixed 0 dB line underneath the EQ response and its overlays.
    g.setColour (kGridZeroLine);
    g.drawLine (static_cast<float> (area.getX()), gainDbToY (0.0),
                static_cast<float> (area.getRight()), gainDbToY (0.0), 1.2f);

    g.restoreState();
}

float ProQ3AudioProcessorEditor::spectrumLevelAtX (const std::vector<float>& spectrum, double rate, float x) const
{
    const auto tilt = getAnalyzerTiltChange();
    const auto detail = analyzerPanel.detail.getSelectedId();
    const auto blendWidth = detail == 1 ? 0.006f : detail == 3 ? 0.0f : 0.0025f;
    const auto width = static_cast<float> (graphBounds.getWidth()) * blendWidth;
    const auto magnitudeAt = [&] (float position)
    {
        const auto frequency = juce::jmin (rate * 0.5, xToFrequency (position));
        return sampleSpectrum (spectrum, frequency, rate)
            + static_cast<float> (tilt * std::log2 (juce::jmax (20.0, frequency) / 1000.0));
    };
    return (magnitudeAt (x - width) + 2.0f * magnitudeAt (x) + magnitudeAt (x + width)) * 0.25f;
}

void ProQ3AudioProcessorEditor::drawSpectrumAnalyzer (juce::Graphics& g, juce::Rectangle<int> area)
{
    const bool showPre  = audioProcessor.apvts.getRawParameterValue ("analyzer_pre")->load() >= 0.5f;
    const bool showPost = audioProcessor.apvts.getRawParameterValue ("analyzer_post")->load() >= 0.5f;
    const bool showSidechain = audioProcessor.apvts.getRawParameterValue ("analyzer_sc")->load() >= 0.5f;

    if (! showPre && ! showPost && ! showSidechain && externalSpectrumDb.empty())
        return;

    g.saveState();
    g.reduceClipRegion (area);

    const auto sampleRate = audioProcessor.getCurrentSampleRate();

    auto buildSpectrumPath = [&] (const std::vector<float>& magDb, double rate, juce::Path& strokePath, juce::Path& fillPath)
    {
        const auto right = juce::jmin (area.getRight(), juce::roundToInt (frequencyToX (rate * 0.5)));
        if (magDb.size() < 3 || right <= area.getX()
            || *std::max_element (magDb.begin(), magDb.end()) <= -105.0f)
            return;

        const auto bottomY = static_cast<float> (area.getBottom());
        for (int px = area.getX(); ; px = juce::jmin (right, px + 2))
        {
            const auto x = static_cast<float> (px);
            const auto db = spectrumLevelAtX (magDb, rate, x);
            const auto y = analyzerDbToY (db);
            if (px == area.getX())
                strokePath.startNewSubPath (x, y);
            else
                strokePath.lineTo (x, y);
            if (px == right)
                break;
        }

        fillPath = strokePath;
        fillPath.lineTo (static_cast<float> (right), bottomY);
        fillPath.lineTo (static_cast<float> (area.getX()), bottomY);
        fillPath.closeSubPath();
    };

    if ((showPre || showPost) && (showSidechain || analyzerExternalId > 0)
        && audioProcessor.apvts.getRawParameterValue ("analyzer_overlap")->load() >= 0.5f)
    {
        const auto steps = static_cast<double> (activeSpectrumOverlap.size() - 1);
        for (size_t i = 0; i < activeSpectrumOverlap.size(); ++i)
        {
            const auto strength = activeSpectrumOverlap[i];
            if (strength < 0.025f)
                continue;
            const auto position = static_cast<double> (i);
            const auto left = frequencyToX (analyzerPreviewFrequency (juce::jmax (0.0, position - 0.5) / steps));
            const auto right = frequencyToX (analyzerPreviewFrequency (juce::jmin (steps, position + 0.5) / steps));
            const auto top = static_cast<float> (area.getY());
            const auto bottom = static_cast<float> (area.getBottom());
            g.setColour (kSpectrumOverlapColour.withAlpha (0.30f * strength));
            g.fillRect (left, top, right - left, bottom - top);
        }
    }

    const auto paintGrabTrace = [&] (const juce::Path& stroke, const juce::Path& fill)
    {
        juce::ColourGradient focus (juce::Colour (0x9a8652b2), area.toFloat().getTopLeft(),
                                     juce::Colour (0x3173469b), area.toFloat().getBottomLeft(), false);
        g.setGradientFill (focus);
        g.setOpacity (0.52f);
        g.fillPath (fill);
        g.setColour (juce::Colour (0xfff7edf7));
        g.strokePath (stroke, juce::PathStrokeType (1.45f, juce::PathStrokeType::curved));
    };

    if (showPre)
    {
        juce::Path stroke, fill;
        buildSpectrumPath (smoothedPreSpectrumDb, sampleRate, stroke, fill);
        if (spectrumGrabActive && ! showPost)
            paintGrabTrace (stroke, fill);
        else
        {
            g.setColour (juce::Colour (0x287f8193));
            g.fillPath (fill);
            g.setColour (juce::Colour (0x608e90a1));
            g.strokePath (stroke, juce::PathStrokeType (1.0f, juce::PathStrokeType::curved));
        }
    }

    if (showPost)
    {
        juce::Path stroke, fill;
        buildSpectrumPath (smoothedPostSpectrumDb, sampleRate, stroke, fill);
        if (spectrumGrabActive)
            paintGrabTrace (stroke, fill);
        else
        {
            juce::ColourGradient spectrum (juce::Colour (0x779997a4), 0.0f, static_cast<float> (area.getY()),
                                            juce::Colour (0x28918f9c), 0.0f, static_cast<float> (area.getBottom()), false);
            g.setGradientFill (spectrum);
            g.setOpacity (0.41f);
            g.fillPath (fill);
            g.setColour (juce::Colour (0xa5c3c0cc));
            g.strokePath (stroke, juce::PathStrokeType (1.15f, juce::PathStrokeType::curved));
        }
    }

    if (showSidechain)
    {
        juce::Path stroke, fill;
        buildSpectrumPath (smoothedSidechainSpectrumDb, sampleRate, stroke, fill);
        g.setColour (juce::Colour (0x24d17284));
        g.fillPath (fill);
        g.setColour (juce::Colour (0xaaee8996));
        g.strokePath (stroke, juce::PathStrokeType (1.1f, juce::PathStrokeType::curved));
    }

    if (analyzerExternalId > 0 && ! externalSpectrumDb.empty())
    {
        juce::Path stroke, fill;
        buildSpectrumPath (externalSpectrumDb, externalSampleRate, stroke, fill);
        g.setColour (kEqGold.withAlpha (0.12f));
        g.fillPath (fill);
        g.setColour (kEqGold.withAlpha (0.79f));
        g.strokePath (stroke, juce::PathStrokeType (1.25f, juce::PathStrokeType::curved));
    }

    g.restoreState();
}

ProQ3AudioProcessor::BandParameters ProQ3AudioProcessorEditor::suggestBand (juce::Point<float> position) const
{
    ProQ3AudioProcessor::BandParameters suggestion;
    suggestion.used = true;
    suggestion.freqHz = xToFrequency (position.x);
    suggestion.shape = graphEdgeFilterShape (position.x, graphBounds);
    suggestion.gainDb = suggestion.shape == ProQ3AudioProcessor::kShapeBell ? yToGainDb (position.y) : 0.0;
    return suggestion;
}

void ProQ3AudioProcessorEditor::extendEqSketch (juce::Point<float> point)
{
    point.x = juce::jlimit (static_cast<float> (graphBounds.getX()), static_cast<float> (graphBounds.getRight()), point.x);
    point.y = juce::jlimit (static_cast<float> (graphBounds.getY()), static_cast<float> (graphBounds.getBottom() - 22), point.y);
    while (! sketchPoints.empty() && sketchPoints.back().x >= point.x)
        sketchPoints.pop_back();
    if (! sketchPoints.empty() && point.x - sketchPoints.back().x < 1.0f)
        sketchPoints.back() = point;
    else
        sketchPoints.push_back (point);
    repaint (graphBounds);
}

void ProQ3AudioProcessorEditor::finishEqSketch (bool apply)
{
    sketching = false;
    int lastBand = -1;
    if (apply && sketchPoints.size() >= 3 && sketchPoints.back().x - sketchPoints.front().x >= 16.0f)
    {
        std::vector<double> gains;
        gains.reserve (sketchPoints.size());
        for (const auto& point : sketchPoints)
            gains.push_back (yToGainDb (point.y));

        constexpr double deadZone = 0.9;
        audioProcessor.apvts.copyState();
        audioProcessor.undoManager.beginNewTransaction ("Sketch EQ curve");
        size_t first = 0;
        int committed = 0;
        while (first < gains.size() && committed < 8)
        {
            if (std::abs (gains[first]) < deadZone)
            {
                ++first;
                continue;
            }

            const double sign = gains[first] > 0.0 ? 1.0 : -1.0;
            size_t end = first + 1;
            size_t peak = first;
            while (end < gains.size() && sign * gains[end] >= deadZone)
            {
                if (sign * gains[end] > sign * gains[peak])
                    peak = end;
                ++end;
            }

            if (sketchPoints[end - 1].x - sketchPoints[first].x >= 9.0f && std::abs (gains[peak]) >= 1.5)
            {
                ProQ3AudioProcessor::BandParameters band;
                const bool low = first == 0 && graphEdgeFilterShape (sketchPoints.front().x, graphBounds) == ProQ3AudioProcessor::kShapeLowCut;
                const bool high = end == gains.size()
                    && graphEdgeFilterShape (sketchPoints.back().x, graphBounds) == ProQ3AudioProcessor::kShapeHighCut;
                if (low || high)
                {
                    size_t corner = peak;
                    const double target = sign < 0.0 ? 3.0 : 0.5 * gains[peak];
                    for (size_t i = first; i < end; ++i)
                        if (std::abs (std::abs (gains[i]) - target) < std::abs (std::abs (gains[corner]) - target))
                            corner = i;
                    band.freqHz = xToFrequency (sketchPoints[corner].x);
                    band.shape = sign < 0.0
                        ? (low ? ProQ3AudioProcessor::kShapeLowCut : ProQ3AudioProcessor::kShapeHighCut)
                        : (low ? ProQ3AudioProcessor::kShapeLowShelf : ProQ3AudioProcessor::kShapeHighShelf);
                    band.gainDb = sign < 0.0 ? 0.0 : gains[peak];
                    if (sign < 0.0)
                    {
                        const auto edge = low ? first : end - 1;
                        const auto width = std::abs (std::log2 (xToFrequency (sketchPoints[edge].x) / band.freqHz));
                        if (width > 0.03)
                        {
                            constexpr std::array slopes { 6, 12, 18, 24, 30, 36, 48, 72, 96 };
                            const auto dbPerOctave = std::abs (gains[edge] - gains[corner]) / width;
                            const auto closest = std::min_element (slopes.begin(), slopes.end(),
                                [dbPerOctave] (int a, int b) { return std::abs (a - dbPerOctave) < std::abs (b - dbPerOctave); });
                            band.slopeIndex = static_cast<int> (closest - slopes.begin());
                        }
                    }
                }
                else
                {
                    auto left = peak;
                    auto right = peak;
                    const double shoulder = 0.63 * std::abs (gains[peak]);
                    while (left > first && std::abs (gains[left]) > shoulder)
                        --left;
                    while (right + 1 < end && std::abs (gains[right]) > shoulder)
                        ++right;
                    band.freqHz = xToFrequency (sketchPoints[peak].x);
                    band.gainDb = gains[peak];
                    const auto lowHz = xToFrequency (sketchPoints[left].x);
                    const auto highHz = xToFrequency (sketchPoints[right].x);
                    band.q = juce::jlimit (0.38, 12.0, band.freqHz / juce::jmax (10.0, highHz - lowHz));
                }
                const auto created = audioProcessor.activateFirstFreeBand (band, false);
                if (created < 0)
                    break;
                lastBand = created;
                ++committed;
            }
            first = end;
        }
        audioProcessor.apvts.copyState();
        audioProcessor.undoManager.beginNewTransaction();
    }

    sketchPoints.clear();
    if (lastBand >= 0)
        attachFloatingControlsToBand (lastBand);
    repaint (graphBounds);
}

void ProQ3AudioProcessorEditor::drawCurvePreview (juce::Graphics& g)
{
    if (sketching && ! sketchPoints.empty())
    {
        const juce::Graphics::ScopedSaveState clip (g);
        g.reduceClipRegion (graphBounds.withTrimmedBottom (22));
        juce::Path stroke;
        stroke.startNewSubPath (sketchPoints.front());
        for (size_t i = 1; i < sketchPoints.size(); ++i)
            stroke.lineTo (sketchPoints[i]);
        g.setColour (kPanelGreen.withAlpha (0.73f));
        g.strokePath (stroke, juce::PathStrokeType (1.6f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
        return;
    }
    if (! spectrumGrabPointerInGraph || lastMousePos.y <= gainDbToY (0.0) + 5.0f
        || hoveredBandIndex >= 0 || draggingBandIndex >= 0 || isSelectionRectDragging || draggingFrequencyView
        || waitingForEdgeDrag || heldSoloButton != nullptr || spectrumGrabActive || showHelpOverlay
        || bandMenuIndex >= 0 || analyzerPanel.isVisible() || matchPanel.isVisible() || outputPanel.isVisible()
        || findBandNodeAtPosition (lastMousePos) >= 0
        || (attachedBandIndex >= 0 && floatingPillBounds.expanded (3, 29).contains (lastMousePos.roundToInt())))
        return;

    int freeBand = 0;
    while (freeBand < ProQ3AudioProcessor::kMaxBands && audioProcessor.getBandParameters (freeBand).used)
        ++freeBand;
    if (freeBand == ProQ3AudioProcessor::kMaxBands)
        return;

    const auto response = audioProcessor.makeBandResponse (suggestBand (lastMousePos));
    juce::Path curve;
    const auto baseline = gainDbToY (0.0);
    for (int x = graphBounds.getX(); x <= graphBounds.getRight(); x += 2)
    {
        const auto y = gainDbToY (response.magnitudeDbAtFrequency (xToFrequency (static_cast<float> (x))));
        if (x == graphBounds.getX()) curve.startNewSubPath (static_cast<float> (x), y);
        else curve.lineTo (static_cast<float> (x), y);
    }

    const juce::Graphics::ScopedSaveState saved (g);
    g.reduceClipRegion (graphBounds.withTrimmedTop (juce::roundToInt (baseline) - graphBounds.getY() + 1)
                                   .withTrimmedBottom (22));
    const auto tint = juce::Colour (0xff8edba2);
    auto fill = curve;
    fill.lineTo (static_cast<float> (graphBounds.getRight()), baseline);
    fill.lineTo (static_cast<float> (graphBounds.getX()), baseline);
    fill.closeSubPath();
    g.setColour (tint.withAlpha (0.037f));
    g.fillPath (fill);
    g.setColour (tint.withAlpha (0.20f));
    g.strokePath (curve, juce::PathStrokeType (1.35f, juce::PathStrokeType::curved));
}

void ProQ3AudioProcessorEditor::drawEqCurvesAndBandNodes (juce::Graphics& g, juce::Rectangle<int> area)
{
    g.saveState();
    g.reduceClipRegion (area);

    const float zeroY = gainDbToY (0.0);
    const int selectedBand = audioProcessor.getSelectedBandIndex();
    const auto selectedMode = audioProcessor.getBandParameters (selectedBand).stereoMode;
    const bool isolatedSide = selectedMode == 1 || selectedMode == 2;
    const auto masterColour = isolatedSide ? stereoPlacementColour (selectedMode) : kEqGold;
    const bool globalBypass = audioProcessor.apvts.getRawParameterValue ("global_bypass")->load() >= 0.5f;
    const auto soloBand = ! globalBypass ? audioProcessor.getSoloBandIndex() : -1;
    const auto curveOpacity = soloBand >= 0 ? 0.26f : 1.0f;

    // Calculate each band's coefficients once per frame and reuse its samples in the total.
    const auto pointCount = static_cast<size_t> (area.getWidth() / 2 + 1);
    std::vector<double> frequencies (pointCount), totalLiveDb (pointCount), totalStaticDb (pointCount);
    for (size_t point = 0; point < pointCount; ++point)
        frequencies[point] = xToFrequency (static_cast<float> (area.getX() + 2 * static_cast<int> (point)));

    const auto toY = [this] (double db) { return gainDbToY (db); };

    struct BandOverlay
    {
        juce::Path edge, fill, dynamicRange, activity;
        juce::Colour colour;
        float opacity;
        bool highlighted;
        bool isCut;
        bool isolated;
    };
    std::vector<BandOverlay> overlays;
    std::vector<float> dynamicEdgeY, staticEdgeY;

    bool hasLiveModulation = false;
    for (int b = 0; b < ProQ3AudioProcessor::kMaxBands; ++b)
    {
        const auto bp = audioProcessor.getBandParameters (b);
        if (! bp.used)
            continue;

        const bool isSelected = (b == selectedBand);
        const bool isHovered = (b == hoveredBandIndex);
        const bool hasDyn = ProQ3AudioProcessor::doesShapeSupportDynamics (bp.shape) && std::abs (bp.dynRangeDb) > 0.05;
        const bool showBand = isSelected || isHovered || std::abs (bp.gainDb) >= 0.02 || hasDyn
                              || ! ProQ3AudioProcessor::doesShapeSupportGain (bp.shape);
        if (! bp.enabled && ! showBand)
            continue;

        const bool drawRange = hasDyn && bp.enabled && bp.dynEnabled && ! globalBypass;
        const auto dynamicGain = drawRange ? bandDynamics[static_cast<size_t> (b)].gainDb : 0.0f;
        const bool isModulated = std::abs (dynamicGain) > 0.01f;
        const bool spectral = bp.spectral && drawRange;
        const auto spectralLive = spectral && isModulated ? audioProcessor.makeSpectralResponse (bp, b, false)
                                                          : ProQ3AudioProcessor::SpectralResponse {};
        const auto spectralRange = spectral ? audioProcessor.makeSpectralResponse (bp, b, true)
                                            : ProQ3AudioProcessor::SpectralResponse {};
        hasLiveModulation |= isModulated;
        const auto staticResponse = audioProcessor.makeBandResponse (bp);
        const auto liveResponse = isModulated && ! spectral ? audioProcessor.makeBandResponse (bp, dynamicGain) : staticResponse;
        const auto rangeResponse = drawRange && ! spectral ? audioProcessor.makeBandResponse (bp, bp.dynRangeDb) : liveResponse;
        if (drawRange)
            dynamicEdgeY.resize (pointCount);
        if (isModulated)
            staticEdgeY.resize (pointCount);

        juce::Path bandLiveCurve;
        juce::Path bandFill;

        for (size_t point = 0; point < pointCount; ++point)
        {
            const double liveDb = liveResponse.magnitudeDbAtFrequency (frequencies[point])
                + (spectral && isModulated ? spectralLive.magnitudeDbAtFrequency (frequencies[point]) : 0.0);
            const double staticDb = isModulated ? staticResponse.magnitudeDbAtFrequency (frequencies[point]) : liveDb;
            const bool oppositeSide = isolatedSide && (bp.stereoMode == 1 || bp.stereoMode == 2) && bp.stereoMode != selectedMode;
            if (bp.enabled && ! oppositeSide)
            {
                totalLiveDb[point] += liveDb;
                totalStaticDb[point] += staticDb;
            }

            if (showBand)
            {
                const float x = static_cast<float> (area.getX() + 2 * static_cast<int> (point));
                const float y = toY (liveDb);
                if (drawRange)
                    dynamicEdgeY[point] = toY (rangeResponse.magnitudeDbAtFrequency (frequencies[point])
                        + (spectral ? spectralRange.magnitudeDbAtFrequency (frequencies[point]) : 0.0));
                if (isModulated)
                    staticEdgeY[point] = toY (staticDb);
                if (point == 0)
                {
                    bandLiveCurve.startNewSubPath (x, y);
                    bandFill.startNewSubPath (x, zeroY);
                }
                else
                {
                    bandLiveCurve.lineTo (x, y);
                }
                bandFill.lineTo (x, y);
            }
        }

        if (! showBand)
            continue;

        bandFill.lineTo (static_cast<float> (area.getRight()), zeroY);
        bandFill.closeSubPath();
        const auto fillTo = [&] (const std::vector<float>& edge)
        {
            auto region = bandLiveCurve;
            for (size_t point = pointCount; point > 0; --point)
            {
                const auto index = point - 1;
                const auto x = static_cast<float> (area.getX() + 2 * static_cast<int> (index));
                region.lineTo (x, edge[index]);
            }
            region.closeSubPath();
            return region;
        };
        auto dynamicFill = drawRange ? fillTo (dynamicEdgeY) : juce::Path {};
        auto activity = isModulated ? fillTo (staticEdgeY) : juce::Path {};

        const bool isCut = bp.shape == ProQ3AudioProcessor::kShapeLowCut || bp.shape == ProQ3AudioProcessor::kShapeHighCut;
        const auto opacity = bp.enabled && ! globalBypass ? 1.0f : 0.33f;
        overlays.push_back ({ std::move (bandLiveCurve), std::move (bandFill), std::move (dynamicFill), std::move (activity),
                              getBandColour (b, bp.stereoMode), opacity * (soloBand < 0 || b == soloBand ? 1.0f : 0.25f),
                              isSelected || isHovered || b == soloBand, isCut, bp.stereoMode == 1 || bp.stereoMode == 2 });
    }

    juce::Path totalLiveCurve;
    juce::Path totalStaticCurve;
    juce::Path totalFill;
    totalFill.startNewSubPath (static_cast<float> (area.getX()), zeroY);
    totalLiveCurve.startNewSubPath (static_cast<float> (area.getX()), toY (totalLiveDb.front()));
    totalStaticCurve.startNewSubPath (static_cast<float> (area.getX()), toY (totalStaticDb.front()));

    for (size_t point = 0; point < pointCount; ++point)
    {
        const float x = static_cast<float> (area.getX() + 2 * static_cast<int> (point));
        const float y = toY (totalLiveDb[point]);
        totalLiveCurve.lineTo (x, y);
        totalFill.lineTo (x, y);
        totalStaticCurve.lineTo (x, toY (totalStaticDb[point]));
    }

    totalFill.lineTo (static_cast<float> (area.getRight()), zeroY);
    totalFill.closeSubPath();
    const auto smokeFill = [&] (const juce::Path& path, juce::Colour colour, float opacity)
    {
        const auto x = static_cast<float> (area.getX());
        const auto half = static_cast<float> (area.getHeight());
        juce::ColourGradient shade (colour.darker (0.45f).withAlpha (0.24f), x, zeroY - half * 0.40f,
                                    colour.darker (0.42f).withAlpha (0.26f), x, zeroY + half * 0.65f, false);
        shade.addColour (0.38, colour.darker (0.60f).withAlpha (0.18f));
        shade.addColour (0.76, colour.withAlpha (0.90f));
        g.setGradientFill (shade);
        g.setOpacity (opacity);
        g.fillPath (path);
    };
    smokeFill (totalFill, masterColour, (globalBypass ? 0.025f : 0.065f) * curveOpacity);

    for (const auto& overlay : overlays)
    {
        const auto tint = overlay.isCut && ! overlay.isolated ? kCutGradientTint : overlay.colour;
        const auto fillOpacity = overlay.isCut || overlay.highlighted ? 0.13f : 0.10f;
        if (overlay.isCut)
        {
            const auto x = static_cast<float> (area.getX());
            const auto farEdge = tint.darker (7.0f).withAlpha (0.0f);
            juce::ColourGradient shade (farEdge, x, zeroY,
                                        farEdge, x, static_cast<float> (area.getBottom()), false);
            shade.addColour (0.31, tint.darker (2.3f).withAlpha (0.24f));
            shade.addColour (0.61, tint.withAlpha (0.95f));
            shade.addColour (0.81, tint.darker (1.55f).withAlpha (0.32f));
            g.setGradientFill (shade);
            g.setOpacity (fillOpacity * overlay.opacity);
            g.fillPath (overlay.fill);
        }
        else
        {
            smokeFill (overlay.fill, tint, fillOpacity * overlay.opacity);
        }
        if (! overlay.dynamicRange.isEmpty())
        {
            g.setColour (overlay.colour.withAlpha ((overlay.highlighted ? 0.075f : 0.055f) * overlay.opacity));
            g.fillPath (overlay.dynamicRange);
        }
        if (! overlay.activity.isEmpty())
        {
            g.setColour (overlay.colour.interpolatedWith (kEqGold, 0.24f)
                             .withAlpha ((overlay.highlighted ? 0.32f : 0.22f) * overlay.opacity));
            g.fillPath (overlay.activity);
        }
        g.setColour (overlay.colour.withAlpha ((overlay.highlighted ? 0.78f : 0.55f) * overlay.opacity));
        g.strokePath (overlay.edge, juce::PathStrokeType (overlay.highlighted ? 1.2f : 1.0f));
    }

    // Traço fantasma da curva estática quando a dinâmica está atuando
    if (hasLiveModulation)
    {
        g.setColour (kTextMuted.withAlpha (0.6f * curveOpacity));
        g.strokePath (totalStaticCurve, juce::PathStrokeType (1.2f));
    }

    // Brilho e curva principal acompanhando em tempo real o ganho aplicado pelo DSP
    g.setColour (masterColour.withAlpha (kEqGlow.getFloatAlpha() * (globalBypass ? 0.3f : 1.0f) * curveOpacity));
    g.strokePath (totalLiveCurve, juce::PathStrokeType (3.5f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

    g.setColour ((globalBypass ? juce::Colour (0xff7e7352) : masterColour).withMultipliedAlpha (curveOpacity));
    g.strokePath (totalLiveCurve, juce::PathStrokeType (2.2f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

    if (soloBand >= 0)
    {
        const auto response = audioProcessor.makeSoloBandResponse (audioProcessor.getBandParameters (soloBand));
        const auto bottom = static_cast<float> (area.getBottom());
        const auto depth = bottom - zeroY;
        juce::Path edge;
        for (size_t point = 0; point < pointCount; ++point)
        {
            const auto x = static_cast<float> (area.getX() + 2 * static_cast<int> (point));
            const auto db = response.magnitudeDbAtFrequency (frequencies[point]);
            const auto y = bottom - depth * static_cast<float> (juce::jlimit (0.0, 1.0, 1.0 + db / 38.0));
            if (point == 0) edge.startNewSubPath (x, y);
            else            edge.lineTo (x, y);
        }
        auto region = edge;
        region.lineTo (static_cast<float> (area.getRight()), bottom);
        region.lineTo (static_cast<float> (area.getX()), bottom);
        region.closeSubPath();
        const auto accent = getBandColour (soloBand).interpolatedWith (kEqGold, 0.26f);
        smokeFill (region, accent, 0.18f);
        g.setColour (accent.withAlpha (0.64f));
        g.strokePath (edge, juce::PathStrokeType (1.25f, juce::PathStrokeType::curved));
    }

    // 3. Nós numerados das bandas ativas (1 a 24) + Indicador de Dynamic Range no display
    g.setFont (juce::FontOptions (7.8f, juce::Font::bold));
    for (int b = 0; b < ProQ3AudioProcessor::kMaxBands; ++b)
    {
        const auto bp = audioProcessor.getBandParameters (b);
        if (! bp.used)
            continue;

        const float nx = frequencyToX (bp.freqHz);
        const float ny = gainDbToY (bp.gainDb);
        const bool isSelected = (b == selectedBand);
        const bool isHovered  = (b == hoveredBandIndex);
        const juce::Colour nodeCol = getBandColour (b, bp.stereoMode);
        const bool dimmed = soloBand >= 0 && b != soloBand;
        if (dimmed)
        {
            g.setColour (nodeCol.withAlpha (0.27f));
            g.fillEllipse (nx - 4.0f, ny - 4.0f, 8.0f, 8.0f);
            continue;
        }

        // Se a banda tem Dynamic Range != 0, desenha a haste vertical de alcance dinâmico e o ponto da redução atual (Manual p. 7 & p. 13)
        if (ProQ3AudioProcessor::doesShapeSupportDynamics (bp.shape) && std::abs (bp.dynRangeDb) > 0.05)
        {
            const float dynTargetY = gainDbToY (bp.gainDb + bp.dynRangeDb);
            const auto liveModDb = bp.enabled && bp.dynEnabled && ! globalBypass
                ? bandDynamics[static_cast<size_t> (b)].gainDb : 0.0f;
            const float liveY = gainDbToY (bp.gainDb + static_cast<double> (liveModDb));

            g.setColour (bp.enabled && bp.dynEnabled ? nodeCol.withAlpha (0.78f) : juce::Colour (0xff666a75));
            g.drawLine (nx, ny, nx, dynTargetY, 1.8f);

            juce::Path handles;
            handles.addTriangle (nx - 3.0f, dynTargetY - 2.0f, nx + 3.0f, dynTargetY - 2.0f, nx, dynTargetY - 6.0f);
            handles.addTriangle (nx - 3.0f, dynTargetY + 2.0f, nx + 3.0f, dynTargetY + 2.0f, nx, dynTargetY + 6.0f);
            g.setColour (juce::Colour (0xffd5d4da).withAlpha (bp.enabled && bp.dynEnabled ? 0.55f : 0.28f));
            g.fillPath (handles);

            if (std::abs (liveY - ny) > 1.5f)
            {
                g.setColour (kDynYellowLive.withAlpha (0.83f));
                g.drawLine (nx, ny, nx, liveY, 1.8f);
                g.fillEllipse (nx - 3.5f, liveY - 3.5f, 7.0f, 7.0f);
            }
        }

        const float radius = isSelected ? 6.3f : (isHovered ? 5.8f : 5.2f);
        const juce::Rectangle<float> dotRect (nx - radius, ny - radius, radius * 2.0f, radius * 2.0f);

        if (isSelected || isHovered)
        {
            g.setColour (nodeCol.withAlpha (0.23f));
            g.fillEllipse (dotRect.expanded (3.0f));
        }

        const auto dotColour = bp.enabled ? nodeCol : juce::Colour (0xff68717e);
        juce::ColourGradient dot (dotColour.brighter (0.38f), nx - radius * 0.32f, ny - radius * 0.45f,
                                  dotColour.darker (0.23f), nx + radius * 0.8f, ny + radius * 0.8f, true);
        g.setGradientFill (dot);
        g.fillEllipse (dotRect);
        g.setColour (juce::Colour (0xff121214));
        g.drawEllipse (dotRect, 1.0f);

        g.setColour (juce::Colours::white.withAlpha (0.53f));
        g.fillEllipse (nx - radius * 0.55f, ny - radius * 0.62f, radius * 0.46f, radius * 0.31f);
        g.setColour (juce::Colour (0xff15141b));
        g.drawText (juce::String (b + 1), dotRect.toNearestInt(), juce::Justification::centred, false);
        if (bp.stereoMode == 1 || bp.stereoMode == 2)
        {
            const auto right = bp.stereoMode == 2;
            const juce::Rectangle<float> tag (right ? nx + radius + 1.0f : nx - radius - 12.0f, ny - 5.0f, 11.0f, 10.0f);
            g.setColour (nodeCol.withAlpha (0.8f));
            g.fillRoundedRectangle (tag, 3.0f);
            g.setColour (juce::Colour (0xff1b1820));
            g.drawText (right ? "R" : "L", tag.toNearestInt(), juce::Justification::centred);
        }
    }

    if (isSelectionRectDragging && ! selectionLassoRect.isEmpty())
    {
        g.setColour (kControlAccent.withAlpha (0.15f));
        g.fillRect (selectionLassoRect);
        g.setColour (kControlAccent.withAlpha (0.7f));
        g.drawRect (selectionLassoRect, 1.0f);
    }

    g.restoreState();
}

juce::Rectangle<int> ProQ3AudioProcessorEditor::getBandTooltipBounds (
    const ProQ3AudioProcessor::BandParameters& band) const noexcept
{
    const auto x = juce::roundToInt (frequencyToX (band.freqHz));
    const auto y = juce::roundToInt (gainDbToY (band.gainDb));
    constexpr int width = 185;
    constexpr int height = 68;
    const auto area = graphBounds.reduced (8);
    const int top = y - height - 20;
    return { juce::jlimit (area.getX(), area.getRight() - width, x - width / 2),
             juce::jlimit (area.getY(), area.getBottom() - height, top < area.getY() ? y + 20 : top),
             width, height };
}

bool ProQ3AudioProcessorEditor::isOverBandTooltip (juce::Point<int> position) const noexcept
{
    const auto band = audioProcessor.getBandParameters (hoveredBandIndex);
    if (! band.used)
        return false;

    const auto node = juce::Point<float> (frequencyToX (band.freqHz), gainDbToY (band.gainDb)).roundToInt();
    const juce::Rectangle<int> nodeBounds (node.x - 10, node.y - 10, 20, 20);
    auto area = getBandTooltipBounds (band).getUnion (nodeBounds);
    if (shapeQuickRail.isVisible())
        area = area.getUnion (shapeQuickRail.getBounds());
    return area.contains (position);
}

void ProQ3AudioProcessorEditor::showBandOptions (int band, juce::Component* anchor)
{
    const auto bp = audioProcessor.getBandParameters (band);
    juce::PopupMenu menu;
    const auto& apvts = audioProcessor.apvts;
    auto choices = [&] (const char* id, int base, int selected)
    {
        juce::PopupMenu list;
        auto items = apvts.getParameter (ProQ3AudioProcessor::getBandParamID (band, id))->getAllValueStrings();
        if (base == 100)
            items.add ("All Pass");
        for (int index = 0; index < items.size(); ++index)
        {
            auto icon = base == 100 ? makeShapeIcon (index, index == selected ? kEqGold : kTextMuted)
                            : base == 300 ? makePlacementIcon (index) : nullptr;
            const bool allowed = base != 200 || index != ProQ3AudioProcessor::kSlopeBrickwall
                || bp.shape == ProQ3AudioProcessor::kShapeLowCut || bp.shape == ProQ3AudioProcessor::kShapeHighCut;
            list.addItem (base + index, items[index], allowed, index == selected, std::move (icon));
        }
        return list;
    };

    if (! bp.used)
    {
        if (! clipboardBand.has_value())
            return;
        menu.addItem (13, "Paste Band");
    }
    else
    {
        const auto canModulate = ProQ3AudioProcessor::doesShapeSupportDynamics (bp.shape);
        const auto dynamic = bp.dynEnabled && std::abs (bp.dynRangeDb) > 0.05;
        menu.addSectionHeader ("Band " + juce::String (band + 1));
        menu.addItem (1, bp.enabled ? "Disable" : "Enable");
        menu.addItem (3, "Invert Gain", ProQ3AudioProcessor::doesShapeSupportGain (bp.shape));
        menu.addItem (2, dynamic && ! bp.spectral ? "Make Static" : "Make Dynamic", canModulate);
        menu.addItem (7, bp.spectral ? "Disable Spectral" : "Make Spectral", canModulate);
        menu.addSeparator();
        menu.addSubMenu ("Shape", choices ("shape", 100, bp.shape));
        menu.addSubMenu ("Slope", choices ("slope", 200, bp.slopeIndex));
        menu.addSubMenu ("Stereo Placement", choices ("stereo", 300, bp.stereoMode));
        menu.addSeparator();
        menu.addItem (11, "Cut");
        menu.addItem (12, "Copy");
        menu.addItem (13, "Paste", clipboardBand.has_value());
        menu.addSeparator();
        menu.addItem (14, "Split");
        menu.addItem (99, "Delete");
        juce::PopupMenu reset;
        reset.addItem (4, "Gain to 0 dB");
        reset.addItem (5, "Q to 1.00");
        reset.addItem (6, "Quantize Frequency to Note");
        menu.addSubMenu ("Reset", reset);
    }

    if (anchor != nullptr)
        bandMenuIndex = band;
    auto options = juce::PopupMenu::Options().withMinimumWidth (154);
    if (anchor != nullptr)
        options = options.withTargetComponent (anchor);
    menu.showMenuAsync (options, [editor = juce::Component::SafePointer<ProQ3AudioProcessorEditor> (this), band] (int result)
    {
        if (editor == nullptr)
            return;
        editor->bandMenuIndex = -1;
        if (result != 0)
            editor->applyBandOption (band, result);
        editor->updateBandShortcuts();
        editor->repaint (editor->graphBounds);
    });
}

void ProQ3AudioProcessorEditor::applyBandOption (int band, int action)
{
    auto bp = audioProcessor.getBandParameters (band);
    if (action == 13 && clipboardBand)
    {
        audioProcessor.undoManager.beginNewTransaction ("Paste EQ Band");
        if (bp.used)
            audioProcessor.applyBandParameters (band, *clipboardBand);
        else
            band = audioProcessor.activateFirstFreeBand (*clipboardBand, false);
        if (band >= 0)
            attachFloatingControlsToBand (band);
    }
    else if (! bp.used)
        return;
    else if (action == 14)
        splitBand (band);
    else if (action == 11 || action == 12 || action == 99)
    {
        if (action != 99)
            clipboardBand = bp;
        if (action != 12)
        {
            audioProcessor.deactivateBand (band);
            attachFloatingControlsToBand (audioProcessor.getSelectedBandIndex());
        }
    }
    else
    {
        const bool dynamic = bp.dynEnabled && std::abs (bp.dynRangeDb) > 0.05;
        const auto defaultRange = bp.gainDb >= 0.0 ? -6.0 : 6.0;
        if (action == 1) bp.enabled = ! bp.enabled;
        else if (action == 2)
        {
            bp.dynRangeDb = dynamic && ! bp.spectral ? 0.0
                : std::abs (bp.dynRangeDb) > 0.05 ? bp.dynRangeDb : defaultRange;
            bp.spectral = false;
            bp.dynEnabled = true;
        }
        else if (action == 3) bp.gainDb = -bp.gainDb;
        else if (action == 4) bp.gainDb = 0.0;
        else if (action == 5) bp.q = 1.0;
        else if (action == 6) bp.freqHz = snapFrequencyToNearestSemitone (bp.freqHz);
        else if (action == 7)
        {
            bp.spectral = ! bp.spectral;
            if (bp.spectral)
            {
                bp.dynEnabled = true;
                if (std::abs (bp.dynRangeDb) <= 0.05)
                    bp.dynRangeDb = -6.0;
            }
        }
        else if (action >= 100 && action <= 100 + ProQ3AudioProcessor::kShapeAllPass)
        {
            bp.shape = action - 100;
            if (! ProQ3AudioProcessor::doesShapeSupportDynamics (bp.shape))
                bp.spectral = false;
            if (bp.slopeIndex == ProQ3AudioProcessor::kSlopeBrickwall
                && bp.shape != ProQ3AudioProcessor::kShapeLowCut && bp.shape != ProQ3AudioProcessor::kShapeHighCut)
                bp.slopeIndex = ProQ3AudioProcessor::kSlope96dB;
        }
        else if (action >= 200 && action <= 209) bp.slopeIndex = action - 200;
        else if (action >= 300 && action <= 304) bp.stereoMode = action - 300;
        else return;

        audioProcessor.undoManager.beginNewTransaction ("Edit EQ Band");
        audioProcessor.applyBandParameters (band, bp);
        attachFloatingControlsToBand (band);
    }
    updateBandShortcuts();
    repaint (graphBounds);
}

void ProQ3AudioProcessorEditor::splitBand (int band)
{
    auto original = audioProcessor.getBandParameters (band);
    if (! original.used)
        return;

    audioProcessor.undoManager.beginNewTransaction ("Split EQ Band");
    auto duplicate = original;
    original.stereoMode = original.stereoMode >= 3 ? 3 : 1;
    duplicate.stereoMode = original.stereoMode + 1;
    const auto other = audioProcessor.activateFirstFreeBand (duplicate, false);
    if (other >= 0)
    {
        audioProcessor.applyBandParameters (band, original);
        attachFloatingControlsToBand (other);
        repaint (graphBounds);
    }
}

void ProQ3AudioProcessorEditor::updateBandShortcuts()
{
    const bool auditioningCard = heldSoloButton == &bandSoloShortcut;
    const auto band = audioProcessor.getBandParameters (auditioningCard ? soloControlBand
                                                        : bandMenuIndex >= 0 ? bandMenuIndex : hoveredBandIndex);
    const bool visible = band.used && draggingBandIndex < 0 && ! showHelpOverlay && ! spectrumGrabActive
        && ! analyzerPanel.isVisible() && ! matchPanel.isVisible() && ! outputPanel.isVisible()
        && ! instanceOverview.isVisible();
    const bool dynamic = visible && ProQ3AudioProcessor::doesShapeSupportDynamics (band.shape);
    if (visible)
    {
        const auto card = getBandTooltipBounds (band);
        const auto x = card.getRight();
        const auto y = card.getY() + 3;
        bandPowerShortcut.setBounds (card.getX() + 4, y, 20, 19);
        bandDeleteShortcut.setBounds (x - 24, y, 20, 19);
        bandSoloShortcut.setBounds (x - 47, y, 20, 19);
        bandDynamicsShortcut.setBounds (x - 70, y, 20, 19);
        bandOptionsShortcut.setBounds (x - 25, card.getBottom() - 24, 20, 19);
        bandShapeShortcut.setBounds (card.getX() + 4, card.getBottom() - 24, 24, 19);
        bandPowerShortcut.setToggleState (band.enabled, juce::dontSendNotification);
        if (shortcutShape != band.shape)
        {
            const auto icon = makeShapeIcon (band.shape, kEqGold);
            bandShapeShortcut.setImages (icon.get());
            shortcutShape = band.shape;
        }
    }
    if (! visible || hoveredBandIndex != shapeQuickBand)
        shapeQuickBand = -1;
    shapeQuickRail.setVisible (shapeQuickBand >= 0);
    if (shapeQuickRail.isVisible())
    {
        constexpr int itemWidth = 26;
        constexpr int railWidth = itemWidth * 10;
        const auto card = getBandTooltipBounds (band);
        const int x = juce::jlimit (graphBounds.getX() + 4, graphBounds.getRight() - railWidth - 4, card.getX());
        const int y = card.getBottom() + 26 >= graphBounds.getBottom() ? card.getY() - 25 : card.getBottom() + 1;
        shapeQuickRail.setBounds (x, y, railWidth, 24);
        for (size_t i = 0; i < shapeQuickButtons.size(); ++i)
        {
            shapeQuickButtons[i]->setBounds (static_cast<int> (i) * itemWidth, 0, itemWidth, 24);
            shapeQuickButtons[i]->setToggleState (static_cast<int> (i) == band.shape, juce::dontSendNotification);
        }
    }
    bandDynamicsShortcut.setVisible (dynamic);
    for (auto* control : std::array<juce::Button*, 5> {
            &bandSoloShortcut, &bandShapeShortcut, &bandOptionsShortcut, &bandPowerShortcut, &bandDeleteShortcut })
        control->setVisible (visible);
    bandSoloShortcut.setEnabled (audioProcessor.apvts.getRawParameterValue ("global_bypass")->load() < 0.5f);
}

void ProQ3AudioProcessorEditor::drawBandParameterTooltip (juce::Graphics& g, int bandIndex)
{
    const auto bp = audioProcessor.getBandParameters (bandIndex);
    if (! bp.used)
        return;

    const auto box = getBandTooltipBounds (bp);
    const auto accent = bandPanelAccent (bp.stereoMode);
    const auto bounds = box.toFloat();
    const auto node = juce::Point<float> (frequencyToX (bp.freqHz), gainDbToY (bp.gainDb));
    const bool above = node.y >= bounds.getBottom();
    const auto edge = above ? bounds.getBottom() - 0.5f : bounds.getY() + 0.5f;
    const auto x = juce::jlimit (bounds.getX() + 14.0f, bounds.getRight() - 14.0f, node.x);
    const auto tip = juce::Point<float> (x, edge + (above ? 7.0f : -7.0f));

    juce::Path card;
    card.addRoundedRectangle (bounds, 6.0f);
    g.setColour (juce::Colour (0xe621202b));
    g.fillPath (card);
    juce::ColourGradient light (accent.withAlpha (0.95f), x, edge, accent.darker (5.0f).withAlpha (0.0f),
                                 x, edge + (above ? -50.0f : 50.0f), true);
    g.setGradientFill (light);
    g.setOpacity (0.24f);
    g.fillPath (card);
    g.setColour (juce::Colour (0x9a60586b));
    g.strokePath (card, juce::PathStrokeType (1.0f));
    juce::Path pointer;
    pointer.addTriangle (x - 5.5f, edge, x + 5.5f, edge, tip.x, tip.y);
    g.setColour (accent.darker (2.0f).withAlpha (0.80f));
    g.fillPath (pointer);
    g.setColour (accent.withAlpha (0.72f));
    g.drawLine (x - 5.5f, edge, tip.x, tip.y, 1.0f);
    g.drawLine (tip.x, tip.y, x + 5.5f, edge, 1.0f);

    static const char* shapeNames[10] = {
        "Bell", "Low Shelf", "Low Cut", "High Shelf", "High Cut",
        "Notch", "Band Pass", "Tilt Shelf", "Flat Tilt", "All Pass"
    };

    const juce::String freqStr = (bp.freqHz >= 1000.0)
                                    ? (juce::String (bp.freqHz / 1000.0, 2) + " kHz")
                                    : (juce::String (bp.freqHz, 1) + " Hz");
    const juce::String noteStr = frequencyToMusicalNoteName (bp.freqHz);
    const juce::String gainStr = (bp.gainDb >= 0.0 ? "+" : "") + juce::String (bp.gainDb, 2) + " dB";
    const float liveDyn = bandDynamics[static_cast<size_t> (bandIndex)].gainDb;
    const juce::String dynStr  = (std::abs (bp.dynRangeDb) > 0.05)
                                    ? (juce::String (bp.spectral ? "  | Spectral: " : "  | Dyn: ") + (bp.dynRangeDb >= 0.0 ? "+" : "") + juce::String (bp.dynRangeDb, 1)
                                       + " (" + (liveDyn >= 0.0f ? "+" : "") + juce::String (liveDyn, 1) + " dB)")
                                    : "";
    const juce::String qStr    = "Q: " + juce::String (bp.q, 2) + "  (" + shapeNames[juce::jlimit (0, 9, bp.shape)] + ")";

    g.setFont (juce::FontOptions (11.5f, juce::Font::bold));
    g.setColour (kTextBright);
    const int buttonsWidth = (bandSoloShortcut.isVisible() ? 24 : 0) + (bandDynamicsShortcut.isVisible() ? 24 : 0);
    const auto topTextWidth = box.getWidth() - 55 - buttonsWidth;
    g.drawFittedText (freqStr + "  [" + noteStr + "]", box.getX() + 28, box.getY() + 5, topTextWidth, 15,
                      juce::Justification::centredLeft, 1);

    g.setColour (getBandColour (bandIndex, bp.stereoMode));
    const auto details = bandIndex == soloControlBand ? "Solo " + juce::String (soloListeningLevel, 1) + " dB" : gainStr + dynStr;
    g.drawFittedText (details, box.getX() + 8, box.getY() + 23, box.getWidth() - 16, 15,
                      juce::Justification::centredLeft, 1);

    g.setFont (juce::FontOptions (11.0f));
    g.setColour (kTextMuted);
    g.drawFittedText (qStr, box.getX() + 33, box.getY() + 45, box.getWidth() - 62, 15, juce::Justification::centredLeft, 1);
}

void ProQ3AudioProcessorEditor::drawPianoRollBar (juce::Graphics& g, juce::Rectangle<int> area)
{
    g.setColour (juce::Colour (0xff16181d));
    g.fillRect (area);

    auto isBlackKey = [] (int midiNote) noexcept
    {
        const int n = midiNote % 12;
        return (n == 1 || n == 3 || n == 6 || n == 8 || n == 10);
    };

    for (int midi = 21; midi <= 108; ++midi)
    {
        const double fCenter = 440.0 * std::pow (2.0, (static_cast<double> (midi) - 69.0) / 12.0);
        const double fLow    = 440.0 * std::pow (2.0, (static_cast<double> (midi) - 69.5) / 12.0);
        const double fHigh   = 440.0 * std::pow (2.0, (static_cast<double> (midi) - 68.5) / 12.0);

        const float x0 = frequencyToX (fLow);
        const float x1 = frequencyToX (fHigh);
        juce::Rectangle<float> keyRect (x0, static_cast<float> (area.getY()), juce::jmax (2.0f, x1 - x0), static_cast<float> (area.getHeight()));

        const bool black = isBlackKey (midi);
        g.setColour (black ? juce::Colour (0xff20232a) : juce::Colour (0xff383d49));
        g.fillRect (keyRect.reduced (0.4f, 1.0f));

        if (midi % 12 == 0)
        {
            const int oct = (midi / 12) - 1;
            g.setColour (kTextBright);
            g.setFont (juce::FontOptions (9.5f));
            g.drawText ("C" + juce::String (oct), static_cast<int> (frequencyToX (fCenter)) - 10, area.getBottom() - 12, 20, 11, juce::Justification::centred, false);
        }
    }

    for (int b = 0; b < ProQ3AudioProcessor::kMaxBands; ++b)
    {
        const auto bp = audioProcessor.getBandParameters (b);
        if (! bp.used)
            continue;

        const float x = frequencyToX (bp.freqHz);
        const float y = static_cast<float> (area.getCentreY());
        g.setColour (getBandColour (b));
        g.fillEllipse (x - 4.0f, y - 4.0f, 8.0f, 8.0f);
    }
}

void ProQ3AudioProcessorEditor::drawFloatingBandControlsBackground (juce::Graphics& g)
{
    if (attachedBandIndex < 0 || attachedBandIndex >= ProQ3AudioProcessor::kMaxBands)
        return;

    const auto bp = audioProcessor.getBandParameters (attachedBandIndex);
    if (! bp.used)
        return;

    auto pill = floatingPillBounds.toFloat();
    const float humpCenterX = pill.getCentreX() - 4.0f;
    const float humpTopY    = pill.getY() - 18.0f;

    // The raised centre leaves room for the dynamic controls above the gain knob.
    juce::Path pillShape;
    const float r = 8.0f;
    pillShape.startNewSubPath (pill.getX() + r, pill.getY());
    pillShape.lineTo (humpCenterX - 68.0f, pill.getY());
    pillShape.cubicTo (humpCenterX - 42.0f, pill.getY(),
                       humpCenterX - 36.0f, humpTopY,
                       humpCenterX, humpTopY);
    pillShape.cubicTo (humpCenterX + 36.0f, humpTopY,
                       humpCenterX + 42.0f, pill.getY(),
                       humpCenterX + 68.0f, pill.getY());
    pillShape.lineTo (pill.getRight() - r, pill.getY());
    pillShape.quadraticTo (pill.getRight(), pill.getY(), pill.getRight(), pill.getY() + r);
    pillShape.lineTo (pill.getRight(), pill.getBottom() - r);
    pillShape.quadraticTo (pill.getRight(), pill.getBottom(), pill.getRight() - r, pill.getBottom());
    pillShape.lineTo (pill.getX() + r, pill.getBottom());
    pillShape.quadraticTo (pill.getX(), pill.getBottom(), pill.getX(), pill.getBottom() - r);
    pillShape.lineTo (pill.getX(), pill.getY() + r);
    pillShape.quadraticTo (pill.getX(), pill.getY(), pill.getX() + r, pill.getY());
    pillShape.closeSubPath();

    const auto accent = bandPanelAccent (bp.stereoMode);
    g.setColour (juce::Colour (0x380a0810));
    g.strokePath (pillShape, juce::PathStrokeType (5.0f, juce::PathStrokeType::curved),
                  juce::AffineTransform::translation (0.0f, 2.0f));

    juce::ColourGradient graphite (juce::Colour (0xff282630), humpCenterX, humpTopY,
                                   juce::Colour (0xff221e29), humpCenterX, pill.getBottom(), false);
    g.setGradientFill (graphite);
    g.setOpacity (0.72f);
    g.fillPath (pillShape);

    const juce::Point<float> origin (humpCenterX, humpTopY);
    juce::ColourGradient crest (accent.withAlpha (0.98f), origin,
                                 accent.darker (6.0f).withAlpha (0.0f), origin.translated (111.0f, 0.0f), true);
    crest.addColour (0.44, accent.darker (1.6f).withAlpha (0.40f));
    g.setGradientFill (crest);
    g.setOpacity (0.22f);
    g.fillPath (pillShape);

    g.setColour (juce::Colour (0x8e575360));
    g.strokePath (pillShape, juce::PathStrokeType (1.0f));
    {
        const juce::Graphics::ScopedSaveState state (g);
        g.reduceClipRegion (juce::Rectangle<float> (humpCenterX - 100.0f, humpTopY - 3.0f,
                                                  200.0f, 24.0f).getSmallestIntegerContainer());
        juce::ColourGradient edge (accent.withAlpha (0.91f), origin, accent.darker (5.0f).withAlpha (0.0f),
                                   origin.translated (100.0f, 0.0f), true);
        g.setGradientFill (edge);
        g.setOpacity (0.57f);
        g.strokePath (pillShape, juce::PathStrokeType (1.1f, juce::PathStrokeType::curved));
    }

    // Se estiver no modo de Limiar Manual (!bp.dynAutoThresh), desenha a barra do medidor do sinal detector
    // atrás/abaixo do slider de Threshold manual (Manual Pro-Q 3 p. 14: "The level of the trigger signal is shown in the slider")
    if (manualThresholdSlider.isVisible())
    {
        auto meterArea = manualThreshMeterBounds.toFloat();
        g.setColour (juce::Colour (0xff14161c));
        g.fillRoundedRectangle (meterArea, 3.0f);

        const float detDb = bandDynamics[static_cast<size_t> (attachedBandIndex)].detectorDb;
        const float norm  = juce::jlimit (0.0f, 1.0f, (detDb + 60.0f) / 60.0f);
        if (norm > 0.01f)
        {
            const auto part = meterArea.withTrimmedTop ((1.0f - norm) * meterArea.getHeight());
            juce::ColourGradient level (juce::Colour (0xffeb735e), meterArea.getCentreX(), meterArea.getY(),
                                        juce::Colour (0xff5ccd9c), meterArea.getCentreX(), meterArea.getBottom(), false);
            level.addColour (0.42, kEqGold);
            g.setGradientFill (level);
            g.fillRoundedRectangle (part, 3.0f);
        }

        g.setColour (juce::Colour (0xff484d5c));
        g.drawRoundedRectangle (meterArea, 3.0f, 1.0f);
    }
}

void ProQ3AudioProcessorEditor::drawOutputMeter (juce::Graphics& g, juce::Rectangle<int> bounds)
{
    g.setColour (juce::Colour (0xff1e1e22));
    g.fillRect (bounds);
    g.setColour (juce::Colour (0xff302f37));
    g.fillRect (bounds.getX(), bounds.getY(), 1, bounds.getHeight());

    const float dbL = audioProcessor.getOutputPeakDbL();
    const float dbR = audioProcessor.getOutputPeakDbR();
    const float peak = juce::jmax (audioProcessor.getOutputHeldPeakDb (0), audioProcessor.getOutputHeldPeakDb (1));
    g.setFont (juce::FontOptions (9.5f));
    g.setColour (kTextMuted);
    g.drawText (peak <= -99.9f ? juce::String ("-INF") : juce::String (peak, 1),
                bounds.getX() + 2, bounds.getY() + 1, bounds.getWidth() - 4, 14,
                juce::Justification::centred, false);

    const auto yForDb = [this] (float db)
    {
        return juce::roundToInt (analyzerDbToY (db));
    };

    const auto floor = -getSpectrumDisplayRange();
    g.setColour (juce::Colour (0xff6e6e75));
    for (int db = 0; db >= floor; db -= 10)
        g.drawText (juce::String (db), bounds.getX() + 2, yForDb (static_cast<float> (db)) - 6, 25, 12,
                    juce::Justification::centredRight, false);

    for (int channel = 0; channel < 2; ++channel)
    {
        const int x = bounds.getRight() - 15 + 7 * channel;
        const float level = channel == 0 ? dbL : dbR;
        for (int db = floor + 2; db <= 0; db += 2)
        {
            const auto threshold = static_cast<float> (db);
            const bool lit = level > -99.9f && level >= threshold;
            const auto y = yForDb (threshold);
            const int barHeight = juce::jmax (1, yForDb (threshold - 2.0f) - y - 1);
            g.setColour (! lit ? juce::Colour (0xff292830)
                              : (db >= -2 ? juce::Colour (0xffee6874)
                                         : (db >= -24 ? kEqGold : juce::Colour (0xff84cf9c))));
            g.fillRect (x, y, 5, barHeight);
        }
        const auto held = audioProcessor.getOutputHeldPeakDb (static_cast<size_t> (channel));
        if (held > ProQ3AudioProcessor::kMeterFloorDb && held > static_cast<float> (floor))
        {
            g.setColour (held >= 0.0f ? juce::Colour (0xffee6874) : kEqGold);
            g.fillRect (x, yForDb (held), 5, 2);
        }
    }
}

void ProQ3AudioProcessorEditor::drawBottomToolbar (juce::Graphics& g, juce::Rectangle<int> bounds)
{
    const auto rail = bounds.toFloat().reduced (4.5f, 2.5f);
    juce::ColourGradient graphite (juce::Colour (0xff302b34), rail.getX(), rail.getY(),
                                   juce::Colour (0xff252129), rail.getX(), rail.getBottom(), false);
    g.setGradientFill (graphite);
    g.fillRoundedRectangle (rail, 8.0f);

    g.setColour (juce::Colour (0xff403945));
    g.drawRoundedRectangle (rail, 8.0f, 1.0f);
    for (const int x : { midiLearnButton.getRight() + 6, outputControlButton.getX() - 20 })
        g.drawVerticalLine (x, rail.getY() + 5.0f, rail.getBottom() - 5.0f);

    const float x = static_cast<float> (outputControlButton.getX()) - 14.0f;
    const float y = rail.getCentreY();
    juce::Path speaker;
    speaker.startNewSubPath (x, y - 2.0f);
    speaker.lineTo (x + 2.5f, y - 2.0f);
    speaker.lineTo (x + 5.5f, y - 4.0f);
    speaker.lineTo (x + 5.5f, y + 4.0f);
    speaker.lineTo (x + 2.5f, y + 2.0f);
    speaker.lineTo (x, y + 2.0f);
    speaker.closeSubPath();
    g.setColour (kTextMuted);
    g.fillPath (speaker);
}

//==============================================================================
// Layout Responsivo (Fiel ao Painel da Banda da image_435802.png)
//==============================================================================
void ProQ3AudioProcessorEditor::layoutBandControls()
{
    const int pillW = 472;
    const int pillH = 126;
    const auto band = audioProcessor.getBandParameters (attachedBandIndex);
    const auto anchor = band.used ? juce::roundToInt (frequencyToX (band.freqHz)) : graphBounds.getCentreX();
    const int pillX = juce::jlimit (graphBounds.getX() + 8, graphBounds.getRight() - pillW - 8, anchor - pillW / 2);
    const int pillY = graphBounds.getBottom() - pillH - 28;
    floatingPillBounds = juce::Rectangle<int> (pillX, pillY, pillW, pillH);

    // Coluna esquerda: Power/Bypass, Shape selector (Bell / Flat Tilt / etc.) e Slope (12 dB/oct)
    bandBypassButton.setBounds (pillX + 10, pillY + 8,  22, 20);
    bandShapeBox.setBounds     (pillX + 10, pillY + 38, 46, 28);
    bandSlopeBox.setBounds     (pillX + 10, pillY + 74, 96, 24);

    // Knob 1: FREQ (esquerda)
    freqSlider.setBounds         (pillX + 116, pillY + 20, 68, 68);
    freqRangeHintLabel.setBounds (pillX + 110, pillY + 88, 80, 14);
    freqTitleLabel.setBounds     (pillX + 116, pillY + 103, 68, 16);

    // Knob 2: GAIN + ANEL DINÂMICO (centro, maior que FREQ e Q, como na imagem image_435802.png)
    const int gainCenterX = pillX + 232;
    concentricGainKnob.setBounds (gainCenterX - 42, pillY + 10, 84, 84);
    gainRangeHintLabel.setBounds (gainCenterX - 42, pillY + 88, 84, 14);
    gainTitleLabel.setBounds     (gainCenterX - 34, pillY + 103, 68, 16);

    // Controles do Arco Dinâmico acima/ao redor do GAIN (exatamente nas posições da image_435802.png):
    // 'x' (clear dynamics) à esquerda às 10h, Power (bypass dynamics) às 11h, e "Auto" no topo às 12h
    clearDynamicsButton.setBounds  (gainCenterX - 48, pillY + 8,  18, 18);
    bypassDynamicsButton.setBounds (gainCenterX - 34, pillY - 6,  28, 18);
    autoThresholdButton.setBounds  (gainCenterX - 4,  pillY - 14, 44, 18);
    spectralButton.setBounds       (gainCenterX + 42, pillY - 8, 30, 17);
    spectralTiltButton.setBounds   (gainCenterX + 75, pillY - 8, 29, 17);
    spectralDensitySlider.setBounds (gainCenterX - 41, pillY + 90, 82, 12);

    // Quando "Auto" é desativado (Modo Manual), exibe o slider de Threshold manual, medidor do detector e botão External Sidechain (SC)
    manualThresholdValue.setBounds (gainCenterX - 35, pillY - 33, 94, 18);
    manualThresholdSlider.setBounds (pillX + 273, pillY + 39, 25, 78);
    const auto sliderTrack = lookAndFeel.getSliderLayout (manualThresholdSlider).sliderBounds
        .translated (manualThresholdSlider.getX(), manualThresholdSlider.getY());
    manualThreshMeterBounds = sliderTrack.withSizeKeepingCentre (8, sliderTrack.getHeight());
    externalSidechainButton.setBounds (gainCenterX + 63, pillY - 32, 32, 18);

    // Engrenagem Gain-Q Interaction entre GAIN e Q
    gainQInterButton.setBounds (pillX + 276, pillY + 22, 24, 16);

    // Knob 3: Q (direita)
    qSlider.setBounds         (pillX + 298, pillY + 20, 68, 68);
    qRangeHintLabel.setBounds (pillX + 292, pillY + 88, 80, 14);
    qTitleLabel.setBounds     (pillX + 298, pillY + 103, 68, 16);

    // Coluna direita: < 1 >, 'X' (excluir banda no canto superior direito), Stereo e Split/Solo
    prevBandButton.setBounds   (pillX + 378, pillY + 8,  18, 20);
    bandNumberLabel.setBounds  (pillX + 396, pillY + 8,  22, 20);
    nextBandButton.setBounds   (pillX + 418, pillY + 8,  18, 20);
    deleteBandButton.setBounds (pillX + 444, pillY + 8,  20, 20);

    stereoModeBox.setBounds     (pillX + 376, pillY + 38, 86, 28);
    soloBandButton.setBounds    (pillX + 376, pillY + 74, 42, 24);
    splitStereoButton.setBounds (pillX + 420, pillY + 74, 42, 24);

}
 
void ProQ3AudioProcessorEditor::resized()
{
    auto area = getLocalBounds();

    topBarBounds    = area.removeFromTop (36);
    bottomBarBounds = area.removeFromBottom (36);
    meterBounds     = area.removeFromRight (44);
    pianoBounds     = area.withTrimmedTop (area.getHeight() - 22);
    graphBounds     = area;

    //---- Top Bar ----
    int tx = 206;
    const int ty = 6;
    const int th = 24;

    undoButton.setBounds (tx, ty, 48, th); tx += 52;
    redoButton.setBounds (tx, ty, 48, th); tx += 58;
    abButton.setBounds   (tx, ty, 42, th); tx += 46;
    copyButton.setBounds (tx, ty, 48, th);

    const int presetW = 240;
    const int presetX = juce::jmax (tx + 60, (topBarBounds.getWidth() - presetW) / 2);
    prevPresetButton.setBounds (presetX, ty, 24, th);
    presetNameButton.setBounds (presetX + 26, ty, presetW - 52, th);
    nextPresetButton.setBounds (presetX + presetW - 24, ty, 24, th);

    helpButton.setBounds (topBarBounds.getRight() - 91, ty, 48, th);
    expandButton.setBounds (topBarBounds.getRight() - 37, ty, 25, th);

    layoutBandControls();

    displayRangeButton.setBounds (graphBounds.getRight() - 68, graphBounds.getY() + 8, 58, 22);

    auto footer = bottomBarBounds.reduced (14, 6).withTrimmedRight (12);
    eqSketchButton.setBounds (footer.removeFromLeft (25));
    pianoToggleButton.setBounds (footer.removeFromLeft (32));
    footer.removeFromLeft (9);
    midiLearnButton.setBounds (footer.removeFromLeft (100));
    footer.removeFromLeft (12);
    globalBypassButton.setBounds (footer.removeFromRight (73));
    outputControlButton.setBounds (footer.removeFromRight (116));
    footer.removeFromRight (21);

    auto leftFooter = footer.removeFromLeft (footer.getWidth() / 2);
    const auto trackWidth = juce::jmin (112, leftFooter.getWidth() / 2);
    instanceButton.setBounds (leftFooter.removeFromRight (trackWidth).reduced (3, 0));
    processingModeBox.setBounds (leftFooter.withSizeKeepingCentre (juce::jmin (142, leftFooter.getWidth()), leftFooter.getHeight()));
    instanceOverview.setBounds (getLocalBounds().reduced (7));
    characterBox.setBounds (footer.removeFromRight (65).reduced (2, 0));
    analyzerButton.setBounds (footer.withSizeKeepingCentre (juce::jmin (160, footer.getWidth()), footer.getHeight()));
    analyzerBackdrop.setBounds (getLocalBounds());
    layoutAnalyzerPanel();
    const auto matchX = juce::jlimit (8, getWidth() - 376, analyzerButton.getBounds().getCentreX() - 184);
    matchPanel.setBounds (matchX, bottomBarBounds.getY() - 164, 368, 159);

    constexpr int panelWidth = 196;
    constexpr int panelHeight = 199;
    const int panelX = juce::jlimit (8, getWidth() - panelWidth - 8, outputControlButton.getBounds().getCentreX() - panelWidth / 2);
    outputPanel.setBounds (panelX, outputControlButton.getY() - panelHeight - 2, panelWidth, panelHeight);
    outputLevelLabel.setBounds (8, 6, panelWidth - 16, 19);
    outputGainSlider.setBounds (52, 24, 92, 80);
    outputScaleLabel.setBounds (10, 113, 63, 22);
    outputScaleSlider.setBounds (72, 113, 114, 22);
    outputBalanceLabel.setBounds (10, 140, 57, 22);
    outputBalanceSlider.setBounds (67, 140, 67, 22);
    outputBalanceModeBox.setBounds (136, 140, 50, 22);
    outputPolarityButton.setBounds (10, 169, 40, 21);
    outputAutoGainButton.setBounds (56, 169, 40, 21);
    outputOptionsButton.setBounds (144, 169, 42, 21);
}
