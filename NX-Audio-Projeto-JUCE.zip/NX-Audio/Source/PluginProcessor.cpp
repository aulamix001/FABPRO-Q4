#include "PluginProcessor.h"
#include "PluginEditor.h"
#include "FactoryPresets.h"
#include <cmath>
#include <cstring>

namespace
{
    const juce::Identifier factoryPresetProperty { "factoryPreset" };

    constexpr double kPi = 3.1415926535897932384626433832795;

    constexpr std::array<int, 10> filterOrders { 1, 2, 3, 4, 5, 6, 8, 12, 16, 16 };

    int getFilterOrder (int slopeIndex) noexcept
    {
        return filterOrders[static_cast<size_t> (juce::jlimit (0, 9, slopeIndex))];
    }

    void designCutFilter (int order, double frequency, double sampleRate,
                          double resonance, bool highPass,
                          std::array<ProQ3AudioProcessor::BiquadCoeffs, ProQ3AudioProcessor::kMaxCascadedSections>& coeffs) noexcept
    {
        const auto w = 2.0 * kPi * frequency / sampleRate;
        const auto cosine = std::cos (w);
        const auto sine = std::sin (w);
        const auto numerator = 0.5 * (highPass ? 1.0 + cosine : 1.0 - cosine);
        const auto sign = highPass ? -1.0 : 1.0;
        const auto firstBiquad = order % 2;
        if (firstBiquad != 0)
        {
            const auto tangent = std::tan (0.5 * w);
            const auto b0 = (highPass ? 1.0 : tangent) / (1.0 + tangent);
            coeffs.front() = { b0, sign * b0, 0.0, (tangent - 1.0) / (tangent + 1.0), 0.0 };
        }

        const auto pairs = order / 2;
        for (int pair = 0; pair < pairs; ++pair)
        {
            // Use the Butterworth pole pairs, ordered from lowest to highest Q.
            const auto angle = kPi * (2 * (pairs - pair) - 1) / (2.0 * order);
            const auto q = 0.5 / std::sin (angle) * (pair == pairs - 1 ? resonance : 1.0);
            const auto alpha = sine / (2.0 * q);
            const auto a0 = 1.0 + alpha;
            coeffs[static_cast<size_t> (firstBiquad + pair)] = {
                numerator / a0, sign * 2.0 * numerator / a0, numerator / a0,
                -2.0 * cosine / a0, (1.0 - alpha) / a0
            };
        }
    }
}

ProQ3AudioProcessor::ProQ3AudioProcessor()
    : AudioProcessor (BusesProperties()
                        .withInput  ("Input",     juce::AudioChannelSet::stereo(), true)
                        .withOutput ("Output",    juce::AudioChannelSet::stereo(), true)
                        .withInput  ("Sidechain", juce::AudioChannelSet::stereo(), true)),
      apvts (*this, &undoManager, "ProQ3Parameters", createParameterLayout())
{
    for (int i = 0; i < kMaxBands; ++i)
    {
        const auto parameter = [this, i] (const char* suffix)
        {
            return apvts.getRawParameterValue (getBandParamID (i, suffix));
        };
        bandParameterValues[static_cast<size_t> (i)] = {
            parameter ("used"), parameter ("enabled"), parameter ("shape"),
            parameter ("freq"), parameter ("gain"), parameter ("q"),
            parameter ("slope"), parameter ("stereo"), parameter ("gain_q"),
            parameter ("dyn_range"), parameter ("dyn_enabled"), parameter ("dyn_auto"),
            parameter ("dyn_thresh"), parameter ("dyn_ext_sc"), parameter ("spectral"), parameter ("all_pass"),
            parameter ("spectral_density"), parameter ("spectral_tilt"), parameter ("signal_target")
        };
        publishBandDynamics (static_cast<size_t> (i), {});
        for (auto& gain : spectralGains[static_cast<size_t> (i)])
            gain.store (0.0f, std::memory_order_relaxed);
    }

    splitEqParameter = apvts.getRawParameterValue ("split_eq");
    midiOutputParameters = { apvts.getParameter ("global_output_gain"), apvts.getParameter ("global_gain_scale") };
    apvts.state.setProperty (factoryPresetProperty, "Default Setting", nullptr);
    stateA = apvts.copyState();
    stateB = apvts.copyState();
    updateAllFilterCoefficients();
    auto& registry = (*sharedInstances);
    const juce::ScopedLock lock (registry.mutex);
    spectrumPeerId = registry.nextId++;
    overviewTarget->processor = this;
    registry.instances.push_back (this);
}

ProQ3AudioProcessor::~ProQ3AudioProcessor()
{
    {
        const juce::ScopedLock lock (overviewTarget->mutex);
        overviewTarget->processor = nullptr;
    }

    auto& registry = (*sharedInstances);
    const juce::ScopedLock lock (registry.mutex);
    registry.instances.erase (std::remove (registry.instances.begin(), registry.instances.end(), this),
                              registry.instances.end());
}

juce::String ProQ3AudioProcessor::getBandParamID (int bandIndex, const juce::String& suffix)
{
    return "band" + juce::String (bandIndex + 1).paddedLeft ('0', 2) + "_" + suffix;
}

bool ProQ3AudioProcessor::doesShapeSupportGain (int shape) noexcept
{
    // Manual Pro-Q 3 p. 11: "The gain knob sets the gain in dB... This setting is only used for Bell, Shelving and Tilt filter types."
    return (shape == kShapeBell
         || shape == kShapeLowShelf
         || shape == kShapeHighShelf
         || shape == kShapeTiltShelf
         || shape == kShapeFlatTilt);
}

bool ProQ3AudioProcessor::doesShapeSupportDynamics (int shape) noexcept
{
    // Manual Pro-Q 3 p. 11 & p. 13: "any of Pro-Q's bands (with Bell or Shelf shapes) can be made dynamic, at any slope"
    // "Note that this setting is only available for Bell and Shelving filter types" (Bell, Low Shelf, High Shelf, Tilt Shelf).
    return (shape == kShapeBell
         || shape == kShapeLowShelf
         || shape == kShapeHighShelf
         || shape == kShapeTiltShelf);
}

bool ProQ3AudioProcessor::doesShapeSupportQ (int shape, int slopeIndex) noexcept
{
    // Manual Pro-Q 3 p. 11: "The Q cannot be adjusted when a 6 dB/octave Notch is used" (e Flat Tilt usa inclinação plana em todo o espectro)
    if (shape == kShapeFlatTilt)
        return false;
    if (shape == kShapeNotch && slopeIndex == kSlope6dB)
        return false;
    if ((shape == kShapeLowCut || shape == kShapeHighCut)
        && (slopeIndex == kSlope6dB || slopeIndex == kSlopeBrickwall))
        return false;
    return true;
}

juce::AudioProcessorValueTreeState::ParameterLayout ProQ3AudioProcessor::createParameterLayout()
{
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> params;
    params.reserve (kMaxBands * 14 + 16);

    juce::NormalisableRange<float> freqRange (10.0f, 30000.0f,
        [] (float start, float end, float norm) -> float
        {
            return start * std::pow (end / start, norm);
        },
        [] (float start, float end, float val) -> float
        {
            return std::log (juce::jlimit (start, end, val) / start) / std::log (end / start);
        },
        [] (float start, float end, float val) -> float
        {
            return juce::jlimit (start, end, val);
        });

    juce::NormalisableRange<float> qRange (0.025f, 40.0f,
        [] (float start, float end, float norm) -> float
        {
            return start * std::pow (end / start, norm);
        },
        [] (float start, float end, float val) -> float
        {
            return std::log (juce::jlimit (start, end, val) / start) / std::log (end / start);
        },
        [] (float start, float end, float val) -> float
        {
            return juce::jlimit (start, end, val);
        });

    juce::NormalisableRange<float> gainRange (-30.0f, 30.0f, 0.01f);
    juce::NormalisableRange<float> dynRange  (-30.0f, 30.0f, 0.01f);
    juce::NormalisableRange<float> threshRange (-60.0f, 0.0f, 0.1f);

    const juce::StringArray shapeChoices {
        "Bell", "Low Shelf", "Low Cut", "High Shelf", "High Cut",
        "Notch", "Band Pass", "Tilt Shelf", "Flat Tilt"
    };

    const juce::StringArray slopeChoices {
        "6 dB/oct", "12 dB/oct", "18 dB/oct", "24 dB/oct",
        "30 dB/oct", "36 dB/oct", "48 dB/oct", "72 dB/oct",
        "96 dB/oct", "Brickwall"
    };

    const juce::StringArray stereoChoices {
        "Stereo", "Left", "Right", "Mid", "Side"
    };

    const std::array<float, kMaxBands> defaultFreqs {
        1000.0f, 100.0f, 250.0f, 500.0f, 2000.0f, 4000.0f, 8000.0f, 12000.0f,
        50.0f,   80.0f,  160.0f, 320.0f, 640.0f,  1250.0f, 2500.0f, 5000.0f,
        10000.0f, 16000.0f, 40.0f, 125.0f, 800.0f, 1600.0f, 3150.0f, 6300.0f
    };

    for (int i = 0; i < kMaxBands; ++i)
    {
        const juce::String prefix = "Band " + juce::String (i + 1) + " ";

        // IDs originais preservados 100% intactos
        params.push_back (std::make_unique<juce::AudioParameterBool> (
            juce::ParameterID { getBandParamID (i, "used"), 1 },
            prefix + "Used",
            false));

        params.push_back (std::make_unique<juce::AudioParameterBool> (
            juce::ParameterID { getBandParamID (i, "enabled"), 1 },
            prefix + "Enabled",
            true));

        params.push_back (std::make_unique<juce::AudioParameterChoice> (
            juce::ParameterID { getBandParamID (i, "shape"), 1 },
            prefix + "Shape",
            shapeChoices,
            0)); // Bell padrão

        params.push_back (std::make_unique<juce::AudioParameterFloat> (
            juce::ParameterID { getBandParamID (i, "freq"), 1 },
            prefix + "Frequency",
            freqRange,
            defaultFreqs[static_cast<size_t> (i)],
            juce::AudioParameterFloatAttributes().withLabel ("Hz")));

        params.push_back (std::make_unique<juce::AudioParameterFloat> (
            juce::ParameterID { getBandParamID (i, "gain"), 1 },
            prefix + "Gain",
            gainRange,
            0.0f,
            juce::AudioParameterFloatAttributes().withLabel ("dB")));

        params.push_back (std::make_unique<juce::AudioParameterFloat> (
            juce::ParameterID { getBandParamID (i, "q"), 1 },
            prefix + "Q",
            qRange,
            1.0f));

        params.push_back (std::make_unique<juce::AudioParameterChoice> (
            juce::ParameterID { getBandParamID (i, "slope"), 1 },
            prefix + "Slope",
            slopeChoices,
            1)); // 12 dB/oct padrão

        params.push_back (std::make_unique<juce::AudioParameterChoice> (
            juce::ParameterID { getBandParamID (i, "stereo"), 1 },
            prefix + "Stereo Placement",
            stereoChoices,
            0)); // Stereo padrão

        params.push_back (std::make_unique<juce::AudioParameterBool> (
            juce::ParameterID { getBandParamID (i, "gain_q"), 1 },
            prefix + "Gain-Q Interaction",
            false));

        // Novos parâmetros de EQ Dinâmico e Sidechain (Manual Pro-Q 3 p. 13-14)
        params.push_back (std::make_unique<juce::AudioParameterFloat> (
            juce::ParameterID { getBandParamID (i, "dyn_range"), 1 },
            prefix + "Dynamic Range",
            dynRange,
            0.0f,
            juce::AudioParameterFloatAttributes().withLabel ("dB")));

        params.push_back (std::make_unique<juce::AudioParameterBool> (
            juce::ParameterID { getBandParamID (i, "dyn_enabled"), 1 },
            prefix + "Dynamics Enabled",
            true));

        params.push_back (std::make_unique<juce::AudioParameterBool> (
            juce::ParameterID { getBandParamID (i, "dyn_auto"), 1 },
            prefix + "Dynamic Auto Threshold",
            true));

        params.push_back (std::make_unique<juce::AudioParameterFloat> (
            juce::ParameterID { getBandParamID (i, "dyn_thresh"), 1 },
            prefix + "Dynamic Threshold",
            threshRange,
            -18.0f,
            juce::AudioParameterFloatAttributes().withLabel ("dB")));

        params.push_back (std::make_unique<juce::AudioParameterBool> (
            juce::ParameterID { getBandParamID (i, "dyn_ext_sc"), 1 },
            prefix + "External Side Chain",
            false));
    }

    // Controles globais da barra inferior
    params.push_back (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID { "global_output_gain", 1 },
        "Output Level",
        juce::NormalisableRange<float> (-36.0f, 36.0f, 0.1f),
        0.0f,
        juce::AudioParameterFloatAttributes().withLabel ("dB")));

    params.push_back (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID { "global_gain_scale", 1 },
        "Gain Scale",
        juce::NormalisableRange<float> (0.0f, 200.0f, 1.0f),
        100.0f,
        juce::AudioParameterFloatAttributes().withLabel ("%")));

    params.push_back (std::make_unique<juce::AudioParameterBool> (
        juce::ParameterID { "global_bypass", 1 },
        "Global Bypass",
        false));

    params.push_back (std::make_unique<juce::AudioParameterBool> (
        juce::ParameterID { "global_phase_invert", 1 },
        "Phase Invert",
        false));

    params.push_back (std::make_unique<juce::AudioParameterBool> (
        juce::ParameterID { "global_auto_gain", 1 },
        "Auto Gain",
        false));

    params.push_back (std::make_unique<juce::AudioParameterChoice> (
        juce::ParameterID { "display_range", 1 },
        "Display Range",
        juce::StringArray { "3 dB", "6 dB", "12 dB", "30 dB" },
        2)); // 12 dB padrão

    params.push_back (std::make_unique<juce::AudioParameterChoice> (
        juce::ParameterID { "processing_mode", 1 },
        "Processing Mode",
        juce::StringArray { "Zero Latency", "Natural Phase", "Linear Phase" },
        0)); // Zero Latency padrão

    params.push_back (std::make_unique<juce::AudioParameterBool> (
        juce::ParameterID { "analyzer_pre", 1 },
        "Analyzer Pre-EQ",
        true));

    params.push_back (std::make_unique<juce::AudioParameterBool> (
        juce::ParameterID { "analyzer_post", 1 },
        "Analyzer Post-EQ",
        true));

    params.push_back (std::make_unique<juce::AudioParameterBool> (
        juce::ParameterID { "analyzer_sc", 1 },
        "Analyzer External Sidechain",
        false));

    params.push_back (std::make_unique<juce::AudioParameterBool> (
        juce::ParameterID { "piano_display", 1 },
        "Piano Display",
        false));

    // Appended so existing host automation indices remain intact.
    params.push_back (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID { "global_output_balance", 1 },
        "Output Balance",
        juce::NormalisableRange<float> (-100.0f, 100.0f, 1.0f),
        0.0f));

    params.push_back (std::make_unique<juce::AudioParameterChoice> (
        juce::ParameterID { "global_output_balance_mode", 1 },
        "Output Balance Mode",
        juce::StringArray { "L/R", "M/S" },
        0));

    params.push_back (std::make_unique<juce::AudioParameterBool> (
        juce::ParameterID { "analyzer_peak_alerts", 1 },
        "Spectrum Peak Alerts",
        true));

    params.push_back (std::make_unique<juce::AudioParameterChoice> (
        juce::ParameterID { "analyzer_speed", 1 }, "Spectrum Speed",
        juce::StringArray { "Slow", "Normal", "Fast" }, 1));
    params.push_back (std::make_unique<juce::AudioParameterChoice> (
        juce::ParameterID { "analyzer_tilt", 1 }, "Spectrum Tilt",
        juce::StringArray { "Flat", "3 dB/oct", "4.5 dB/oct", "6 dB/oct" }, 2));
    params.push_back (std::make_unique<juce::AudioParameterChoice> (
        juce::ParameterID { "analyzer_range", 1 }, "Spectrum Display Range",
        juce::StringArray { "60 dB", "90 dB", "100 dB", "120 dB" }, 2));
    params.push_back (std::make_unique<juce::AudioParameterChoice> (
        juce::ParameterID { "analyzer_detail", 1 }, "Spectrum Trace Detail",
        juce::StringArray { "Smooth", "Balanced", "Detailed" }, 1));

    params.push_back (std::make_unique<juce::AudioParameterChoice> (
        juce::ParameterID { "analyzer_resolution", 1 }, "Spectrum FFT Resolution",
        juce::StringArray { "1024", "2048", "4096", "8192" }, 2));

    params.push_back (std::make_unique<juce::AudioParameterBool> (
        juce::ParameterID { "analyzer_overlap", 1 }, "Spectrum Overlap", true));

    // The separate All Pass switch keeps the original nine-value shape automation range.
    for (int band = 0; band < kMaxBands; ++band)
    {
        const auto name = "Band " + juce::String (band + 1);
        params.push_back (std::make_unique<juce::AudioParameterBool> (
            juce::ParameterID { getBandParamID (band, "spectral"), 1 }, name + " Spectral", false));
        params.push_back (std::make_unique<juce::AudioParameterBool> (
            juce::ParameterID { getBandParamID (band, "all_pass"), 1 }, name + " All Pass", false));
    }

    params.push_back (std::make_unique<juce::AudioParameterChoice> (
        juce::ParameterID { "output_character", 1 }, "Character",
        juce::StringArray { "Clean", "Subtle", "Warm" }, 0));

    for (int band = 0; band < kMaxBands; ++band)
    {
        const auto name = "Band " + juce::String (band + 1);
        params.push_back (std::make_unique<juce::AudioParameterFloat> (
            juce::ParameterID { getBandParamID (band, "spectral_density"), 1 }, name + " Spectral Density",
            juce::NormalisableRange<float> (0.0f, 1.0f, 0.01f), 0.5f));
        params.push_back (std::make_unique<juce::AudioParameterBool> (
            juce::ParameterID { getBandParamID (band, "spectral_tilt"), 1 }, name + " Spectral Tilt", true));
    }
    params.push_back (std::make_unique<juce::AudioParameterBool> (
        juce::ParameterID { "split_eq", 1 }, "Transient / Tonal EQ", false));
    for (int band = 0; band < kMaxBands; ++band)
        params.push_back (std::make_unique<juce::AudioParameterChoice> (
            juce::ParameterID { getBandParamID (band, "signal_target"), 1 },
            "Band " + juce::String (band + 1) + " Signal",
            juce::StringArray { "Both", "Transient", "Tonal" }, 0));

    return { params.begin(), params.end() };
}

const juce::String ProQ3AudioProcessor::getName() const { return JucePlugin_Name; }
bool ProQ3AudioProcessor::acceptsMidi() const { return true; }
bool ProQ3AudioProcessor::producesMidi() const { return false; }
bool ProQ3AudioProcessor::isMidiEffect() const { return false; }
double ProQ3AudioProcessor::getTailLengthSeconds() const { return 0.0; }
int ProQ3AudioProcessor::getNumPrograms() { return 1; }
int ProQ3AudioProcessor::getCurrentProgram() { return 0; }
void ProQ3AudioProcessor::setCurrentProgram (int) {}
const juce::String ProQ3AudioProcessor::getProgramName (int) { return "Default"; }
void ProQ3AudioProcessor::changeProgramName (int, const juce::String&) {}

void ProQ3AudioProcessor::prepareToPlay (double sampleRate, int /*samplesPerBlock*/)
{
    currentSampleRate.store (sampleRate > 0.0 ? sampleRate : 44100.0, std::memory_order_relaxed);

    resetEqProcessing();
    splitWasProcessing = false;
    preFftFifo.resetHistory();
    postFftFifo.resetHistory();
    sidechainFftFifo.resetHistory();
    outputPeakDbL.store (kMeterFloorDb, std::memory_order_relaxed);
    outputPeakDbR.store (kMeterFloorDb, std::memory_order_relaxed);
    for (auto& peak : outputHeldPeakDb)
        peak.store (kMeterFloorDb, std::memory_order_relaxed);
    meterHoldSamples.fill (0);
    characterAmount.reset (getCurrentSampleRate(), 0.014);
    characterAmount.setCurrentAndTargetValue (apvts.getRawParameterValue ("output_character")->load (std::memory_order_relaxed));
    characterDc.fill (0.0f);
    characterTone.fill (0.0f);
    soloBlend.reset (getCurrentSampleRate(), 0.012);
    soloBlend.setCurrentAndTargetValue (0.0f);
    soloGain.reset (getCurrentSampleRate(), 0.012);
    soloGain.setCurrentAndTargetValue (juce::Decibels::decibelsToGain (-6.0f));
    renderedSoloBand = -1;
    updateAllFilterCoefficients();
}

void ProQ3AudioProcessor::releaseResources() {}

bool ProQ3AudioProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
    const auto mainIn  = layouts.getMainInputChannelSet();
    const auto mainOut = layouts.getMainOutputChannelSet();

    if (mainIn != mainOut)
        return false;

    if (mainOut != juce::AudioChannelSet::mono() && mainOut != juce::AudioChannelSet::stereo())
        return false;

    // Barramento Sidechain opcional (pode estar desabilitado, mono ou estéreo no Studio One)
    if (layouts.inputBuses.size() > 1)
    {
        const auto scIn = layouts.getChannelSet (true, 1);
        if (! scIn.isDisabled()
            && scIn != juce::AudioChannelSet::mono()
            && scIn != juce::AudioChannelSet::stereo())
            return false;
    }

    return true;
}

ProQ3AudioProcessor::BandParameters ProQ3AudioProcessor::getBandParameters (int bandIndex) const noexcept
{
    BandParameters bp;
    if (bandIndex < 0 || bandIndex >= kMaxBands)
        return bp;

    const auto& values = bandParameterValues[static_cast<size_t> (bandIndex)];
    const auto getVal = [] (const std::atomic<float>* value, float fallback)
    {
        return value != nullptr ? value->load (std::memory_order_relaxed) : fallback;
    };

    bp.used           = getVal (values.used, 0.0f) >= 0.5f;
    bp.enabled        = getVal (values.enabled, 1.0f) >= 0.5f;
    bp.shape          = getVal (values.allPass, 0.0f) >= 0.5f ? kShapeAllPass
                      : static_cast<int> (std::lround (getVal (values.shape, 0.0f)));
    bp.freqHz         = getVal (values.freqHz, 1000.0f);
    bp.gainDb         = getVal (values.gainDb, 0.0f);
    bp.q              = getVal (values.q, 1.0f);
    bp.slopeIndex     = static_cast<int> (std::lround (getVal (values.slopeIndex, 1.0f)));
    bp.stereoMode     = static_cast<int> (std::lround (getVal (values.stereoMode, 0.0f)));
    bp.gainQInter     = getVal (values.gainQInter, 0.0f) >= 0.5f;
    bp.dynRangeDb     = getVal (values.dynRangeDb, 0.0f);
    bp.dynEnabled     = getVal (values.dynEnabled, 1.0f) >= 0.5f;
    bp.dynAutoThresh  = getVal (values.dynAutoThresh, 1.0f) >= 0.5f;
    bp.dynThresholdDb = getVal (values.dynThresholdDb, -18.0f);
    bp.dynExtSidechain = getVal (values.dynExtSidechain, 0.0f) >= 0.5f;
    bp.spectral = getVal (values.spectral, 0.0f) >= 0.5f;
    bp.spectralDensity = getVal (values.spectralDensity, 0.5f);
    bp.spectralTilt = getVal (values.spectralTilt, 1.0f) >= 0.5f;
    bp.signalTarget = static_cast<SignalTarget> (juce::roundToInt (getVal (values.signalTarget, 0.0f)));

    return bp;
}

void ProQ3AudioProcessor::computeBandDetectorCoeffs (double freqHz, double q, double sampleRate, BiquadCoeffs& outCoeffs) noexcept
{
    if (sampleRate <= 0.0)
    {
        outCoeffs = BiquadCoeffs {};
        return;
    }

    // Manual Pro-Q 3 p. 13: "Internally, the dynamic EQ process will trigger on a band-limited version of the plug-in's input, according to the frequency range the band works on."
    const double f0 = juce::jlimit (15.0, 0.49 * sampleRate, freqHz);
    const double detQ = juce::jlimit (0.35, 12.0, q * 0.7071067811865475);
    const double w0 = 2.0 * kPi * f0 / sampleRate;
    const double alpha = std::sin (w0) / (2.0 * detQ);
    const double invA0 = 1.0 / (1.0 + alpha);

    outCoeffs.b0 =  alpha * invA0;
    outCoeffs.b1 =  0.0;
    outCoeffs.b2 = -alpha * invA0;
    outCoeffs.a1 = (-2.0 * std::cos (w0)) * invA0;
    outCoeffs.a2 = (1.0 - alpha) * invA0;
}

void ProQ3AudioProcessor::publishBandDynamics (size_t band, BandDynamicsReading reading, bool tonalReading) noexcept
{
    // Publish one coherent reading without locking the audio thread.
    static_assert (std::atomic<juce::uint64>::is_always_lock_free);
    static_assert (sizeof (reading) == sizeof (juce::uint64));
    juce::uint64 packed;
    std::memcpy (&packed, &reading, sizeof (packed));
    (tonalReading ? tonalBandDynamicsReadings : bandDynamicsReadings)[band].store (packed, std::memory_order_relaxed);
}

ProQ3AudioProcessor::BandDynamicsReading ProQ3AudioProcessor::getBandDynamicsReading (int bandIndex, bool tonalReading) const noexcept
{
    if (bandIndex < 0 || bandIndex >= kMaxBands)
        return {};

    const auto& readings = tonalReading ? tonalBandDynamicsReadings : bandDynamicsReadings;
    const auto packed = readings[static_cast<size_t> (bandIndex)].load (std::memory_order_relaxed);
    BandDynamicsReading reading;
    std::memcpy (&reading, &packed, sizeof (packed));
    return reading;
}

double ProQ3AudioProcessor::processDynamicEnvelopeSample (const BandParameters& bp,
                                                          BandDynamicState& dynState,
                                                          double detectorInputSample,
                                                          double sampleRate,
                                                          std::optional<double> detectorRightSample) noexcept
{
    const auto& c = dynState.detectorBpCoeffs;
    auto& state = dynState.detectorBpState;
    const auto bandLimitedLevel = [&c] (double input, double& z1, double& z2)
    {
        const double filtered = c.b0 * input + z1;
        z1 = c.b1 * input - c.a1 * filtered + z2;
        z2 = c.b2 * input - c.a2 * filtered;
        return std::abs (filtered);
    };

    const auto leftLevel = bandLimitedLevel (detectorInputSample, state.z1L, state.z2L);
    const auto rightLevel = bandLimitedLevel (detectorRightSample.value_or (0.0), state.z1R, state.z2R);
    return updateDynamicEnvelope (bp, dynState, detectorRightSample ? juce::jmax (leftLevel, rightLevel) : leftLevel,
                                  sampleRate);
}

double ProQ3AudioProcessor::updateDynamicEnvelope (const BandParameters& bp, BandDynamicState& dynState,
                                                    double absSig, double sampleRate) noexcept
{
    // Constantes de tempo dependentes da frequência e do programa (Manual Pro-Q 3 p. 13:
    // "attack, release and knee all depend on the processed audio, the frequency range of the EQ band and the current dynamic range")
    const double freqScale = juce::jlimit (0.35, 2.5, std::sqrt (1000.0 / juce::jmax (20.0, bp.freqHz)));
    const double attackSec  = 0.0035 * freqScale;
    const double releaseSec = 0.0550 * freqScale;

    const double attCoeff = std::exp (-1.0 / juce::jmax (1.0, attackSec * sampleRate));
    const double relCoeff = std::exp (-1.0 / juce::jmax (1.0, releaseSec * sampleRate));

    if (absSig > dynState.fastEnvLin)
        dynState.fastEnvLin = attCoeff * dynState.fastEnvLin + (1.0 - attCoeff) * absSig;
    else
        dynState.fastEnvLin = relCoeff * dynState.fastEnvLin + (1.0 - relCoeff) * absSig;

    // Atualiza referência adaptativa lenta para o modo Auto Threshold (~350 ms)
    const double slowCoeff = std::exp (-1.0 / juce::jmax (1.0, 0.35 * sampleRate));
    if (absSig > 1.0e-5)
        dynState.slowAutoRefLin = slowCoeff * dynState.slowAutoRefLin + (1.0 - slowCoeff) * absSig;

    const double envDb = (dynState.fastEnvLin > 1.0e-6)
                            ? (20.0 * std::log10 (dynState.fastEnvLin))
                            : -100.0;
    dynState.detectorLevelDb = envDb;

    // Se a forma não suporta dinâmica (ex: Flat Tilt, Low/High Cut, Notch, Band Pass),
    // ou se o botão de Bypass Dynamics estiver desligado, ou se a faixa dinâmica for 0 dB:
    // o ganho dinâmico aplicado pelo DSP é exatamente 0.0 dB (banda puramente estática)
    if (! doesShapeSupportDynamics (bp.shape) || ! bp.dynEnabled || std::abs (bp.dynRangeDb) < 1.0e-4)
    {
        dynState.smoothedGainModDb *= 0.90;
        if (std::abs (dynState.smoothedGainModDb) < 1.0e-4)
            dynState.smoothedGainModDb = 0.0;
        return dynState.smoothedGainModDb;
    }

    // Determina o limiar efetivo em dB (Auto vs Manual)
    double effectiveThreshDb = bp.dynThresholdDb;
    if (bp.dynAutoThresh)
    {
        // No modo Auto Threshold (Manual p. 14: "the threshold is constantly adjusting to the level of the current, band-limited trigger signal"),
        // ancora o limiar 4.5 dB abaixo do nível médio recente (com piso em -48 dB)
        const double autoRefDb = (dynState.slowAutoRefLin > 1.0e-5)
                                    ? (20.0 * std::log10 (dynState.slowAutoRefLin))
                                    : -48.0;
        effectiveThreshDb = juce::jlimit (-54.0, -3.0, autoRefDb - 4.5);
    }

    // Soft knee de 6 dB (Manual p. 14: "a soft knee is used internally by the dynamic EQ algorithm, so it can start triggering a little bit below the selected threshold value")
    const double overDb = envDb - effectiveThreshDb;
    const double kneeWidthDb = 6.0;
    const double fullRangeSpanDb = 12.0; // 12 dB acima do limiar atinge ~100% da faixa dinâmica configurada

    double normTrigger = 0.0;
    if (overDb <= -0.5 * kneeWidthDb)
    {
        normTrigger = 0.0;
    }
    else if (overDb < 0.5 * kneeWidthDb)
    {
        const double t = (overDb + 0.5 * kneeWidthDb) / kneeWidthDb;
        const double softDb = 0.5 * kneeWidthDb * t * t;
        normTrigger = softDb / fullRangeSpanDb;
    }
    else
    {
        normTrigger = overDb / fullRangeSpanDb;
    }

    // Saturação suave assintótica em [0.0, 1.0] para preservar naturalidade musical
    normTrigger = juce::jlimit (0.0, 1.0, normTrigger / (1.0 + 0.35 * juce::jmax (0.0, normTrigger - 0.65)));

    const double targetModDb = bp.dynRangeDb * normTrigger;
    const double modSmooth = (std::abs (targetModDb) > std::abs (dynState.smoothedGainModDb)) ? attCoeff : relCoeff;
    dynState.smoothedGainModDb = modSmooth * dynState.smoothedGainModDb + (1.0 - modSmooth) * targetModDb;

    return dynState.smoothedGainModDb;
}

void ProQ3AudioProcessor::computeFilterCascadeCoeffs (const BandParameters& params,
                                                      double sampleRate,
                                                      double gainScale,
                                                      double dynamicGainOffsetDb,
                                                      std::array<BiquadCoeffs, kMaxCascadedSections>& outCoeffs,
                                                      int& outNumSections) noexcept
{
    const auto order = getFilterOrder (params.slopeIndex);
    outNumSections = (order + 1) / 2;
    for (auto& c : outCoeffs)
        c = BiquadCoeffs {};

    if (! params.used || ! params.enabled || sampleRate <= 0.0)
        return;

    const double nyquist = 0.498 * sampleRate;
    const double f0 = juce::jlimit (10.0, nyquist, params.freqHz);
    if (params.shape == kShapeLowCut || params.shape == kShapeHighCut)
    {
        const auto resonance = order == 1 || params.slopeIndex == kSlopeBrickwall
            ? 1.0 : juce::jlimit (0.025, 40.0, params.q);
        designCutFilter (order, f0, sampleRate, resonance, params.shape == kShapeLowCut, outCoeffs);
        return;
    }

    const double w0 = 2.0 * kPi * f0 / sampleRate;
    const double cosW0 = std::cos (w0);
    const double sinW0 = std::sin (w0);

    // Compensação de cramping perto de Nyquist (Pro-Q 3 Zero Latency analog magnitude matching)
    const double nyquistRatio = f0 / (0.5 * sampleRate);
    const double crampComp = 1.0 / std::sqrt (juce::jmax (0.15, 1.0 - 0.65 * nyquistRatio * nyquistRatio));

    // Q=1.0 no Pro-Q 3 corresponde a 1/sqrt(2) = 0.70710678 (Manual p. 11)
    double effectiveQ = juce::jlimit (0.025, 40.0, params.q) * 0.7071067811865475;

    // Soma o ganho estático escalado por Gain Scale ao ganho dinâmico instantâneo (se o tipo suportar dinâmica)
    const double staticGainDb = doesShapeSupportGain (params.shape) ? (params.gainDb * gainScale) : 0.0;
    const double dynGainDb    = (doesShapeSupportDynamics (params.shape) && params.dynEnabled) ? dynamicGainOffsetDb : 0.0;
    const double totalGainDb  = juce::jlimit (-45.0, 45.0, staticGainDb + dynGainDb);

    // Gain-Q interaction (Manual p. 11: afeta Bell)
    if (params.gainQInter && params.shape == kShapeBell)
    {
        const double gainFactor = 1.0 + 0.035 * std::abs (totalGainDb);
        effectiveQ = juce::jlimit (0.018, 40.0, effectiveQ * gainFactor);
    }

    if (params.slopeIndex == kSlope6dB)
        effectiveQ = params.shape == kShapeNotch ? 0.7071067811865475 : effectiveQ * 0.55;
    else if (params.slopeIndex == kSlopeBrickwall)
        effectiveQ = juce::jmax (effectiveQ, 1.25);

    const double qComp = effectiveQ * crampComp;
    BiquadCoeffs section;

    switch (params.shape)
    {
        case kShapeBell:
        {
            if (std::abs (totalGainDb) < 1.0e-5)
                return;
            const double sectionGainDb = totalGainDb / static_cast<double> (outNumSections);
            const double A = std::pow (10.0, sectionGainDb / 40.0);
            const double alpha = sinW0 / (2.0 * qComp);

            const double b0 = 1.0 + alpha * A;
            const double b1 = -2.0 * cosW0;
            const double b2 = 1.0 - alpha * A;
            const double a0 = 1.0 + alpha / A;
            const double a1 = -2.0 * cosW0;
            const double a2 = 1.0 - alpha / A;
            const double invA0 = 1.0 / a0;

            section.b0 = b0 * invA0;
            section.b1 = b1 * invA0;
            section.b2 = b2 * invA0;
            section.a1 = a1 * invA0;
            section.a2 = a2 * invA0;
            break;
        }

        case kShapeLowShelf:
        {
            if (std::abs (totalGainDb) < 1.0e-5)
                return;
            const double sectionGainDb = totalGainDb / static_cast<double> (outNumSections);
            const double A = std::pow (10.0, sectionGainDb / 40.0);
            const double sqrtA = std::sqrt (A);
            const double alpha = sinW0 / (2.0 * qComp);

            const double b0 =      A * ((A + 1.0) - (A - 1.0) * cosW0 + 2.0 * sqrtA * alpha);
            const double b1 =  2.0 * A * ((A - 1.0) - (A + 1.0) * cosW0);
            const double b2 =      A * ((A + 1.0) - (A - 1.0) * cosW0 - 2.0 * sqrtA * alpha);
            const double a0 =           (A + 1.0) + (A - 1.0) * cosW0 + 2.0 * sqrtA * alpha;
            const double a1 = -2.0 *     ((A - 1.0) + (A + 1.0) * cosW0);
            const double a2 =           (A + 1.0) + (A - 1.0) * cosW0 - 2.0 * sqrtA * alpha;
            const double invA0 = 1.0 / a0;

            section.b0 = b0 * invA0;
            section.b1 = b1 * invA0;
            section.b2 = b2 * invA0;
            section.a1 = a1 * invA0;
            section.a2 = a2 * invA0;
            break;
        }

        case kShapeHighShelf:
        {
            if (std::abs (totalGainDb) < 1.0e-5)
                return;
            const double sectionGainDb = totalGainDb / static_cast<double> (outNumSections);
            const double A = std::pow (10.0, sectionGainDb / 40.0);
            const double sqrtA = std::sqrt (A);
            const double alpha = sinW0 / (2.0 * qComp);

            const double b0 =      A * ((A + 1.0) + (A - 1.0) * cosW0 + 2.0 * sqrtA * alpha);
            const double b1 = -2.0 * A * ((A - 1.0) + (A + 1.0) * cosW0);
            const double b2 =      A * ((A + 1.0) + (A - 1.0) * cosW0 - 2.0 * sqrtA * alpha);
            const double a0 =           (A + 1.0) - (A - 1.0) * cosW0 + 2.0 * sqrtA * alpha;
            const double a1 =  2.0 *     ((A - 1.0) - (A + 1.0) * cosW0);
            const double a2 =           (A + 1.0) - (A - 1.0) * cosW0 - 2.0 * sqrtA * alpha;
            const double invA0 = 1.0 / a0;

            section.b0 = b0 * invA0;
            section.b1 = b1 * invA0;
            section.b2 = b2 * invA0;
            section.a1 = a1 * invA0;
            section.a2 = a2 * invA0;
            break;
        }

        case kShapeNotch:
        {
            const double alpha = sinW0 / (2.0 * qComp);
            const double b0 =  1.0;
            const double b1 = -2.0 * cosW0;
            const double b2 =  1.0;
            const double a0 =  1.0 + alpha;
            const double a1 = -2.0 * cosW0;
            const double a2 =  1.0 - alpha;
            const double invA0 = 1.0 / a0;

            section.b0 = b0 * invA0;
            section.b1 = b1 * invA0;
            section.b2 = b2 * invA0;
            section.a1 = a1 * invA0;
            section.a2 = a2 * invA0;
            break;
        }

        case kShapeAllPass:
        {
            const auto alpha = sinW0 / (2.0 * qComp);
            const auto invA0 = 1.0 / (1.0 + alpha);
            const auto a1 = -2.0 * cosW0 * invA0;
            const auto a2 = (1.0 - alpha) * invA0;
            section = { a2, a1, 1.0, a1, a2 };
            break;
        }

        case kShapeBandPass:
        {
            const double alpha = sinW0 / (2.0 * qComp);
            const double b0 =  alpha;
            const double b1 =  0.0;
            const double b2 = -alpha;
            const double a0 =  1.0 + alpha;
            const double a1 = -2.0 * cosW0;
            const double a2 =  1.0 - alpha;
            const double invA0 = 1.0 / a0;

            section.b0 = b0 * invA0;
            section.b1 = b1 * invA0;
            section.b2 = b2 * invA0;
            section.a1 = a1 * invA0;
            section.a2 = a2 * invA0;
            break;
        }

        case kShapeTiltShelf:
        case kShapeFlatTilt:
        {
            // Tilt Shelf inclina graves e agudos simetricamente em torno de f0;
            // Flat Tilt usa Q ultralargo fixo (0.28) para uma inclinação linear em todo o espectro audível (Manual p. 1 & p. 11)
            if (std::abs (totalGainDb) < 1.0e-5)
                return;
            const double tiltQ = (params.shape == kShapeFlatTilt) ? 0.28 : qComp;
            const double sectionGainDb = totalGainDb / static_cast<double> (outNumSections);
            const double A = std::pow (10.0, sectionGainDb / 20.0); // Metade para baixo em LF, metade para cima em HF
            const double sqrtA = std::sqrt (A);
            const double alpha = sinW0 / (2.0 * tiltQ);

            const double b0 =      sqrtA * ((A + 1.0) + (A - 1.0) * cosW0 + 2.0 * sqrtA * alpha);
            const double b1 = -2.0 * sqrtA * ((A - 1.0) + (A + 1.0) * cosW0);
            const double b2 =      sqrtA * ((A + 1.0) + (A - 1.0) * cosW0 - 2.0 * sqrtA * alpha);
            const double a0 =     (1.0 / sqrtA) * (A * ((A + 1.0) - (A - 1.0) * cosW0 + 2.0 * sqrtA * alpha));
            const double a1 =  2.0 * (1.0 / sqrtA) * (A * ((A - 1.0) - (A + 1.0) * cosW0));
            const double a2 =     (1.0 / sqrtA) * (A * ((A + 1.0) - (A - 1.0) * cosW0 - 2.0 * sqrtA * alpha));
            const double invA0 = 1.0 / a0;

            section.b0 = b0 * invA0;
            section.b1 = b1 * invA0;
            section.b2 = b2 * invA0;
            section.a1 = a1 * invA0;
            section.a2 = a2 * invA0;
            break;
        }

        default:
            break;
    }

    for (int s = 0; s < outNumSections; ++s)
        outCoeffs[static_cast<size_t> (s)] = section;
}

void ProQ3AudioProcessor::updateAllFilterCoefficients() noexcept
{
    const double sr = currentSampleRate.load (std::memory_order_relaxed);
    const double gainScale = static_cast<double> (apvts.getRawParameterValue ("global_gain_scale")->load (std::memory_order_relaxed)) * 0.01;

    for (int i = 0; i < kMaxBands; ++i)
    {
        const BandParameters bp = getBandParameters (i);
        auto& band = dspBands[static_cast<size_t> (i)];
        computeBandDetectorCoeffs (bp.freqHz, bp.q, sr, band.dynState.detectorBpCoeffs);

        const double dynModDb = static_cast<double> (getBandDynamicGainDb (i));
        computeFilterCascadeCoeffs (bp, sr, gainScale, dynModDb, band.coeffs, band.activeSections);
    }
}

ProQ3AudioProcessor::BandResponse ProQ3AudioProcessor::makeSoloBandResponse (BandParameters parameters) const noexcept
{
    BandResponse response;
    response.sampleRate = getCurrentSampleRate();
    if (! parameters.used)
        return response;

    switch (parameters.shape)
    {
        case kShapeLowCut:    parameters.shape = kShapeHighCut; break;
        case kShapeHighCut:   parameters.shape = kShapeLowCut;  break;
        case kShapeLowShelf:  parameters.shape = kShapeHighCut; break;
        case kShapeHighShelf: parameters.shape = kShapeLowCut;  break;
        default:              parameters.shape = kShapeBandPass; break;
    }

    parameters.enabled = true;
    // Limit resonant peaks from auditioning extreme Q settings on cut and shelf edges.
    if (parameters.shape != kShapeBandPass)
        parameters.q = juce::jlimit (0.35, 1.45, std::pow (parameters.q, 0.18));
    computeFilterCascadeCoeffs (parameters, response.sampleRate, 1.0, 0.0,
                                response.coefficients, response.sections);
    return response;
}

ProQ3AudioProcessor::BandResponse ProQ3AudioProcessor::makeBandResponse (BandParameters parameters,
                                                                       double dynamicGainDb) const noexcept
{
    BandResponse response;
    if (! parameters.used)
        return response;

    response.sampleRate = currentSampleRate.load (std::memory_order_relaxed);
    const double gainScale = apvts.getRawParameterValue ("global_gain_scale")->load (std::memory_order_relaxed) * 0.01;
    parameters.enabled = true;
    computeFilterCascadeCoeffs (parameters, response.sampleRate, gainScale, dynamicGainDb, response.coefficients, response.sections);
    return response;
}

double ProQ3AudioProcessor::BandResponse::magnitudeDbAtFrequency (double freqHz) const noexcept
{
    if (sections == 0)
        return 0.0;

    const double sr = sampleRate;
    const double clampedFreq = juce::jlimit (10.0, 0.498 * sr, freqHz);
    const double w = 2.0 * kPi * clampedFreq / sr;

    const std::complex<double> z1 (std::cos (-w), std::sin (-w));
    const auto z2 = z1 * z1;

    double magnitude = 1.0;
    for (int section = 0; section < sections; ++section)
    {
        const auto& c = coefficients[static_cast<size_t> (section)];
        const auto numerator = c.b0 + c.b1 * z1 + c.b2 * z2;
        const auto denominator = 1.0 + c.a1 * z1 + c.a2 * z2;
        magnitude *= std::norm (numerator) / std::norm (denominator);
    }
    return 10.0 * std::log10 (juce::jmax (1.0e-20, magnitude));
}

double ProQ3AudioProcessor::getBandMagnitudeDbAtFrequency (int bandIndex, double freqHz, bool includeDynamicGain) const noexcept
{
    if (bandIndex < 0 || bandIndex >= kMaxBands)
        return 0.0;

    const auto parameters = getBandParameters (bandIndex);
    if (includeDynamicGain && parameters.spectral)
        return makeBandResponse (parameters).magnitudeDbAtFrequency (freqHz)
             + makeSpectralResponse (parameters, bandIndex, false).magnitudeDbAtFrequency (freqHz);
    return makeBandResponse (parameters, includeDynamicGain ? getBandDynamicGainDb (bandIndex) : 0.0f)
        .magnitudeDbAtFrequency (freqHz);
}

double ProQ3AudioProcessor::getTotalMagnitudeDbAtFrequency (double freqHz, bool includeDynamicGain) const noexcept
{
    double totalDb = 0.0;
    for (int i = 0; i < kMaxBands; ++i)
    {
        const BandParameters bp = getBandParameters (i);
        if (! bp.used || ! bp.enabled)
            continue;
        totalDb += getBandMagnitudeDbAtFrequency (i, freqHz, includeDynamicGain);
    }
    return totalDb;
}

double ProQ3AudioProcessor::getChannelMagnitudeDbAtFrequency (double freqHz, int targetStereoMode, bool includeDynamicGain) const noexcept
{
    double totalDb = 0.0;
    for (int i = 0; i < kMaxBands; ++i)
    {
        const BandParameters bp = getBandParameters (i);
        if (! bp.used || ! bp.enabled)
            continue;
        if (bp.stereoMode == 0 || bp.stereoMode == targetStereoMode)
            totalDb += getBandMagnitudeDbAtFrequency (i, freqHz, includeDynamicGain);
    }
    return totalDb;
}

int ProQ3AudioProcessor::getFactoryPresetCount() noexcept
{
    return static_cast<int> (std::size (FactoryPresets::entries));
}

juce::String ProQ3AudioProcessor::getFactoryPresetName (int index)
{
    return juce::isPositiveAndBelow (index, getFactoryPresetCount())
        ? juce::String (FactoryPresets::entries[index].name) : juce::String();
}

juce::String ProQ3AudioProcessor::getFactoryPresetCategory (int index)
{
    if (! juce::isPositiveAndBelow (index, getFactoryPresetCount()))
        return {};

    const auto* category = FactoryPresets::entries[index].category;
    return category != nullptr ? juce::String (category) : juce::String();
}

int ProQ3AudioProcessor::getFactoryPresetIndex() const
{
    const auto name = apvts.state.getProperty (factoryPresetProperty).toString();
    for (int index = 0; index < getFactoryPresetCount(); ++index)
        if (name == FactoryPresets::entries[index].name)
            return index;
    return -1;
}

void ProQ3AudioProcessor::loadFactoryPreset (int index)
{
    if (! juce::isPositiveAndBelow (index, getFactoryPresetCount()))
        return;

    const auto& preset = FactoryPresets::entries[index];
    jassert (preset.bands.size() <= kMaxBands);

    // APVTS writes undoable parameter changes to its tree asynchronously.
    apvts.copyState();
    undoManager.beginNewTransaction ("Load Preset: " + juce::String (preset.name));

    {
        const juce::ScopedLock callbackLock (getCallbackLock());
        const auto setParameter = [this] (const juce::String& id, float value)
        {
            if (auto* parameter = apvts.getParameter (id))
            {
                const auto normalized = parameter->convertTo0to1 (value);
                if (! juce::approximatelyEqual (parameter->getValue(), normalized))
                    parameter->setValueNotifyingHost (normalized);
            }
        };

        int slot = 0;
        for (const auto& band : preset.bands)
        {
            const auto set = [slot, &setParameter] (const char* suffix, double value)
            {
                setParameter (getBandParamID (slot, suffix), static_cast<float> (value));
            };
            set ("enabled", band.enabled);
            set ("shape", band.shape);
            set ("freq", band.freqHz);
            set ("gain", band.gainDb);
            set ("q", band.q);
            set ("slope", band.slopeIndex);
            set ("stereo", band.stereoMode);
            set ("gain_q", band.gainQInter);
            set ("dyn_range", band.dynRangeDb);
            set ("dyn_enabled", band.dynEnabled);
            set ("dyn_auto", band.dynAutoThresh);
            set ("dyn_thresh", band.dynThresholdDb);
            set ("dyn_ext_sc", band.dynExtSidechain);
            set ("spectral", false);
            set ("all_pass", false);
            set ("spectral_density", 0.5);
            set ("spectral_tilt", true);
            set ("signal_target", 0.0);
            set ("used", true);
            ++slot;
        }
        for (; slot < kMaxBands; ++slot)
            setParameter (getBandParamID (slot, "used"), 0.0f);

        setParameter ("split_eq", 0.0f);
        if (preset.displayRange >= 0)
        {
            setParameter ("display_range", static_cast<float> (preset.displayRange));
            setParameter ("processing_mode", static_cast<float> (preset.phase));
            setParameter ("global_output_gain", preset.output);
            setParameter ("global_gain_scale", 100.0f);
            setParameter ("global_bypass", 0.0f);
            setParameter ("global_phase_invert", 0.0f);
            setParameter ("global_auto_gain", 0.0f);
            setParameter ("output_character", 0.0f);
            setParameter ("global_output_balance", 0.0f);
            setParameter ("global_output_balance_mode", 0.0f);
            setParameter ("analyzer_pre", 1.0f);
            setParameter ("analyzer_post", 1.0f);
            setParameter ("analyzer_sc", 0.0f);
            setParameter ("piano_display", 0.0f);
        }

        setSelectedBandIndex (preset.bands.size() == 0 ? -1 : 0);
        setSoloBandIndex (-1);
        resetEqProcessing();
    }

    apvts.state.setProperty (factoryPresetProperty, preset.name, &undoManager);
    apvts.copyState();
    undoManager.beginNewTransaction();
}

void ProQ3AudioProcessor::applyBandParameters (int band, const BandParameters& bp)
{
    if (! juce::isPositiveAndBelow (band, kMaxBands))
        return;

    const auto set = [this, band] (const char* name, double value)
    {
        auto* parameter = apvts.getParameter (getBandParamID (band, name));
        const auto normalized = parameter->convertTo0to1 (static_cast<float> (value));
        if (! juce::approximatelyEqual (normalized, parameter->getValue()))
            parameter->setValueNotifyingHost (normalized);
    };
    set ("enabled", bp.enabled);
    if (bp.shape != kShapeAllPass)
        set ("shape", bp.shape);
    set ("all_pass", bp.shape == kShapeAllPass);
    set ("freq", bp.freqHz);
    set ("gain", bp.gainDb);
    set ("q", bp.q);
    set ("slope", bp.slopeIndex);
    set ("stereo", bp.stereoMode);
    set ("gain_q", bp.gainQInter);
    set ("dyn_range", bp.dynRangeDb);
    set ("dyn_enabled", bp.dynEnabled);
    set ("dyn_auto", bp.dynAutoThresh);
    set ("dyn_thresh", bp.dynThresholdDb);
    set ("dyn_ext_sc", bp.dynExtSidechain);
    set ("spectral", bp.spectral);
    set ("spectral_density", bp.spectralDensity);
    set ("spectral_tilt", bp.spectralTilt);
    set ("signal_target", static_cast<int> (bp.signalTarget));
}

int ProQ3AudioProcessor::activateFirstFreeBand (const BandParameters& bp, bool newUndoTransaction)
{
    for (int i = 0; i < kMaxBands; ++i)
    {
        if (getBandParameters (i).used)
            continue;
        if (newUndoTransaction)
            undoManager.beginNewTransaction ("Create EQ Band " + juce::String (i + 1));
        applyBandParameters (i, bp);
        apvts.getParameter (getBandParamID (i, "used"))->setValueNotifyingHost (1.0f);
        setSelectedBandIndex (i);
        return i;
    }
    return -1;
}

int ProQ3AudioProcessor::activateFirstFreeBand (float freqHz, float gainDb, float qValue, int shape,
                                              float dynRangeDb, bool newUndoTransaction)
{
    BandParameters bp;
    bp.freqHz = juce::jlimit (10.0f, 30000.0f, freqHz);
    bp.gainDb = juce::jlimit (-30.0f, 30.0f, gainDb);
    bp.q = juce::jlimit (0.025f, 40.0f, qValue);
    bp.shape = juce::jlimit (0, static_cast<int> (kShapeAllPass), shape);
    bp.dynRangeDb = juce::jlimit (-30.0f, 30.0f, dynRangeDb);
    return activateFirstFreeBand (bp, newUndoTransaction);
}

void ProQ3AudioProcessor::deactivateBand (int bandIndex)
{
    if (bandIndex < 0 || bandIndex >= kMaxBands)
        return;

    undoManager.beginNewTransaction ("Delete EQ Band " + juce::String (bandIndex + 1));
    const juce::ScopedLock callbackLock (getCallbackLock());

    auto setParam = [this] (const juce::String& id, float plainValue)
    {
        if (auto* p = apvts.getParameter (id))
            p->setValueNotifyingHost (p->convertTo0to1 (plainValue));
    };

    setParam (getBandParamID (bandIndex, "used"), 0.0f);
    setParam (getBandParamID (bandIndex, "gain"), 0.0f);
    setParam (getBandParamID (bandIndex, "dyn_range"), 0.0f);
    setParam (getBandParamID (bandIndex, "spectral"), 0.0f);
    setParam (getBandParamID (bandIndex, "all_pass"), 0.0f);

    for (auto& st : dspBands[static_cast<size_t> (bandIndex)].states)
        st.reset();
    dspBands[static_cast<size_t> (bandIndex)].dynState.reset();
    dspBands[static_cast<size_t> (bandIndex)].spectralWasActive = false;
    (*tonalDspBands)[static_cast<size_t> (bandIndex)] = {};
    publishBandDynamics (static_cast<size_t> (bandIndex), {}, true);
    for (auto& gain : tonalSpectralGains[static_cast<size_t> (bandIndex)])
        gain.store (0.0f, std::memory_order_relaxed);
    for (auto& gain : spectralGains[static_cast<size_t> (bandIndex)])
        gain.store (0.0f, std::memory_order_relaxed);
    publishBandDynamics (static_cast<size_t> (bandIndex), {});

    int nextSel = -1;
    for (int i = 0; i < kMaxBands; ++i)
    {
        if (i != bandIndex && getBandParameters (i).used)
        {
            nextSel = i;
            break;
        }
    }
    setSelectedBandIndex (nextSel);
}

void ProQ3AudioProcessor::setSoloBandIndex (int idx, float levelDb) noexcept
{
    soloLevelDb.store (juce::jlimit (-36.0f, 6.0f, levelDb), std::memory_order_relaxed);
    soloBandIndex.store (juce::jlimit (-1, kMaxBands - 1, idx), std::memory_order_release);
}

void ProQ3AudioProcessor::toggleABState()
{
    const juce::ScopedLock lock (getCallbackLock());
    if (! currentIsB)
    {
        stateA = apvts.copyState();
        apvts.replaceState (stateB.createCopy());
        currentIsB = true;
    }
    else
    {
        stateB = apvts.copyState();
        apvts.replaceState (stateA.createCopy());
        currentIsB = false;
    }
    resetEqProcessing();
}

void ProQ3AudioProcessor::copyActiveToInactiveState()
{
    if (! currentIsB)
        stateB = apvts.copyState();
    else
        stateA = apvts.copyState();
}

void ProQ3AudioProcessor::armMidiLearn (MidiOutputTarget target) noexcept
{
    armedMidiTarget.store (static_cast<int> (target), std::memory_order_relaxed);
}

void ProQ3AudioProcessor::clearMidiLearn() noexcept
{
    armedMidiTarget.store (-1, std::memory_order_relaxed);
    for (auto& assignment : learnedControllers)
        assignment.store (-1, std::memory_order_relaxed);
}

bool ProQ3AudioProcessor::isMidiLearnArmed() const noexcept
{
    return armedMidiTarget.load (std::memory_order_relaxed) >= 0;
}

bool ProQ3AudioProcessor::hasMidiOutputMapping() const noexcept
{
    return std::any_of (learnedControllers.begin(), learnedControllers.end(), [] (const auto& controller)
    {
        return controller.load (std::memory_order_relaxed) >= 0;
    });
}

void ProQ3AudioProcessor::processMidiLearn (const juce::MidiBuffer& midiMessages)
{
    if (midiMessages.isEmpty() || (! isMidiLearnArmed() && ! hasMidiOutputMapping()))
        return;

    std::array<int, 2> lastValues { -1, -1 };
    for (const auto event : midiMessages)
    {
        if (event.numBytes != 3 || (event.data[0] & 0xf0) != 0xb0)
            continue;

        const int controller = (event.data[0] & 0x0f) * 128 + event.data[1];
        const int learning = armedMidiTarget.exchange (-1, std::memory_order_relaxed);
        if (juce::isPositiveAndBelow (learning, static_cast<int> (learnedControllers.size())))
            learnedControllers[static_cast<size_t> (learning)].store (controller, std::memory_order_relaxed);

        for (size_t target = 0; target < learnedControllers.size(); ++target)
            if (learnedControllers[target].load (std::memory_order_relaxed) == controller)
                lastValues[target] = event.data[2];
    }

    for (size_t target = 0; target < lastValues.size(); ++target)
        if (lastValues[target] >= 0)
            midiOutputParameters[target]->setValueNotifyingHost (static_cast<float> (lastValues[target]) / 127.0f);
}

void ProQ3AudioProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midiMessages)
{
    juce::ScopedNoDenormals noDenormals;
    processMidiLearn (midiMessages);

    for (int start = 0; start < buffer.getNumSamples(); start += soloBufferSamples)
        processAudioRange (buffer, start, juce::jmin (soloBufferSamples, buffer.getNumSamples() - start));
}

void ProQ3AudioProcessor::processAudioRange (juce::AudioBuffer<float>& buffer, int start, int numSamples)
{
    auto mainBus = getBusBuffer (buffer, true, 0);
    const int numMainChannels = mainBus.getNumChannels();

    if (numSamples <= 0 || numMainChannels <= 0)
        return;

    const auto resolution = juce::jlimit (0, 3, static_cast<int> (apvts.getRawParameterValue ("analyzer_resolution")->load (std::memory_order_relaxed)));
    const auto fftSize = size_t { 1024 } << resolution;
    preFftFifo.setResolution (fftSize);
    postFftFifo.setResolution (fftSize);
    sidechainFftFifo.setResolution (fftSize);

    const double sr = currentSampleRate.load (std::memory_order_relaxed);
    const double gainScale = static_cast<double> (apvts.getRawParameterValue ("global_gain_scale")->load (std::memory_order_relaxed)) * 0.01;
    const bool globalBypass = apvts.getRawParameterValue ("global_bypass")->load (std::memory_order_relaxed) >= 0.5f;
    const bool phaseInvert  = apvts.getRawParameterValue ("global_phase_invert")->load (std::memory_order_relaxed) >= 0.5f;
    const bool autoGain     = apvts.getRawParameterValue ("global_auto_gain")->load (std::memory_order_relaxed) >= 0.5f;
    const float outGainDb   = apvts.getRawParameterValue ("global_output_gain")->load (std::memory_order_relaxed);

    float* leftChannel  = mainBus.getWritePointer (0, start);
    float* rightChannel = (numMainChannels > 1) ? mainBus.getWritePointer (1, start) : nullptr;

    // Barramento auxiliar External Side Chain (Bus 1)
    const float* scLeft  = nullptr;
    const float* scRight = nullptr;
    if (getBusCount (true) > 1)
    {
        auto scBus = getBusBuffer (buffer, true, 1);
        if (scBus.getNumChannels() > 0)
        {
            scLeft  = scBus.getReadPointer (0, start);
            scRight = (scBus.getNumChannels() > 1) ? scBus.getReadPointer (1, start) : scLeft;
        }
    }

    for (int s = 0; s < numSamples; ++s)
    {
        preFftFifo.push (leftChannel[s], rightChannel != nullptr ? rightChannel[s] : leftChannel[s]);
        sidechainFftFifo.push (scLeft != nullptr ? scLeft[s] : 0.0f, scRight != nullptr ? scRight[s] : 0.0f);
    }

    const bool splitActive = isSplitEqEnabled() && ! globalBypass;
    if (splitActive != splitWasProcessing)
    {
        resetEqProcessing();
        splitWasProcessing = splitActive;
    }

    const int activeSolo = soloBandIndex.load (std::memory_order_acquire);
    const auto auditionBand = getBandParameters (activeSolo);
    const bool soloOn = ! globalBypass && auditionBand.used
        && (splitActive || auditionBand.signalTarget == SignalTarget::both);
    if (soloOn)
    {
        soloParameters = auditionBand;
        soloResponse = makeSoloBandResponse (soloParameters);
        soloGain.setTargetValue (juce::Decibels::decibelsToGain (soloLevelDb.load (std::memory_order_relaxed)));
    }
    if (globalBypass)
        soloBlend.setCurrentAndTargetValue (0.0f);
    else
        soloBlend.setTargetValue (soloOn ? 1.0f : 0.0f);

    const bool mixSolo = soloOn || soloBlend.isSmoothing();
    const bool soloComponent = mixSolo && splitActive && soloParameters.signalTarget != SignalTarget::both;
    const bool newSoloBand = soloOn && renderedSoloBand != activeSolo;
    if (mixSolo && ! soloComponent)
        renderSolo (leftChannel, rightChannel, numSamples, soloParameters, soloResponse, newSoloBand);
    if (soloOn || ! mixSolo)
        renderedSoloBand = soloOn ? activeSolo : -1;

    if (! globalBypass)
    {
        BandSnapshot bands;
        for (int band = 0; band < kMaxBands; ++band)
            bands[static_cast<size_t> (band)] = getBandParameters (band);
        if (splitActive)
            processSplitEq (bands, leftChannel, rightChannel, scLeft, scRight, numSamples, sr, gainScale, fftSize,
                            soloComponent, newSoloBand);
        else
            processEqBands (bands, leftChannel, rightChannel, scLeft, scRight, numSamples, sr, gainScale, SignalTarget::both);

        // Auto-Gain inteligente com ponderação estática + dinâmica (Manual Pro-Q 3 p. 1 & p. 29)
        double autoMakeupDb = 0.0;
        if (autoGain)
        {
            for (int b = 0; b < kMaxBands; ++b)
            {
                const auto& bp = bands[static_cast<size_t> (b)];
                if (bp.used && bp.enabled && doesShapeSupportGain (bp.shape)
                    && (splitActive || bp.signalTarget == SignalTarget::both))
                {
                    const double dynMod = static_cast<double> (getBandDynamicGainDb (b));
                    const auto share = bp.signalTarget == SignalTarget::both ? 1.0 : 0.5;
                    autoMakeupDb -= share * (bp.gainDb * gainScale + 0.5 * dynMod) * 0.25 / std::sqrt (juce::jmax (0.25, bp.q));
                }
            }
            autoMakeupDb = juce::jlimit (-18.0, 18.0, autoMakeupDb);
        }

        const auto character = static_cast<int> (apvts.getRawParameterValue ("output_character")->load (std::memory_order_relaxed));
        applyCharacter (leftChannel, rightChannel, numSamples, sr, character);

        float linearGain = juce::Decibels::decibelsToGain (outGainDb + static_cast<float> (autoMakeupDb));
        if (phaseInvert)
            linearGain = -linearGain;

        const float balance = apvts.getRawParameterValue ("global_output_balance")->load (std::memory_order_relaxed) * 0.01f;
        if (rightChannel != nullptr && std::abs (balance) > 1.0e-5f)
        {
            const float firstGain = linearGain * (1.0f - juce::jmax (0.0f, balance));
            const float secondGain = linearGain * (1.0f + juce::jmin (0.0f, balance));
            const bool midSide = apvts.getRawParameterValue ("global_output_balance_mode")->load (std::memory_order_relaxed) > 0.5f;
            if (midSide)
            {
                for (int sample = 0; sample < numSamples; ++sample)
                {
                    const float l = leftChannel[sample], r = rightChannel[sample];
                    const float mid = 0.5f * (l + r) * firstGain;
                    const float side = 0.5f * (l - r) * secondGain;
                    leftChannel[sample] = mid + side;
                    rightChannel[sample] = mid - side;
                }
            }
            else
            {
                mainBus.applyGain (0, start, numSamples, firstGain);
                mainBus.applyGain (1, start, numSamples, secondGain);
            }
        }
        else if (std::abs (linearGain - 1.0f) > 1.0e-5f)
        {
            mainBus.applyGain (start, numSamples, linearGain);
        }
    }

    if (globalBypass)
        for (size_t band = 0; band < dspBands.size(); ++band)
            publishBandDynamics (band, {});

    if (mixSolo)
    {
        for (int sample = 0; sample < numSamples; ++sample)
        {
            const auto blend = soloBlend.getNextValue();
            const auto level = soloGain.getNextValue();
            leftChannel[sample] += blend * (level * soloAudio[0][static_cast<size_t> (sample)] - leftChannel[sample]);
            if (rightChannel != nullptr)
                rightChannel[sample] += blend * (level * soloAudio[1][static_cast<size_t> (sample)] - rightChannel[sample]);
        }
    }

    float peakL = 0.0f;
    float peakR = 0.0f;

    for (int s = 0; s < numSamples; ++s)
    {
        const float l = leftChannel[s];
        const float r = (rightChannel != nullptr) ? rightChannel[s] : l;

        peakL = juce::jmax (peakL, std::abs (l));
        peakR = juce::jmax (peakR, std::abs (r));

        postFftFifo.push (l, r);
    }

    updateOutputMeter (peakL, peakR, numSamples, sr);
}

void ProQ3AudioProcessor::processEqBands (const BandSnapshot& bands, float* leftChannel, float* rightChannel,
                                          const float* scLeft, const float* scRight, int numSamples,
                                          double sr, double gainScale, SignalTarget target)
{
    auto& chains = target == SignalTarget::tonal ? *tonalDspBands : dspBands;
    for (size_t band = 0; band < bands.size(); ++band)
    {
        const auto& bp = bands[band];
        auto& chain = chains[band];
        const bool routed = bp.signalTarget == SignalTarget::both || bp.signalTarget == target;
        const bool isLinkedTonal = target == SignalTarget::tonal && bp.signalTarget == SignalTarget::both;
        if (! routed || ! bp.used || ! bp.enabled)
        {
            if (chain.wasProcessing)
                chain = {};
            if (target == SignalTarget::both || routed)
                publishBandDynamics (band, {}, isLinkedTonal);
            continue;
        }
        chain.wasProcessing = true;

        const bool hasDynamicRange = doesShapeSupportDynamics (bp.shape) && std::abs (bp.dynRangeDb) > 1.0e-4;
        const bool spectralActive = bp.spectral && bp.dynEnabled && hasDynamicRange;
        if (! spectralActive && chain.spectralWasActive)
        {
            chain.spectralWasActive = false;
            chain.dynState.reset();
            auto& gains = isLinkedTonal ? tonalSpectralGains : spectralGains;
            for (auto& gain : gains[band])
                gain.store (0.0f, std::memory_order_relaxed);
        }

        computeBandDetectorCoeffs (bp.freqHz, bp.q, sr, chain.dynState.detectorBpCoeffs);

        BandDynamicsReading applied;
        if (spectralActive)
            applied = processSpectralBand (band, chain, isLinkedTonal, bp, leftChannel, rightChannel, scLeft, scRight, numSamples);

        // Se a banda tem alcance dinâmico configurado (ou se está no modo manual monitorando o detector),
        // roda o detector sample-a-sample sobre a fonte selecionada (Main Input ou External Sidechain)
        if (! spectralActive && (hasDynamicRange || ! bp.dynAutoThresh))
        {
            // Manual Pro-Q 3 p. 14: External side chain só dispara quando em modo manual e dynExtSidechain == true
            const bool useExtSc = (! bp.dynAutoThresh) && bp.dynExtSidechain && (scLeft != nullptr);

            for (int s = 0; s < numSamples; ++s)
            {
                double detSample = leftChannel[s];
                std::optional<double> detRight;
                if (useExtSc)
                {
                    detSample = scLeft[s];
                    if (scRight != nullptr && scRight != scLeft)
                        detRight = scRight[s];
                }
                else if (rightChannel != nullptr)
                {
                    const double right = rightChannel[s];
                    switch (bp.stereoMode)
                    {
                        case 0: detRight = right; break;
                        case 2: detSample = right; break;
                        case 3: detSample = 0.5 * (detSample + right); break;
                        case 4: detSample = 0.5 * (detSample - right); break;
                        default: break;
                    }
                }

                const auto envelopeGain = processDynamicEnvelopeSample (bp, chain.dynState, detSample, sr, detRight);

                if ((s & 15) == 0)
                {
                    const auto appliedGain = hasDynamicRange && bp.dynEnabled ? envelopeGain : 0.0;
                    computeFilterCascadeCoeffs (bp, sr, gainScale, appliedGain, chain.coeffs, chain.activeSections);
                    applied = { static_cast<float> (appliedGain), static_cast<float> (chain.dynState.detectorLevelDb) };
                }

                const int numSec = chain.activeSections;
                for (int sec = 0; sec < numSec; ++sec)
                {
                    const auto& c = chain.coeffs[static_cast<size_t> (sec)];
                    auto& st      = chain.states[static_cast<size_t> (sec)];

                    if (rightChannel == nullptr || bp.stereoMode == 0)
                    {
                        const double xL = static_cast<double> (leftChannel[s]);
                        const double yL = c.b0 * xL + st.z1L;
                        st.z1L = c.b1 * xL - c.a1 * yL + st.z2L;
                        st.z2L = c.b2 * xL - c.a2 * yL;
                        leftChannel[s] = static_cast<float> (yL);

                        if (rightChannel != nullptr)
                        {
                            const double xR = static_cast<double> (rightChannel[s]);
                            const double yR = c.b0 * xR + st.z1R;
                            st.z1R = c.b1 * xR - c.a1 * yR + st.z2R;
                            st.z2R = c.b2 * xR - c.a2 * yR;
                            rightChannel[s] = static_cast<float> (yR);
                        }
                    }
                    else if (bp.stereoMode == 1)
                    {
                        const double xL = static_cast<double> (leftChannel[s]);
                        const double yL = c.b0 * xL + st.z1L;
                        st.z1L = c.b1 * xL - c.a1 * yL + st.z2L;
                        st.z2L = c.b2 * xL - c.a2 * yL;
                        leftChannel[s] = static_cast<float> (yL);
                    }
                    else if (bp.stereoMode == 2)
                    {
                        const double xR = static_cast<double> (rightChannel[s]);
                        const double yR = c.b0 * xR + st.z1R;
                        st.z1R = c.b1 * xR - c.a1 * yR + st.z2R;
                        st.z2R = c.b2 * xR - c.a2 * yR;
                        rightChannel[s] = static_cast<float> (yR);
                    }
                    else if (bp.stereoMode == 3)
                    {
                        const double l = static_cast<double> (leftChannel[s]);
                        const double r = static_cast<double> (rightChannel[s]);
                        const double mid  = 0.5 * (l + r);
                        const double side = 0.5 * (l - r);

                        const double yMid = c.b0 * mid + st.z1L;
                        st.z1L = c.b1 * mid - c.a1 * yMid + st.z2L;
                        st.z2L = c.b2 * mid - c.a2 * yMid;

                        leftChannel[s]  = static_cast<float> (yMid + side);
                        rightChannel[s] = static_cast<float> (yMid - side);
                    }
                    else if (bp.stereoMode == 4)
                    {
                        const double l = static_cast<double> (leftChannel[s]);
                        const double r = static_cast<double> (rightChannel[s]);
                        const double mid  = 0.5 * (l + r);
                        const double side = 0.5 * (l - r);

                        const double ySide = c.b0 * side + st.z1R;
                        st.z1R = c.b1 * side - c.a1 * ySide + st.z2R;
                        st.z2R = c.b2 * side - c.a2 * ySide;

                        leftChannel[s]  = static_cast<float> (mid + ySide);
                        rightChannel[s] = static_cast<float> (mid - ySide);
                    }
                }
            }

            publishBandDynamics (band, applied, isLinkedTonal);
        }
        else
        {
            publishBandDynamics (band, applied, isLinkedTonal);

            if (doesShapeSupportGain (bp.shape) && std::abs (bp.gainDb) < 1.0e-5)
                continue;

            computeFilterCascadeCoeffs (bp, sr, gainScale, 0.0, chain.coeffs, chain.activeSections);
            const int numSec = chain.activeSections;

            for (int sec = 0; sec < numSec; ++sec)
            {
                const auto& c = chain.coeffs[static_cast<size_t> (sec)];
                auto& st      = chain.states[static_cast<size_t> (sec)];

                if (rightChannel == nullptr || bp.stereoMode == 0)
                {
                    for (int s = 0; s < numSamples; ++s)
                    {
                        const double xL = static_cast<double> (leftChannel[s]);
                        const double yL = c.b0 * xL + st.z1L;
                        st.z1L = c.b1 * xL - c.a1 * yL + st.z2L;
                        st.z2L = c.b2 * xL - c.a2 * yL;
                        leftChannel[s] = static_cast<float> (yL);

                        if (rightChannel != nullptr)
                        {
                            const double xR = static_cast<double> (rightChannel[s]);
                            const double yR = c.b0 * xR + st.z1R;
                            st.z1R = c.b1 * xR - c.a1 * yR + st.z2R;
                            st.z2R = c.b2 * xR - c.a2 * yR;
                            rightChannel[s] = static_cast<float> (yR);
                        }
                    }
                }
                else if (bp.stereoMode == 1)
                {
                    for (int s = 0; s < numSamples; ++s)
                    {
                        const double xL = static_cast<double> (leftChannel[s]);
                        const double yL = c.b0 * xL + st.z1L;
                        st.z1L = c.b1 * xL - c.a1 * yL + st.z2L;
                        st.z2L = c.b2 * xL - c.a2 * yL;
                        leftChannel[s] = static_cast<float> (yL);
                    }
                }
                else if (bp.stereoMode == 2)
                {
                    for (int s = 0; s < numSamples; ++s)
                    {
                        const double xR = static_cast<double> (rightChannel[s]);
                        const double yR = c.b0 * xR + st.z1R;
                        st.z1R = c.b1 * xR - c.a1 * yR + st.z2R;
                        st.z2R = c.b2 * xR - c.a2 * yR;
                        rightChannel[s] = static_cast<float> (yR);
                    }
                }
                else if (bp.stereoMode == 3)
                {
                    for (int s = 0; s < numSamples; ++s)
                    {
                        const double l = static_cast<double> (leftChannel[s]);
                        const double r = static_cast<double> (rightChannel[s]);
                        const double mid  = 0.5 * (l + r);
                        const double side = 0.5 * (l - r);

                        const double yMid = c.b0 * mid + st.z1L;
                        st.z1L = c.b1 * mid - c.a1 * yMid + st.z2L;
                        st.z2L = c.b2 * mid - c.a2 * yMid;

                        leftChannel[s]  = static_cast<float> (yMid + side);
                        rightChannel[s] = static_cast<float> (yMid - side);
                    }
                }
                else if (bp.stereoMode == 4)
                {
                    for (int s = 0; s < numSamples; ++s)
                    {
                        const double l = static_cast<double> (leftChannel[s]);
                        const double r = static_cast<double> (rightChannel[s]);
                        const double mid  = 0.5 * (l + r);
                        const double side = 0.5 * (l - r);

                        const double ySide = c.b0 * side + st.z1R;
                        st.z1R = c.b1 * side - c.a1 * ySide + st.z2R;
                        st.z2R = c.b2 * side - c.a2 * ySide;

                        leftChannel[s]  = static_cast<float> (mid + ySide);
                        rightChannel[s] = static_cast<float> (mid - ySide);
                    }
                }
            }
        }
    }
}

void ProQ3AudioProcessor::resetEqProcessing() noexcept
{
    for (auto& chain : dspBands)
        chain = {};
    for (auto& chain : *tonalDspBands)
        chain = {};
    for (size_t band = 0; band < dspBands.size(); ++band)
    {
        publishBandDynamics (band, {});
        publishBandDynamics (band, {}, true);
        for (auto& gain : spectralGains[band])
            gain.store (0.0f, std::memory_order_relaxed);
        for (auto& gain : tonalSpectralGains[band])
            gain.store (0.0f, std::memory_order_relaxed);
    }
    splitLowPass = {};
    splitEnvelopes = {};
    for (size_t index = 0; index < splitFftFifos.size(); ++index)
    {
        splitFftFifos[index].resetHistory();
        splitPeakDb[index].store (kMeterFloorDb, std::memory_order_relaxed);
    }
}

void ProQ3AudioProcessor::processSplitEq (const BandSnapshot& bands, float* left, float* right, const float* scLeft, const float* scRight,
                                         int count, double rate, double gainScale, size_t fftSize,
                                         bool auditionComponent, bool newSoloBand)
{
    const auto coefficient = [rate] (double milliseconds)
    {
        return static_cast<float> (-std::expm1 (-1000.0 / (milliseconds * rate)));
    };
    const auto fastAttack = coefficient (0.55);
    const auto fastRelease = coefficient (9.0);
    const auto slowAttack = coefficient (34.0);
    const auto slowRelease = coefficient (115.0);
    const auto weightAttack = coefficient (0.75);
    const auto weightRelease = coefficient (13.0);
    std::array<float, 3> crossover { 160.0f, 1450.0f, 6250.0f };
    for (auto& frequency : crossover)
        frequency = static_cast<float> (-std::expm1 (-2.0 * kPi * juce::jmin (rate * 0.45, static_cast<double> (frequency)) / rate));

    auto* transientLeft = (*transientAudio)[0].data();
    auto* transientRight = right != nullptr ? (*transientAudio)[1].data() : nullptr;
    for (int sample = 0; sample < count; ++sample)
    {
        const auto separateRegions = [&] (float input, size_t channel)
        {
            auto& low = splitLowPass[channel];
            for (size_t index = 0; index < low.size(); ++index)
                low[index] += crossover[index] * (input - low[index]);
            return std::array<float, 4> { low[0], low[1] - low[0], low[2] - low[1], input - low[2] };
        };
        const auto l = separateRegions (left[sample], 0);
        const auto r = right != nullptr ? separateRegions (right[sample], 1) : l;
        float attackL = 0.0f, attackR = 0.0f;
        for (size_t region = 0; region < splitEnvelopes.size(); ++region)
        {
            auto& env = splitEnvelopes[region];
            const auto peak = juce::jmax (std::abs (l[region]), std::abs (r[region]));
            env.fast += (peak > env.fast ? fastAttack : fastRelease) * (peak - env.fast);
            env.slow += (peak > env.slow ? slowAttack : slowRelease) * (peak - env.slow);
            const auto onset = juce::jlimit (0.0f, 1.0f, (env.fast - 1.2f * env.slow) / (0.72f * env.fast + 1.0e-5f));
            env.weight += (onset > env.weight ? weightAttack : weightRelease) * (onset - env.weight);
            attackL += l[region] * env.weight;
            attackR += r[region] * env.weight;
        }
        // Using the complementary residual preserves the input when both paths have unity gain.
        transientLeft[sample] = attackL;
        left[sample] -= attackL;
        if (right != nullptr)
        {
            transientRight[sample] = attackR;
            right[sample] -= attackR;
        }
    }

    if (auditionComponent)
    {
        const auto transient = soloParameters.signalTarget == SignalTarget::transient;
        renderSolo (transient ? transientLeft : left, transient ? transientRight : right, count,
                    soloParameters, soloResponse, newSoloBand);
    }

    processEqBands (bands, transientLeft, transientRight, scLeft, scRight, count, rate, gainScale, SignalTarget::transient);
    processEqBands (bands, left, right, scLeft, scRight, count, rate, gainScale, SignalTarget::tonal);

    for (auto& capture : splitFftFifos)
        capture.setResolution (fftSize);
    std::array<float, 2> peaks {};
    for (int sample = 0; sample < count; ++sample)
    {
        const auto tL = transientLeft[sample];
        const auto tR = right != nullptr ? transientRight[sample] : tL;
        const auto sL = left[sample];
        const auto sR = right != nullptr ? right[sample] : sL;
        splitFftFifos[0].push (tL, tR);
        splitFftFifos[1].push (sL, sR);
        peaks[0] = juce::jmax (peaks[0], std::abs (tL), std::abs (tR));
        peaks[1] = juce::jmax (peaks[1], std::abs (sL), std::abs (sR));
        left[sample] = tL + sL;
        if (right != nullptr)
            right[sample] = tR + sR;
    }
    const auto release = static_cast<float> (30.0 * count / rate);
    for (size_t index = 0; index < peaks.size(); ++index)
    {
        auto& level = splitPeakDb[index];
        const auto peak = juce::Decibels::gainToDecibels (peaks[index], kMeterFloorDb);
        level.store (juce::jmax (peak, level.load (std::memory_order_relaxed) - release), std::memory_order_relaxed);
    }
}

void ProQ3AudioProcessor::applyCharacter (float* left, float* right, int count, double rate, int mode) noexcept
{
    characterAmount.setTargetValue (static_cast<float> (juce::jlimit (0, 2, mode)));
    if (mode == 0 && ! characterAmount.isSmoothing())
    {
        characterDc.fill (0.0f);
        characterTone.fill (0.0f);
        return;
    }

    const auto dcCoefficient = static_cast<float> (1.0 - std::exp (-2.0 * kPi * 14.0 / rate));
    const auto toneCoefficient = static_cast<float> (1.0 - std::exp (-2.0 * kPi * juce::jmin (10000.0, rate * 0.23) / rate));
    for (int sample = 0; sample < count; ++sample)
    {
        const auto amount = characterAmount.getNextValue();
        const auto drive = 0.78f + 0.47f * amount;
        const auto mix = 0.18f * amount;
        const auto asymmetry = 0.14f * juce::jmax (0.0f, amount - 1.0f);
        const auto colour = [&] (float input, size_t channel)
        {
            const auto compressed = std::tanh (input * drive) / drive;
            const auto residue = compressed - input + asymmetry * compressed * compressed;
            auto& dc = characterDc[channel];
            dc += dcCoefficient * (residue - dc);
            auto& tone = characterTone[channel];
            tone += toneCoefficient * (residue - dc - tone);
            return input + mix * tone;
        };
        left[sample] = colour (left[sample], 0);
        if (right != nullptr)
            right[sample] = colour (right[sample], 1);
    }
}

std::array<ProQ3AudioProcessor::BandParameters, ProQ3AudioProcessor::spectralRegionCount>
ProQ3AudioProcessor::getSpectralRegions (const BandParameters& parent, double rate) noexcept
{
    std::array<BandParameters, spectralRegionCount> regions;
    const auto spacing = juce::jlimit (0.13, 0.95, std::asinh (0.5 / parent.q) / std::log (2.0));
    const bool shelf = parent.shape == kShapeLowShelf || parent.shape == kShapeHighShelf;
    const auto step = shelf ? juce::jmax (0.65, spacing) : spacing;
    const auto density = 0.60 + 0.80 * parent.spectralDensity;
    const auto regionQ = juce::jlimit (1.25, 32.0, 1.5 * density / (std::exp2 (step * 0.5) - std::exp2 (-step * 0.5)));

    for (size_t index = 0; index < regions.size(); ++index)
    {
        auto region = parent;
        auto offset = static_cast<double> (index) - 2.0;
        if (shelf)
            offset = (parent.shape == kShapeLowShelf ? -1.0 : 1.0) * static_cast<double> (index);
        const auto hz = parent.freqHz * std::exp2 (offset * step);
        region.freqHz = juce::jlimit (10.0, 0.498 * rate, hz);
        region.q = regionQ;
        region.shape = kShapeBell;
        region.slopeIndex = kSlope12dB;
        region.gainDb = 0.0;
        region.gainQInter = false;
        // Keep overlapping bell skirts below the requested range.
        region.dynRangeDb *= std::abs (hz - region.freqHz) > 0.01 ? 0.0 : (shelf ? 0.65 : 0.68);
        regions[index] = region;
    }
    return regions;
}

ProQ3AudioProcessor::SpectralResponse ProQ3AudioProcessor::makeSpectralResponse (
    const BandParameters& parameters, int band, bool fullRange, bool tonalReading) const noexcept
{
    SpectralResponse response;
    if (! parameters.used || ! parameters.enabled || ! parameters.dynEnabled
        || ! doesShapeSupportDynamics (parameters.shape) || ! juce::isPositiveAndBelow (band, kMaxBands))
        return response;

    const auto rate = getCurrentSampleRate();
    const auto regions = getSpectralRegions (parameters, rate);
    for (size_t index = 0; index < regions.size(); ++index)
    {
        const auto gain = fullRange ? regions[index].dynRangeDb
            : (tonalReading ? tonalSpectralGains : spectralGains)[static_cast<size_t> (band)][index].load (std::memory_order_relaxed);
        if (std::abs (gain) < 0.001)
            continue;
        auto& filter = response.regions[index];
        filter.sampleRate = rate;
        computeFilterCascadeCoeffs (regions[index], rate, 1.0, gain, filter.coefficients, filter.sections);
    }
    return response;
}

double ProQ3AudioProcessor::SpectralResponse::magnitudeDbAtFrequency (double hz) const noexcept
{
    double result = 0.0;
    for (const auto& region : regions)
        if (region.sections != 0)
            result += region.magnitudeDbAtFrequency (hz);
    return result;
}

ProQ3AudioProcessor::BandDynamicsReading ProQ3AudioProcessor::processSpectralBand (
    size_t band, BandDspChain& chain, bool tonalReading, const BandParameters& parameters, float* left, float* right,
    const float* scLeft, const float* scRight, int numSamples)
{
    constexpr int stride = 16;
    auto& states = chain.spectralRegions;
    if (! chain.spectralWasActive)
    {
        chain.spectralWasActive = true;
        states.fill ({});
        chain.spectralSamples = 0;
    }

    const auto rate = getCurrentSampleRate();
    const auto regions = getSpectralRegions (parameters, rate);
    const auto mode = right != nullptr ? parameters.stereoMode : 0;
    const bool external = ! parameters.dynAutoThresh && parameters.dynExtSidechain && scLeft != nullptr;
    const bool linked = external ? scRight != nullptr && scRight != scLeft : right != nullptr && mode == 0;
    std::array<double, spectralRegionCount> tilt {};
    for (size_t index = 0; index < regions.size(); ++index)
    {
        const auto& region = regions[index];
        computeBandDetectorCoeffs (region.freqHz, region.q, rate, states[index].detector.detectorBpCoeffs);
        const auto tiltDb = 3.0 * std::log2 (region.freqHz / 1000.0);
        tilt[index] = parameters.spectralTilt ? juce::Decibels::decibelsToGain (tiltDb) : 1.0;
        std::array<BiquadCoeffs, kMaxCascadedSections> coeffs;
        int sections = 0;
        computeFilterCascadeCoeffs (region, rate, 1.0, states[index].gainDb, coeffs, sections);
        states[index].filter = coeffs.front();
    }

    const auto filter = [] (const BiquadCoeffs& c, double input, double& z1, double& z2)
    {
        const auto output = c.b0 * input + z1;
        z1 = c.b1 * input - c.a1 * output + z2;
        z2 = c.b2 * input - c.a2 * output;
        return output;
    };

    for (int sample = 0; sample < numSamples; ++sample)
    {
        const double l = left[sample];
        const double r = right != nullptr ? right[sample] : l;
        double first = l, second = r;
        switch (mode)
        {
            case 2: first = r; break;
            case 3: first = 0.5 * (l + r); second = 0.5 * (l - r); break;
            case 4: first = 0.5 * (l - r); second = 0.5 * (l + r); break;
            default: break;
        }

        const double detL = external ? scLeft[sample] : first;
        const double detR = external && scRight != nullptr ? scRight[sample] : second;
        const bool update = ++chain.spectralSamples >= stride;
        if (update)
            chain.spectralSamples = 0;

        for (size_t index = 0; index < regions.size(); ++index)
        {
            auto& state = states[index];
            auto& det = state.detector.detectorBpState;
            const auto& detector = state.detector.detectorBpCoeffs;
            auto level = std::abs (filter (detector, detL, det.z1L, det.z2L));
            if (linked)
                level = juce::jmax (level, std::abs (filter (detector, detR, det.z1R, det.z2R)));
            state.detectedPeak = juce::jmax (state.detectedPeak, level);

            if (update)
            {
                const auto gain = updateDynamicEnvelope (regions[index], state.detector, state.detectedPeak * tilt[index], rate / stride);
                state.detectedPeak = 0.0;
                if (std::abs (gain - state.gainDb) > 0.005 || (gain == 0.0 && state.gainDb != 0.0))
                {
                    state.gainDb = gain;
                    std::array<BiquadCoeffs, kMaxCascadedSections> coeffs;
                    int sections = 0;
                    computeFilterCascadeCoeffs (regions[index], rate, 1.0, gain, coeffs, sections);
                    state.filter = coeffs.front();
                }
            }

            auto& audio = state.filterState;
            first = filter (state.filter, first, audio.z1L, audio.z2L);
            if (right != nullptr && mode == 0)
                second = filter (state.filter, second, audio.z1R, audio.z2R);
        }

        switch (mode)
        {
            case 1: left[sample] = static_cast<float> (first); break;
            case 2: right[sample] = static_cast<float> (first); break;
            case 3: left[sample] = static_cast<float> (first + second);
                    right[sample] = static_cast<float> (first - second); break;
            case 4: left[sample] = static_cast<float> (second + first);
                    right[sample] = static_cast<float> (second - first); break;
            default: left[sample] = static_cast<float> (first);
                     if (right != nullptr) right[sample] = static_cast<float> (second); break;
        }
    }

    BandDynamicsReading reading;
    for (size_t index = 0; index < regions.size(); ++index)
    {
        const auto gain = static_cast<float> (states[index].gainDb);
        (tonalReading ? tonalSpectralGains : spectralGains)[band][index].store (gain, std::memory_order_relaxed);
        if (std::abs (gain) > std::abs (reading.gainDb))
            reading.gainDb = gain;
        reading.detectorDb = juce::jmax (reading.detectorDb, static_cast<float> (states[index].detector.detectorLevelDb));
    }
    return reading;
}

void ProQ3AudioProcessor::renderSolo (const float* left, const float* right, int numSamples,
                                         const BandParameters& band, const BandResponse& response,
                                         bool newBand) noexcept
{
    if (newBand)
        soloStates.fill ({});

    const auto mode = right != nullptr ? band.stereoMode : 0;
    for (int sample = 0; sample < numSamples; ++sample)
    {
        const double l = left[sample];
        const double r = right != nullptr ? right[sample] : l;
        double first = l;
        double second = mode == 0 && right != nullptr ? r : 0.0;
        switch (mode)
        {
            case 2: first = r; break;
            case 3: first = 0.5 * (l + r); break;
            case 4: first = 0.5 * (l - r); break;
            default: break;
        }
        for (int section = 0; section < response.sections; ++section)
        {
            const auto& c = response.coefficients[static_cast<size_t> (section)];
            auto& state = soloStates[static_cast<size_t> (section)];
            const auto y = c.b0 * first + state.z1L;
            state.z1L = c.b1 * first - c.a1 * y + state.z2L;
            state.z2L = c.b2 * first - c.a2 * y;
            first = y;

            const auto yr = c.b0 * second + state.z1R;
            state.z1R = c.b1 * second - c.a1 * yr + state.z2R;
            state.z2R = c.b2 * second - c.a2 * yr;
            second = yr;
        }
        switch (mode)
        {
            case 2: second = first; first = 0.0; break;
            case 3: second = first; break;
            case 4: second = -first; break;
            default: break;
        }
        soloAudio[0][static_cast<size_t> (sample)] = static_cast<float> (first);
        soloAudio[1][static_cast<size_t> (sample)] = static_cast<float> (second);
    }
}

void ProQ3AudioProcessor::updateOutputMeter (float leftPeak, float rightPeak, int samples, double sampleRate) noexcept
{
    const auto elapsed = static_cast<float> (samples / sampleRate);
    const std::array<float, 2> peakGain { leftPeak, rightPeak };
    const std::array<std::atomic<float>*, 2> levels { &outputPeakDbL, &outputPeakDbR };

    for (size_t channel = 0; channel < levels.size(); ++channel)
    {
        const auto peak = juce::Decibels::gainToDecibels (peakGain[channel], kMeterFloorDb);
        const auto level = juce::jmax (peak, levels[channel]->load (std::memory_order_relaxed) - 30.0f * elapsed);
        levels[channel]->store (level, std::memory_order_relaxed);

        const auto held = outputHeldPeakDb[channel].load (std::memory_order_relaxed);
        if (peak >= held)
        {
            outputHeldPeakDb[channel].store (peak, std::memory_order_relaxed);
            meterHoldSamples[channel] = juce::roundToInt (sampleRate * 1.5);
        }
        else
        {
            meterHoldSamples[channel] -= samples;
            if (meterHoldSamples[channel] <= 0)
            {
                const auto releaseTime = static_cast<float> (-meterHoldSamples[channel] / sampleRate);
                outputHeldPeakDb[channel].store (juce::jmax (level, held - 18.0f * releaseTime), std::memory_order_relaxed);
                meterHoldSamples[channel] = 0;
            }
        }
    }
}

float ProQ3AudioProcessor::spectrumTiltDb (double frequency) noexcept
{
    return static_cast<float> (4.5 * std::log2 (juce::jmax (20.0, frequency) / 1000.0));
}

bool ProQ3AudioProcessor::pullSpectrum (SpectrumCapture& source, std::vector<float>& destMagnitudesDb)
{
    using FrameState = SpectrumCapture::FrameState;
    auto published = FrameState::ready;
    if (! source.frameState.compare_exchange_strong (published, FrameState::reading, std::memory_order_acquire))
        return false;

    auto& transform = spectrumTransforms[source.publishedPlan];
    const auto size = transform.size;
    const auto bins = size / 2 + 1;
    destMagnitudesDb.assign (bins, 0.0f);
    for (const auto& channel : *source.frame)
    {
        std::copy_n (channel.begin(), size, fftWorkspace.begin());
        std::fill_n (fftWorkspace.begin() + static_cast<std::ptrdiff_t> (size), size, 0.0f);
        transform.window.multiplyWithWindowingTable (fftWorkspace.data(), size);
        transform.fft.performFrequencyOnlyForwardTransform (fftWorkspace.data(), true);
        const auto inverseSize = 1.0f / static_cast<float> (size);
        for (size_t bin = 0; bin < bins; ++bin)
        {
            // The normalized Hann window has unity coherent gain.
            const auto scale = bin == 0 || bin == bins - 1 ? inverseSize : 2.0f * inverseSize;
            const auto amplitude = fftWorkspace[bin] * scale;
            destMagnitudesDb[bin] += 0.5f * amplitude * amplitude;
        }
    }
    source.frameState.store (FrameState::empty, std::memory_order_release);

    const auto binWidth = getCurrentSampleRate() / static_cast<double> (size);
    for (size_t bin = 0; bin < destMagnitudesDb.size(); ++bin)
    {
        const auto tiltDb = spectrumTiltDb (binWidth * static_cast<double> (bin));
        destMagnitudesDb[bin] = juce::Decibels::gainToDecibels (std::sqrt (destMagnitudesDb[bin]), -140.0f) + tiltDb;
    }
    return true;
}

bool ProQ3AudioProcessor::pullNextPreFftBlock (std::vector<float>& dest)
{
    return pullSpectrum (preFftFifo, dest);
}

bool ProQ3AudioProcessor::pullNextPostFftBlock (std::vector<float>& dest)
{
    return pullSpectrum (postFftFifo, dest);
}

bool ProQ3AudioProcessor::pullNextSidechainFftBlock (std::vector<float>& dest)
{
    return pullSpectrum (sidechainFftFifo, dest);
}

bool ProQ3AudioProcessor::pullNextSplitSpectrum (size_t component, std::vector<float>& dest)
{
    return pullSpectrum (splitFftFifos[component], dest);
}

void ProQ3AudioProcessor::updateTrackProperties (const TrackProperties& properties)
{
    const juce::ScopedLock lock ((*sharedInstances).mutex);
    spectrumTrackName = properties.name.trim();
    spectrumTrackColour = properties.colour.isTransparent() ? juce::Colour (0xffc81e51) : properties.colour;
}

juce::String ProQ3AudioProcessor::getSpectrumInstanceNameUnlocked() const
{
    if (spectrumTrackName.isNotEmpty())
        return spectrumTrackName;

    return spectrumInstanceAlias.isEmpty() ? "Track " + juce::String (spectrumPeerId) : spectrumInstanceAlias;
}

juce::String ProQ3AudioProcessor::getSpectrumInstanceName() const
{
    const juce::ScopedLock lock ((*sharedInstances).mutex);
    return getSpectrumInstanceNameUnlocked();
}

juce::Colour ProQ3AudioProcessor::getSpectrumTrackColour() const
{
    const juce::ScopedLock lock (sharedInstances->mutex);
    return spectrumTrackColour;
}

bool ProQ3AudioProcessor::hasSpectrumTrackName() const
{
    const juce::ScopedLock lock ((*sharedInstances).mutex);
    return spectrumTrackName.isNotEmpty();
}

void ProQ3AudioProcessor::setSpectrumInstanceAlias (juce::String alias)
{
    alias = alias.trim().substring (0, 64);
    {
        const juce::ScopedLock lock ((*sharedInstances).mutex);
        if (spectrumInstanceAlias == alias)
            return;
        spectrumInstanceAlias = std::move (alias);
    }
    updateHostDisplay (ChangeDetails {}.withNonParameterStateChanged (true));
}

std::vector<ProQ3AudioProcessor::SpectrumPeer> ProQ3AudioProcessor::getSpectrumPeers() const
{
    auto& registry = (*sharedInstances);
    const juce::ScopedLock lock (registry.mutex);
    std::vector<SpectrumPeer> peers;
    for (auto* instance : registry.instances)
    {
        if (instance != this)
            peers.push_back ({ instance->spectrumPeerId, instance->getSpectrumInstanceNameUnlocked(), instance->spectrumTrackColour });
    }

    for (auto& peer : peers)
    {
        const auto matchesName = [&peer] (const auto* instance)
        {
            return instance->getSpectrumInstanceNameUnlocked() == peer.name;
        };
        if (std::count_if (registry.instances.begin(), registry.instances.end(), matchesName) > 1)
            peer.name += " (" + juce::String (peer.id) + ")";
    }
    return peers;
}

void ProQ3AudioProcessor::refreshPostSpectrum()
{
    if (pullNextPostFftBlock (cachedPostSpectrum))
    {
        lastPostSpectrumMs = juce::Time::getMillisecondCounterHiRes();
        ++postSpectrumGeneration;
    }
}

bool ProQ3AudioProcessor::readPostSpectrum (juce::uint64& generation, std::vector<float>& magnitudes)
{
    const juce::ScopedLock lock ((*sharedInstances).mutex);
    refreshPostSpectrum();
    if (generation == postSpectrumGeneration || juce::Time::getMillisecondCounterHiRes() - lastPostSpectrumMs > 200.0)
        return false;
    generation = postSpectrumGeneration;
    magnitudes = cachedPostSpectrum;
    return true;
}

bool ProQ3AudioProcessor::readPeerSpectrum (int peerId, std::vector<float>& magnitudes, double& rate)
{
    auto& registry = (*sharedInstances);
    const juce::ScopedLock lock (registry.mutex);
    for (auto* instance : registry.instances)
    {
        if (instance == this || instance->spectrumPeerId != peerId)
            continue;
        instance->refreshPostSpectrum();
        if (instance->cachedPostSpectrum.empty() || juce::Time::getMillisecondCounterHiRes() - instance->lastPostSpectrumMs > 200.0)
            return false;
        magnitudes = instance->cachedPostSpectrum;
        rate = instance->getCurrentSampleRate();
        return true;
    }
    return false;
}

ProQ3AudioProcessor::OverviewCurve ProQ3AudioProcessor::getOverviewCurve() const
{
    OverviewCurve result;
    const auto bypass = apvts.getRawParameterValue ("global_bypass")->load() >= 0.5f;
    result.hasSplit = isSplitEqEnabled();
    for (int band = 0; band < kMaxBands; ++band)
    {
        const auto bp = getBandParameters (band);
        if (! bp.used)
            continue;
        const auto gain = doesShapeSupportGain (bp.shape) ? static_cast<float> (bp.gainDb) : 0.0f;
        const bool active = ! bypass && bp.enabled && (result.hasSplit || bp.signalTarget == SignalTarget::both);
        result.markers[result.markerCount++] = { static_cast<float> (bp.freqHz), gain,
                                                 bp.stereoMode, bp.signalTarget, band, active };
        if (! active)
            continue;
        const auto accumulate = [&] (auto& curve, bool linkedTonal)
        {
            const auto modulation = getBandDynamicsReading (band, linkedTonal).gainDb;
            const auto response = makeBandResponse (bp, bp.spectral ? 0.0 : modulation);
            const auto spectral = bp.spectral
                ? makeSpectralResponse (bp, band, false, linkedTonal) : SpectralResponse {};
            for (size_t index = 0; index < curve.size(); ++index)
            {
                const auto hz = 20.0 * std::pow (1000.0, static_cast<double> (index) / static_cast<double> (curve.size() - 1));
                curve[index] += static_cast<float> (response.magnitudeDbAtFrequency (hz)
                    + (bp.spectral ? spectral.magnitudeDbAtFrequency (hz) : 0.0));
            }
        };
        if (result.hasSplit)
        {
            if (bp.signalTarget != SignalTarget::tonal)
                accumulate (result.split[0], false);
            if (bp.signalTarget != SignalTarget::transient)
                accumulate (result.split[1], bp.signalTarget == SignalTarget::both);
        }
        else
        {
            result.hasLeft |= bp.stereoMode == 1;
            result.hasRight |= bp.stereoMode == 2;
            accumulate (bp.stereoMode == 1 ? result.left : bp.stereoMode == 2 ? result.right : result.common, false);
        }
    }
    return result;
}

bool ProQ3AudioProcessor::readOverviewCurve (int id, OverviewCurve& dest) const
{
    if (id == 0)
    {
        dest = getOverviewCurve();
        return true;
    }

    auto& registry = (*sharedInstances);
    const juce::ScopedLock lock (registry.mutex);
    for (auto* instance : registry.instances)
    {
        if (instance->spectrumPeerId == id)
        {
            dest = instance->getOverviewCurve();
            return true;
        }
    }
    return false;
}

bool ProQ3AudioProcessor::withOverviewTrack (int id, const std::function<void (ProQ3AudioProcessor&)>& edit)
{
    auto target = overviewTarget;
    if (id != 0)
    {
        auto& registry = (*sharedInstances);
        const juce::ScopedLock lock (registry.mutex);
        const auto found = std::find_if (registry.instances.begin(), registry.instances.end(), [id] (const auto* instance)
        {
            return instance->spectrumPeerId == id;
        });
        if (found == registry.instances.end())
            return false;
        target = (*found)->overviewTarget;
    }

    // Host notifications may query the instance list. Release the registry lock before editing.
    const juce::ScopedLock lock (target->mutex);
    if (target->processor == nullptr)
        return false;
    edit (*target->processor);
    return true;
}

bool ProQ3AudioProcessor::hasEditor() const { return true; }

juce::AudioProcessorEditor* ProQ3AudioProcessor::createEditor()
{
    return new ProQ3AudioProcessorEditor (*this);
}

void ProQ3AudioProcessor::getStateInformation (juce::MemoryBlock& destData)
{
    auto state = apvts.copyState();
    {
        const juce::ScopedLock lock ((*sharedInstances).mutex);
        if (spectrumInstanceAlias.isNotEmpty())
            state.setProperty ("spectrumInstanceAlias", spectrumInstanceAlias, nullptr);
        else
            state.removeProperty ("spectrumInstanceAlias", nullptr);
    }
    state.setProperty ("selectedBandIndex", selectedBandIndex.load (std::memory_order_relaxed), nullptr);
    state.setProperty ("currentIsB", currentIsB, nullptr);
    state.setProperty ("midiOutputLevelCC", learnedControllers[0].load (std::memory_order_relaxed), nullptr);
    state.setProperty ("midiGainScaleCC", learnedControllers[1].load (std::memory_order_relaxed), nullptr);

    std::unique_ptr<juce::XmlElement> xml (state.createXml());
    copyXmlToBinary (*xml, destData);
}

void ProQ3AudioProcessor::setStateInformation (const void* data, int sizeInBytes)
{
    std::unique_ptr<juce::XmlElement> xmlState (getXmlFromBinary (data, sizeInBytes));
    if (xmlState != nullptr)
    {
        if (xmlState->hasTagName (apvts.state.getType()))
        {
            auto newTree = juce::ValueTree::fromXml (*xmlState);
            {
                const juce::ScopedLock lock ((*sharedInstances).mutex);
                spectrumInstanceAlias = newTree.getProperty ("spectrumInstanceAlias").toString().trim().substring (0, 64);
            }
            const std::array addedParameters { std::pair { "global_output_balance", 0.0f },
                                               std::pair { "global_output_balance_mode", 0.0f },
                                               std::pair { "analyzer_overlap", 1.0f },
                                               std::pair { "output_character", 0.0f },
                                               std::pair { "split_eq", 0.0f } };
            for (const auto& [id, defaultValue] : addedParameters)
            {
                if (! newTree.getChildWithProperty ("id", id).isValid())
                {
                    juce::ValueTree parameter ("PARAM");
                    parameter.setProperty ("id", id, nullptr);
                    parameter.setProperty ("value", defaultValue, nullptr);
                    newTree.addChild (parameter, -1, nullptr);
                }
            }
            for (int band = 0; band < kMaxBands; ++band)
            {
                const auto oldSpectral = newTree.getChildWithProperty ("id", getBandParamID (band, "spectral"));
                const bool wasSpectral = oldSpectral.isValid() && static_cast<float> (oldSpectral.getProperty ("value")) >= 0.5f;
                const std::array controls { std::pair { "spectral", 0.0f }, std::pair { "all_pass", 0.0f },
                                            std::pair { "spectral_density", 0.5f }, std::pair { "spectral_tilt", wasSpectral ? 0.0f : 1.0f },
                                            std::pair { "signal_target", 0.0f } };
                for (const auto& [control, defaultValue] : controls)
                {
                    const auto id = getBandParamID (band, control);
                    if (! newTree.getChildWithProperty ("id", id).isValid())
                    {
                        juce::ValueTree parameter ("PARAM");
                        parameter.setProperty ("id", id, nullptr);
                        parameter.setProperty ("value", defaultValue, nullptr);
                        newTree.addChild (parameter, -1, nullptr);
                    }
                }
            }
            armedMidiTarget.store (-1, std::memory_order_relaxed);
            setSoloBandIndex (-1);
            const auto loadController = [&newTree] (const char* id)
            {
                const int value = static_cast<int> (newTree.getProperty (id, -1));
                return juce::isPositiveAndBelow (value, 16 * 128) ? value : -1;
            };
            learnedControllers[0].store (loadController ("midiOutputLevelCC"), std::memory_order_relaxed);
            learnedControllers[1].store (loadController ("midiGainScaleCC"), std::memory_order_relaxed);
            if (newTree.getProperty (factoryPresetProperty).toString() == "Default")
                newTree.setProperty (factoryPresetProperty, "Default Setting", nullptr);
            setSelectedBandIndex (static_cast<int> (newTree.getProperty ("selectedBandIndex", -1)));
            currentIsB = static_cast<bool> (newTree.getProperty ("currentIsB", false));
            const juce::ScopedLock lock (getCallbackLock());
            apvts.replaceState (newTree);
            resetEqProcessing();
            stateA = apvts.copyState();
            stateB = apvts.copyState();
            updateAllFilterCoefficients();
        }
    }
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new ProQ3AudioProcessor();
}
