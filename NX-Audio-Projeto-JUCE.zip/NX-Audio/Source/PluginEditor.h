#pragma once

#include <juce_gui_basics/juce_gui_basics.h>
#include <juce_audio_processors/juce_audio_processors.h>
#include "PluginProcessor.h"
#include <array>
#include <functional>
#include <memory>
#include <vector>

class ProQ3LookAndFeel final : public juce::LookAndFeel_V4
{
public:
    ProQ3LookAndFeel();
    ~ProQ3LookAndFeel() override = default;

    void drawRotarySlider (juce::Graphics& g,
                           int x, int y, int width, int height,
                           float sliderPosProportional,
                           float rotaryStartAngle,
                           float rotaryEndAngle,
                           juce::Slider& slider) override;

    void drawLinearSlider (juce::Graphics&, int x, int y, int width, int height,
                           float position, float minPosition, float maxPosition,
                           juce::Slider::SliderStyle, juce::Slider&) override;

    void drawToggleButton (juce::Graphics&, juce::ToggleButton&, bool highlighted, bool down) override;

    void drawButtonText (juce::Graphics&, juce::TextButton&, bool highlighted, bool down) override;

    void drawButtonBackground (juce::Graphics& g,
                               juce::Button& button,
                               const juce::Colour& backgroundColour,
                               bool shouldDrawButtonAsHighlighted,
                               bool shouldDrawButtonAsDown) override;

    void drawComboBox (juce::Graphics& g,
                       int width, int height,
                       bool isButtonDown,
                       int buttonX, int buttonY, int buttonW, int buttonH,
                       juce::ComboBox& box) override;

    void drawPopupMenuItem (juce::Graphics& g,
                            const juce::Rectangle<int>& area,
                            bool isSeparator, bool isActive,
                            bool isHighlighted, bool isTicked,
                            bool hasSubMenu,
                            const juce::String& text,
                            const juce::String& shortcutKeyText,
                            const juce::Drawable* icon,
                            const juce::Colour* textColourToUse) override;
};

//==============================================================================
// Knob Concêntrico Duplo de GAIN + ANEL DE FAIXA DINÂMICA (Dynamic Range Ring)
// Centro: altera exclusivamente o Gain estático (-30 a +30 dB)
// Anel externo: área de arraste independente que altera exclusivamente o Dynamic Range (-30 a +30 dB)
// Exibe arco vermelho/âmbar para a faixa dinâmica configurada e arco amarelo vivo para a redução/expansão instantânea
//==============================================================================
class ConcentricGainDynamicsComponent final : public juce::Component
{
public:
    ConcentricGainDynamicsComponent();
    ~ConcentricGainDynamicsComponent() override = default;

    void bindParameters (juce::RangedAudioParameter* staticGainParam,
                         juce::RangedAudioParameter* dynamicRangeParam,
                         juce::UndoManager* undoMgr);

    void setLiveDynamicModulationDb (float modDb) noexcept;
    void setDynamicsActiveAndSupported (bool isSupported, bool isDynBypassed) noexcept;

    void paint (juce::Graphics& g) override;
    void mouseMove (const juce::MouseEvent& e) override;
    void mouseExit (const juce::MouseEvent& e) override;
    void mouseDown (const juce::MouseEvent& e) override;
    void mouseDrag (const juce::MouseEvent& e) override;
    void mouseUp (const juce::MouseEvent& e) override;
    void mouseDoubleClick (const juce::MouseEvent& e) override;
    void mouseWheelMove (const juce::MouseEvent& e, const juce::MouseWheelDetails& wheel) override;

    bool isHoveringOuterRing() const noexcept { return hoveringRing; }

private:
    bool hitTestOuterRing (juce::Point<float> pt) const noexcept;
    float getStaticGainDb() const noexcept;
    float getDynamicRangeDb() const noexcept;
    void setStaticGainDb (float newDb);
    void setDynamicRangeDb (float newDb);

    juce::RangedAudioParameter* gainParam = nullptr;
    juce::RangedAudioParameter* dynRangeParam = nullptr;
    juce::UndoManager* undoManager = nullptr;

    float liveDynamicModDb = 0.0f;
    bool shapeSupportsDynamics = true;
    bool dynamicsBypassed = false;

    bool hoveringRing = false;
    bool hoveringInner = false;
    bool draggingOuterRing = false;
    bool draggingInnerKnob = false;
    float dragStartY = 0.0f;
    float dragStartValueDb = 0.0f;
};

class ProQ3AudioProcessorEditor final : public juce::AudioProcessorEditor,
                                        private juce::Timer
{
public:
    explicit ProQ3AudioProcessorEditor (ProQ3AudioProcessor&);
    ~ProQ3AudioProcessorEditor() override;

    void paint (juce::Graphics&) override;
    void resized() override;

    void mouseEnter (const juce::MouseEvent& event) override;
    void mouseExit (const juce::MouseEvent& event) override;
    void mouseMove (const juce::MouseEvent& event) override;
    void mouseDown (const juce::MouseEvent& event) override;
    void mouseDrag (const juce::MouseEvent& event) override;
    void mouseUp (const juce::MouseEvent& event) override;
    void mouseDoubleClick (const juce::MouseEvent& event) override;
    void mouseWheelMove (const juce::MouseEvent& event, const juce::MouseWheelDetails& wheel) override;
    bool keyPressed (const juce::KeyPress& key) override;

    // Parser de entrada de texto com atalhos do manual Pro-Q 3 ("2k", "A4", "C#3 + 13", "50%")
    static double parseFrequencyTextInput (const juce::String& text, double currentFreqHz) noexcept;

private:
    struct PianoButton final : juce::Button
    {
        PianoButton();
        void paintButton (juce::Graphics&, bool highlighted, bool down) override;
    };

    struct OutputPanel final : juce::Component
    {
        void paint (juce::Graphics&) override;
    };

    struct SoloButton final : juce::Button
    {
        SoloButton (ProQ3AudioProcessorEditor&, bool onBandCard);
        void paintButton (juce::Graphics&, bool highlighted, bool down) override;
        void mouseDown (const juce::MouseEvent&) override;
        void mouseDrag (const juce::MouseEvent&) override;
        void mouseUp (const juce::MouseEvent&) override;

        ProQ3AudioProcessorEditor& editor;
        bool onBandCard;
    };

    void startBandSolo (SoloButton&, const juce::MouseEvent&);
    void dragBandSolo (const juce::MouseEvent&);
    void stopBandSolo();

    void timerCallback() override;
    void configureOutputControls();
    void updateOutputReadout();
    void showOutputPanel();
    void updateOutputPanelVisibility();
    void showOutputOptions();
    void configureAnalyzerPanel();
    void configureInstanceOverview();
    void setInstanceOverviewOpen (bool);
    void updateInstanceOverview (double now);
    void showAnalyzerMenu();
    void openAnalyzerPanel (bool pinned);
    void dismissAnalyzerPanel();
    void updateAnalyzerHover (double now);
    void refreshAnalyzerPanel();
    void layoutAnalyzerPanel();
    void selectAnalyzerSource (int sourceId);
    juce::String getAnalyzerSourceName() const;
    void updateExternalSpectrum (bool frozen);
    void updateSourcePreviews (double now, bool frozen);
    void updateSpectrumGrab (double now);
    void finishSpectrumGrab();
    double getAnalyzerTiltChange() const noexcept;
    static constexpr size_t analyzerPreviewPoints = 92;
    using AnalyzerPreview = std::array<float, analyzerPreviewPoints>;
    static double analyzerPreviewFrequency (double normalizedPosition);
    static AnalyzerPreview sampleAnalyzerProfile (const std::vector<float>&, double sampleRate);
    static AnalyzerPreview measureAnalyzerOverlaps (const AnalyzerPreview&, const AnalyzerPreview&);
    void configureMatchPanel();
    void openMatchPanel();
    void closeMatchPanel();
    void refreshMatchReferenceMenu();
    void refreshMatchControls();
    void updateMatchCapture (const std::vector<float>&, double sampleRate, bool sidechain);
    void buildMatchPreview();
    void applyMatchPreview();
    void saveMatchReference();
    void drawMatchSpectra (juce::Graphics&, juce::Rectangle<int>);
    static float sampleSpectrum (const std::vector<float>&, double frequency, double sampleRate);
    static double spectrumBandPower (const std::vector<float>&, double centre, double rate);
    bool grabSpectrumPeak (juce::Point<float> position);
    void layoutBandControls();
    bool isOverFrequencyStrip (juce::Point<int>) const noexcept;
    void updateFrequencyView (double anchor, double zoom, double position);
    void showMidiLearnMenu();
    void toggleExpandedView();
    void refreshStatusControls();
    void setParameterFromEditor (const char* id, float value);

    float frequencyToX (double freqHz) const noexcept;
    double xToFrequency (float x) const noexcept;
    float gainDbToY (double gainDb) const noexcept;
    double yToGainDb (float y) const noexcept;
    float analyzerDbToY (double analyzerDb) const noexcept;
    int getSpectrumDisplayRange() const noexcept;
    double getCurrentDisplayRangeDb() const noexcept;

    static juce::String frequencyToMusicalNoteName (double freqHz);
    static double snapFrequencyToNearestSemitone (double freqHz) noexcept;

    void attachFloatingControlsToBand (int bandIndex);
    void updateFloatingControlsVisibilityAndValues();
    void stepSelectedBand (int delta);
    void showFactoryPresetMenu();
    void stepFactoryPreset (int delta);
    void loadFactoryPreset (int index);
    void refreshFactoryPresetName();

    bool startNewCurveBandDrag (juce::Point<float> position);
    int findBandNodeAtPosition (juce::Point<float> pos, float maxRadiusPx = 14.0f) const noexcept;

    void drawTopToolbar (juce::Graphics& g, juce::Rectangle<int> bounds);
    void drawEqGridAndScales (juce::Graphics& g, juce::Rectangle<int> area);
    void drawSpectrumAnalyzer (juce::Graphics& g, juce::Rectangle<int> area);
    float spectrumLevelAtX (const std::vector<float>&, double sampleRate, float x) const;
    void updateSpectrumPeaks (double now);
    void drawSpectrumPeaks (juce::Graphics& g);
    void drawEqCurvesAndBandNodes (juce::Graphics& g, juce::Rectangle<int> area);
    juce::Rectangle<int> getBandTooltipBounds (const ProQ3AudioProcessor::BandParameters&) const noexcept;
    bool isOverBandTooltip (juce::Point<int> position) const noexcept;
    void updateBandShortcuts();
    void showBandOptions (int band, juce::Component* anchor = nullptr);
    void applyBandOption (int band, int action);
    void splitBand (int band);
    void drawCurvePreview (juce::Graphics&);
    ProQ3AudioProcessor::BandParameters suggestBand (juce::Point<float>) const;
    void drawBandParameterTooltip (juce::Graphics& g, int bandIndex);
    void drawPianoRollBar (juce::Graphics& g, juce::Rectangle<int> area);
    void drawFloatingBandControlsBackground (juce::Graphics& g);
    void drawOutputMeter (juce::Graphics& g, juce::Rectangle<int> meterBounds);
    void drawBottomToolbar (juce::Graphics& g, juce::Rectangle<int> bounds);

    ProQ3AudioProcessor& audioProcessor;
    ProQ3LookAndFeel lookAndFeel;

    juce::Rectangle<int> topBarBounds;
    juce::Rectangle<int> graphBounds;
    juce::Rectangle<int> pianoBounds;
    juce::Rectangle<int> meterBounds;
    juce::Rectangle<int> bottomBarBounds;
    juce::Rectangle<int> floatingPillBounds;
    juce::Rectangle<int> manualThreshMeterBounds;
    std::array<ProQ3AudioProcessor::BandDynamicsReading, ProQ3AudioProcessor::kMaxBands> bandDynamics {};

    // Top Bar
    juce::TextButton undoButton  { "Undo" };
    juce::TextButton redoButton  { "Redo" };
    juce::TextButton abButton    { "A/B" };
    juce::TextButton copyButton  { "Copy" };
    juce::TextButton prevPresetButton { "<" };
    juce::TextButton presetNameButton { "Default" };
    juce::TextButton nextPresetButton { ">" };
    juce::TextButton helpButton  { "Help" };
    juce::TextButton expandButton;
    juce::Rectangle<int> compactEditorBounds;

    // Floating Band Controls Pill (com crista superior para o anel dinâmico, botão Auto, Bypass Dynamics e Clear Dynamics)
    juce::ToggleButton bandBypassButton { "" };
    juce::ComboBox     bandShapeBox;
    juce::ComboBox     bandSlopeBox;

    juce::Slider       freqSlider;
    ConcentricGainDynamicsComponent concentricGainKnob;
    juce::Slider       qSlider;
    juce::ToggleButton gainQInterButton { "G-Q" };

    // Controles específicos do anel dinâmico do GAIN (Manual Pro-Q 3 p. 13-14 + imagem de referência)
    juce::TextButton   clearDynamicsButton  { "x" };    // 'x' à esquerda do arco: zera dyn_range sem excluir a banda
    juce::ToggleButton bypassDynamicsButton { "D-On" }; // Power junto ao anel: suspende somente a dinâmica
    juce::ToggleButton autoThresholdButton  { "Auto" }; // Topo do arco: alterna entre Auto e Manual Threshold
    juce::Label        manualThresholdValue;
    juce::Slider       manualThresholdSlider;           // Slider de limiar manual em dB (-60 a 0 dB) visível quando Auto está desligado
    juce::ToggleButton externalSidechainButton { "SC" };// Botão External Side Chain visível no modo manual

    juce::Label        freqTitleLabel;
    juce::Label        gainTitleLabel;
    juce::Label        qTitleLabel;
    juce::Label        freqRangeHintLabel;
    juce::Label        gainRangeHintLabel;
    juce::Label        qRangeHintLabel;

    juce::TextButton   prevBandButton   { "<" };
    juce::Label        bandNumberLabel;
    juce::TextButton   nextBandButton   { ">" };
    juce::TextButton   deleteBandButton { "X" }; // 'X' no canto superior direito: exclui a banda
    juce::ComboBox     stereoModeBox;
    SoloButton soloBandButton { *this, false };
    SoloButton bandSoloShortcut { *this, true };
    SoloButton* heldSoloButton = nullptr;
    int soloControlBand = -1;
    juce::Point<float> soloDragOrigin;
    double soloStartFrequency = 1000.0;
    double soloStartQ = 1.0;
    float soloStartLevel = -6.0f;
    float soloListeningLevel = -6.0f;
    juce::RangedAudioParameter* soloFrequencyGesture = nullptr;
    juce::RangedAudioParameter* soloQGesture = nullptr;
    juce::TextButton   splitStereoButton { "Split" };

    // Attachments dinâmicos do APVTS para a banda selecionada
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment>   bandEnabledAttachment;
    std::unique_ptr<juce::ParameterAttachment> bandShapeAttachment;
    std::unique_ptr<juce::ParameterAttachment> allPassAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> bandSlopeAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment>   freqAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment>   qAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment>   gainQInterAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment>   bypassDynamicsAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment>   autoThresholdAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment>   manualThresholdAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment>   externalSidechainAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> stereoModeAttachment;

    // Bottom Bar
    juce::ComboBox     processingModeBox;
    juce::TextButton   analyzerButton { "Analyzer: Pre+Post" };
    juce::TextButton   midiLearnButton { "MIDI Learn" };
    PianoButton        pianoToggleButton;
    juce::TextButton  displayRangeButton { "12 dB" };
    juce::TextButton   outputControlButton { "100%  0.0 dB" };
    OutputPanel        outputPanel;
    juce::Label        outputLevelLabel    { {}, "Output Level" };
    juce::Label        outputScaleLabel    { {}, "Gain Scale" };
    juce::Label        outputBalanceLabel  { {}, "Balance" };
    juce::Slider       outputGainSlider;
    juce::Slider       outputScaleSlider;
    juce::Slider       outputBalanceSlider;
    juce::ComboBox     outputBalanceModeBox;
    juce::TextButton   outputPolarityButton { "Ø" };
    juce::TextButton   outputAutoGainButton { "A" };
    juce::TextButton   outputOptionsButton  { "..." };
    double outputPanelLastInteraction = 0.0;
    bool outputPanelKeyboardAccess = false;
    bool outputOptionsOpen = false;
    juce::ToggleButton globalBypassButton   { "Bypass" };

    std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> processingModeAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment>   pianoDisplayAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment>   outputGainAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment>   outputScaleAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment>   outputBalanceAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> outputBalanceModeAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment>   outputPolarityAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment>   outputAutoGainAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment>   globalBypassAttachment;

    juce::DrawableButton bandDynamicsShortcut { "Open Dynamic EQ", juce::DrawableButton::ImageFitted };
    juce::DrawableButton bandShapeShortcut { "Filter Shape", juce::DrawableButton::ImageFitted };
    juce::TextButton bandOptionsShortcut { "..." };
    juce::TextButton bandPowerShortcut;
    juce::TextButton bandDeleteShortcut { "x" };
    int bandMenuIndex = -1;
    int shortcutShape = -1;
    int shapeQuickBand = -1;
    juce::Component shapeQuickRail;
    std::array<std::unique_ptr<juce::DrawableButton>, 10> shapeQuickButtons;
    std::optional<ProQ3AudioProcessor::BandParameters> clipboardBand;
    struct AnalyzerBackdrop final : juce::Component
    {
        std::function<void()> dismiss;
        void mouseDown (const juce::MouseEvent&) override { if (dismiss) dismiss(); }
    };
    struct AnalyzerToolButton final : juce::Button
    {
        enum class Icon { freeze, grab, overlap, settings };
        AnalyzerToolButton (const char* name, Icon icon);
        void paintButton (juce::Graphics&, bool highlighted, bool down) override;
        const Icon icon;
    };

    struct AnalyzerPanel final : juce::Component, private juce::ListBoxModel
    {
        static constexpr int rowHeight = 36;

        struct Source
        {
            int id;
            juce::String name;
            AnalyzerPreview levels {};
            AnalyzerPreview overlap {};
            bool hasTrace = false;
        };

        struct SettingsPane final : juce::Component
        {
            void paint (juce::Graphics&) override;
        };

        AnalyzerPanel();
        ~AnalyzerPanel() override;
        void paint (juce::Graphics&) override;
        void resized() override;
        void setSelectedSource (int id);
        void setSources (const std::vector<ProQ3AudioProcessor::SpectrumPeer>&);
        int preferredHeight() const noexcept;
        bool sourceIsVisible (int row) const;
        bool hasOpenCombo() const;

        std::function<void (int)> onSourceChanged;
        std::vector<Source> sources;
        juce::ListBox sourceList;
        juce::Label instance;
        juce::TextButton pre { "Pre" }, post { "Post" }, peaks { "Peak Labels" };
        AnalyzerToolButton freeze { "Freeze", AnalyzerToolButton::Icon::freeze };
        AnalyzerToolButton grab { "Spectrum Grab", AnalyzerToolButton::Icon::grab };
        AnalyzerToolButton overlaps { "Spectrum Overlap", AnalyzerToolButton::Icon::overlap };
        AnalyzerToolButton settingsButton { "Analyzer Settings", AnalyzerToolButton::Icon::settings };
        juce::TextButton match { "EQ Match" };
        SettingsPane settings;
        juce::ComboBox speed, tilt, range, detail, resolution;

    private:
        int getNumRows() override;
        juce::String getNameForRow (int) override;
        void paintListBoxItem (int row, juce::Graphics&, int width, int height, bool selected) override;
        void selectedRowsChanged (int row) override;
        bool syncingSelection = false;
    };
    AnalyzerBackdrop analyzerBackdrop;
    AnalyzerPanel analyzerPanel;
    struct InstanceOverview final : juce::Component, juce::ListBoxModel
    {
        explicit InstanceOverview (ProQ3AudioProcessorEditor&);
        ~InstanceOverview() override;
        void paint (juce::Graphics&) override;
        void resized() override;
        void refresh();
        int getNumRows() override;
        juce::String getNameForRow (int) override;
        void paintListBoxItem (int, juce::Graphics&, int, int, bool) override;
        void listBoxItemDoubleClicked (int, const juce::MouseEvent&) override;

        struct Track
        {
            int id = 0;
            juce::String name;
            ProQ3AudioProcessor::OverviewCurve response;
            std::vector<float> spectrum;
            double sampleRate = 0.0;
            double lastSpectrumMs = 0.0;
        };
        ProQ3AudioProcessorEditor& editor;
        juce::ListBox rows;
        juce::TextEditor search;
        juce::Slider size;
        juce::TextButton close { "Back to EQ" };
        std::vector<Track> tracks;
        juce::uint64 generation = 0;
    };

    juce::TextButton instanceButton { "NX Audio" };
    InstanceOverview instanceOverview { *this };
    double lastOverviewMs = 0.0;

    bool analyzerPinned = false;
    bool analyzerHoverSuppressed = false;
    double analyzerHoverSince = 0.0;
    double analyzerLastInteraction = 0.0;
    std::array<std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment>, 5> analyzerAttachments;
    std::vector<ProQ3AudioProcessor::SpectrumPeer> analyzerPeers;
    int analyzerExternalId = 0;
    juce::uint64 seenPostSpectrum = 0;
    double externalSampleRate = 0.0;
    double lastExternalRefreshMs = 0.0;
    double lastAnalyzerRefreshMs = 0.0;
    double lastPreviewRefreshMs = 0.0;
    double spectrumGrabHoverSince = 0.0;
    juce::Point<int> spectrumGrabHoverAnchor;
    juce::Point<int> spectrumGrabPointer;
    bool spectrumGrabPointerInGraph = false;
    bool spectrumGrabActive = false;
    bool spectrumPeakHoverActive = false;
    bool draggingSpectrumPeak = false;
    std::vector<float> externalSpectrumDb;
    AnalyzerPreview activeSpectrumOverlap {};
    static constexpr std::array<double, 18> matchFrequencies {
        45, 63, 90, 125, 180, 250, 355, 500, 710, 1000, 1400, 2000, 2800, 4000, 5600, 8000, 11300, 16000
    };
    using MatchPowers = std::array<double, matchFrequencies.size()>;
    struct MatchCapture
    {
        MatchPowers power {};
        int frames = 0;
        bool recording = false;
        bool ready() const noexcept { return frames >= 5; }
    };
    struct MatchReference
    {
        juce::String name;
        MatchPowers power {};
    };
    struct MatchPanel final : juce::Component
    {
        void paint (juce::Graphics&) override;
        juce::TextButton input { "Record Input" }, resetInput { "Reset Input" }, recordReference { "Record Reference" };
        juce::TextButton preview { "Match" }, finish { "Apply Match" }, back { "Capture" }, close { "Close" }, save { "Save" };
        juce::ComboBox reference;
        juce::Label status;
        juce::TextEditor referenceName;
        juce::Slider bandCount;
    };
    static juce::File getMatchLibraryFile();
    static std::vector<MatchReference> loadMatchLibrary();

    MatchPanel matchPanel;
    MatchCapture matchInput, matchReference;
    std::vector<MatchReference> savedMatchReferences;
    std::vector<ProQ3AudioProcessor::BandParameters> matchPreview;
    int selectedMatchSource = 0;
    int matchExternalId = 0;
    bool showingMatchPreview = false;
    bool savingMatchReference = false;
    int expandedDynamicsBand = -1;
    int attachedBandIndex = -1;
    int hoveredBandIndex  = -1;
    int draggingBandIndex = -1;
    bool draggingFrequencyView = false;
    double frequencyViewStart = 0.0;
    double frequencyViewSpan = 1.0;
    double dragStartViewAnchor = 0.0;
    double dragStartViewSpan = 1.0;
    bool waitingForEdgeDrag = false;
    bool isDraggingNode   = false;
    bool isDraggingDynHandle = false;
    bool isSelectionRectDragging = false;
    juce::Point<float> dragStartMousePos;
    juce::Rectangle<float> selectionLassoRect;
    double dragStartFreqHz = 1000.0;
    double dragStartGainDb = 0.0;
    double dragStartDynRangeDb = 0.0;
    double dragStartQ      = 1.0;
    juce::Point<float> lastMousePos { -1.0f, -1.0f };
    bool showHelpOverlay = false;

    enum class SpectrumSource { none, pre, post, sidechain };
    SpectrumSource peakSource = SpectrumSource::none;
    double peakSampleRate = 0.0;
    size_t peakSpectrumBins = 0;

    static constexpr double peakConfirmationMs = 110.0;

    struct SpectrumPeak
    {
        double frequency = 0.0;
        float level = 0.0f;
        double firstSeen = 0.0;
        double lastSeen = 0.0;
    };
    std::array<SpectrumPeak, 5> spectrumPeaks {};
    std::array<juce::Rectangle<float>, 5> peakTags {};
    std::array<double, 5> peakTagFrequencies {};
    std::vector<float> rawSpectrumDb;
    double lastSpectrumFrameMs = 0.0;
    double spectrumIdleMs = 0.0;
    std::vector<float> smoothedPreSpectrumDb;
    std::vector<float> smoothedPostSpectrumDb;
    std::vector<float> smoothedSidechainSpectrumDb;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (ProQ3AudioProcessorEditor)
};
