#pragma once

#include "PluginProcessor.h"

namespace FactoryPresets
{
    using Processor = ProQ3AudioProcessor;

    constexpr auto bell = Processor::kShapeBell;
    constexpr auto lowShelf = Processor::kShapeLowShelf;
    constexpr auto highShelf = Processor::kShapeHighShelf;
    constexpr auto lowCut = Processor::kShapeLowCut;
    constexpr auto highCut = Processor::kShapeHighCut;
    constexpr auto tiltShelf = Processor::kShapeTiltShelf;

    constexpr Processor::BandParameters band (int shape, double hz, double gain = 0.0,
                                               double q = 1.0, double dynamicRange = 0.0,
                                               int slope = Processor::kSlope12dB, int channel = 0)
    {
        Processor::BandParameters result;
        result.used = true;
        result.shape = shape;
        result.freqHz = hz;
        result.gainDb = gain;
        result.q = q;
        result.dynRangeDb = dynamicRange;
        result.slopeIndex = slope;
        result.stereoMode = channel;
        return result;
    }

    struct Preset
    {
        const char* name;
        std::initializer_list<Processor::BandParameters> bands;
        const char* category = nullptr;
        int displayRange = -1;
        int phase = 0;
        float output = 0.0f;
    };

    constexpr auto cut6 = Processor::kSlope6dB;
    constexpr auto cut12 = Processor::kSlope12dB;
    constexpr auto cut24 = Processor::kSlope24dB;
    constexpr int left = 1, right = 2, mid = 3, side = 4;
    constexpr int range12 = 2, range30 = 3;
    constexpr int zeroLatency = 0, naturalPhase = 1, linearPhase = 2;

    // The user supplied curve screenshots. Band widths, slopes and dynamic spans are estimates.
    inline constexpr Preset entries[] {
        { "Default", { band (bell, 1000) } },
        { "Dynamic De-Esser 6 kHz", { band (bell, 6000, 0, 3, -6) } },
        { "Flat Tilt Mastering", { band (Processor::kShapeFlatTilt, 1000, 1.5) } },
        { "Clean Slate", {} },
        { "Drums", { band (lowCut, 20, 0, 0.8, 0, cut24), band (lowShelf, 50, -1),
                     band (bell, 100, 2, 1.3), band (bell, 5000, 2, 1.3),
                     band (highShelf, 10000, 1), band (highCut, 30000, 0, 0.75, 0, cut12) },
          nullptr, range12 },
        { "Phone", { band (lowCut, 520, 0, 0.8, 0, cut24), band (bell, 950, 4.6, 2.1),
                     band (bell, 1625, 6.3, 2), band (bell, 2670, 6, 4.5),
                     band (highCut, 3600, 0, 0.8, 0, cut24) }, nullptr, range12 },
        { "Vocal", { band (lowCut, 30), band (lowShelf, 60, -3, 0.7),
                     band (bell, 6500, 1, 0.8), band (highShelf, 10000, 3, 0.7) }, nullptr, range12 },

        { "Drumbus - Mud Control and Magic",
          { band (highShelf, 20, 0, 0.8, -8), band (lowShelf, 80, 0, 0.7, 4),
            band (bell, 415, -6, 0.75, 9, cut12, mid), band (bell, 415, -4, 0.8, 8, cut12, side),
            band (bell, 3000, 0, 0.9, 4), band (bell, 4250, 0, 1),
            band (bell, 6500, 1, 0.9, -6, cut12, mid), band (bell, 6500, 1, 0.9, -6, cut12, side),
            band (highShelf, 17500, -1, 0.8, 2, cut12, side) }, "Drums", range30, naturalPhase, 2 },
        { "HiHat 1 - Low Cut and Bright",
          { band (lowCut, 1000, 0, 1, 0, cut6), band (tiltShelf, 1200, 0, 0.7, 20),
            band (bell, 2400, 0, 3, -6), band (bell, 8000, 0, 3, -10),
            band (highShelf, 10000, 0, 0.8, -12) }, "Drums", range30, naturalPhase, 4 },
        { "Kick 1 inside mic - Punch and Click",
          { band (lowShelf, 115, 1, 0.7, 7), band (bell, 205, -6, 0.7, 5),
            band (bell, 620, -3, 1.2, 3), band (bell, 3500, 5, 1, -8) }, "Drums", range12 },
        { "Kick 1 outside mic - Subs and Bleed Control",
          { band (bell, 40, 7, 0.7, -10), band (bell, 136, -6, 2.2),
            band (bell, 420, -7, 0.55, 8), band (bell, 4100, 3, 1, 3),
            band (bell, 9400, -10, 0.35, 10) }, "Drums", range12, naturalPhase },
        { "Kick Fixer",
          { band (lowCut, 21), band (bell, 50, 0, 1.3, 6), band (bell, 145, -9.3, 1.15, 6.8),
            band (bell, 580, -3.8, 1), band (bell, 3250, 2.5, 0.8, -3),
            band (highCut, 10500, 0, 0.85, 0, cut24) }, "Drums", range12 },
        { "Overheads 1 - Mud Cleanup and Control",
          { band (bell, 600, -10, 0.65, 14), band (tiltShelf, 3000, 0, 0.7, 4),
            band (bell, 7800, 1, 2.6, -9) }, "Drums", range12, naturalPhase },
        { "Overheads 2 - Low Suppression",
          { band (lowCut, 150, 0, 1, 0, cut6), band (lowShelf, 260, -3, 0.7, -27),
            band (bell, 1250, 0, 0.55, -10), band (highShelf, 4000, 17, 0.7, -15),
            band (bell, 7200, -5, 0.8, 5) }, "Drums", range30, zeroLatency, 1 },
        { "Overheads 3 - Darkener",
          { band (bell, 48, 2, 0.9, 3.2), band (bell, 155, 2.2, 1, 2.5),
            band (bell, 460, -3.8, 1.1, 2.5), band (highShelf, 3400, 1.8, 0.7, -7.6) },
          "Drums", range12, naturalPhase },
        { "Room 1 - Mud Removal and Control",
          { band (bell, 132, -9, 1.6, 9), band (bell, 400, -4, 0.65, 4),
            band (lowShelf, 6000, 5, 0.6, -9), band (bell, 7100, -3, 1.5, 3),
            band (bell, 15000, 2, 1, -6) }, "Drums", range12, naturalPhase, 1 },
        { "Room 2 - Bright and Resonance Control",
          { band (bell, 235, -6, 0.6, 8), band (bell, 355, 0, 4, -14),
            band (bell, 820, -6, 0.55, 8), band (bell, 2650, 5, 1, -10),
            band (highShelf, 22000, 1, 0.7, -16) }, "Drums", range30, linearPhase, 4 },
        { "Snare 1 bottom - Bleed Control",
          { band (lowCut, 155, 0, 0.85, 0, cut24), band (bell, 265, 4.8, 0.8, -3),
            band (bell, 700, -8, 0.8, 4), band (bell, 7600, -6, 0.65, 6) },
          "Drums", range12, naturalPhase, 1 },
        { "Snare 1 top - Punch and Bleed Control",
          { band (highShelf, 120, 5, 0.75, -5), band (bell, 220, -4, 1.7, 6), band (bell, 520, -5, 1.1, 6),
            band (bell, 1200, -1.5, 0.65), band (highShelf, 2250, -11, 0.85, 19),
            band (bell, 3300, 4.3, 1.1) }, "Drums", range12, naturalPhase, 1 },
        { "Snare 2 bottom - Rattle Control",
          { band (lowCut, 170, 0, 1, 0, cut6), band (bell, 210, 0, 1.7, 4),
            band (bell, 420, 5, 0.8, -9), band (bell, 690, -10, 1.1, 14),
            band (bell, 710, 1, 1.8, -8), band (bell, 1750, -5, 2, 6),
            band (bell, 3000, 2, 1.3, -3), band (highCut, 6100, 0, 1, 0, cut6),
            band (bell, 7600, 3, 0.7, -14) }, "Drums", range30, naturalPhase, 1 },
        { "Snare 2 top - Control and Sustain",
          { band (highShelf, 120, 5, 0.75, -4.5), band (bell, 220, -4, 1.7, 6),
            band (bell, 300, 4, 2.1, -7.3), band (bell, 520, -5, 1, 6),
            band (highShelf, 4000, -11, 0.75, 15), band (bell, 5000, 5, 1.1),
            band (bell, 10000, -2, 1.2, 7) }, "Drums", range12, naturalPhase, -1 },
        { "Snare Salvage",
          { band (bell, 210, 4.3, 1.35, -2.7), band (bell, 500, -5, 1.4, 2.8),
            band (highShelf, 2050, -5.5, 0.7, 12) }, "Drums", range12, naturalPhase },
        { "Tom Floor 1 - Punch and Click",
          { band (bell, 90, 1, 0.85, 6), band (bell, 405, -11, 1.1, 9),
            band (bell, 2850, 1, 0.8, 7), band (bell, 7950, 0, 2, -12) }, "Drums", range12 },
        { "Tom Rack 1 - Punch and Click",
          { band (bell, 130, 1, 0.9, 6), band (bell, 340, -7, 1.1, 6),
            band (bell, 2800, 0, 1, 6), band (bell, 6500, 0, 3, -6) }, "Drums", range12 },

        { "Ac Guitar - Control and Excitement",
          { band (lowCut, 60, 0, 0.8, 0, cut24), band (bell, 235, 0, 1.6, -2),
            band (tiltShelf, 600, 0.5, 0.7, -3), band (bell, 3600, -1, 0.45, 4) }, "Instruments", range12 },
        { "Ac Guitar - Control and Excitement (Unlinked)",
          { band (lowCut, 60, 0, 0.8, 0, cut24),
            band (bell, 235, 0, 1.6, -2, cut12, left), band (bell, 235, 0, 1.6, -2, cut12, right),
            band (tiltShelf, 600, 0.5, 0.7, -3, cut12, left), band (tiltShelf, 600, 0.5, 0.7, -3, cut12, right),
            band (bell, 3600, -1, 0.45, 4, cut12, left), band (bell, 3600, -1, 0.45, 4, cut12, right) },
          "Instruments", range12 },
        { "Ac Guitar - Mud Removal 1",
          { band (bell, 180, -3, 0.65, 3.6), band (bell, 190, -0.3, 2, -2.7) }, "Instruments", range12 },
        { "Ac Guitar - Mud Removal 2",
          { band (bell, 180, -4, 0.65, 5), band (bell, 190, 0, 2, -2.5),
            band (bell, 1300, -1.5, 0.45, 2.5) }, "Instruments", range12 },
        { "Ac Guitar - Mud Removal 2 (Unlinked)",
          { band (bell, 180, -4, 0.65, 5),
            band (bell, 190, 0, 2, -2.5, cut12, left), band (bell, 190, 0, 2, -2.5, cut12, right),
            band (bell, 1300, -1.5, 0.45, 2.5) }, "Instruments", range12 },
        { "Bass Balancer",
          { band (bell, 87, 4, 0.9, -4), band (bell, 262, 5, 0.85, -5),
            band (bell, 790, 3, 0.65, -3), band (bell, 2450, 6, 0.85, -6) },
          "Instruments", range12, zeroLatency, -3 },
        { "Bass Gtr - Brighten",
          { band (bell, 190, -0.8, 0.7, -4), band (bell, 300, -10.5, 0.95, 12),
            band (bell, 770, 3.2, 1.4, 8.5), band (tiltShelf, 1100, -2.6, 0.7, -4),
            band (bell, 2600, 2.6, 1.8, 12.5) }, "Instruments", range30 },
        { "Bass Gtr - DI Transformation",
          { band (lowCut, 45, 0, 1, 0, cut6), band (bell, 44, 2.4, 3, 1.4),
            band (bell, 145, -0.7, 0.65, -4.5), band (bell, 170, 0, 7, -6),
            band (bell, 600, 1.5, 1, 3), band (tiltShelf, 1100, -1.2, 0.7, -3),
            band (bell, 2400, -0.9, 0.65, 3.3) }, "Instruments", range12 },
        { "Bass Gtr - Tonal Control",
          { band (bell, 190, -0.7, 0.85, -4.6), band (bell, 770, 0.7, 1.8, 2.4),
            band (tiltShelf, 1100, -2.5, 0.7, -3), band (bell, 2900, -1.3, 0.65, 4) }, "Instruments", range12 },
        { "Guitar Repair",
          { band (bell, 104, 6, 0.9, -6), band (bell, 356, 4, 0.8, -4),
            band (bell, 1500, 6, 0.65, -6), band (bell, 7500, 6, 0.65, -6) }, "Instruments", range12 },

        { "Choir - Fullness and Air",
          { band (lowShelf, 136, 2.2, 0.65, -2.2), band (bell, 690, 2, 0.4, -3),
            band (highShelf, 1100, -1.6, 0.65, 4.1) }, "Vocals", range12 },
        { "Vocal Lead 1",
          { band (bell, 410, -2.5, 0.35, 2.5), band (bell, 2250, 0.3, 7, -4),
            band (bell, 3200, 2, 0.55, -2), band (bell, 12000, 3, 0.8, -3) },
          "Vocals", range12, zeroLatency, 0.3f },
        { "Vocal Lead 2",
          { band (lowCut, 86, 0, 0.8, 0, cut12), band (bell, 150, 1.5, 0.45, -3),
            band (bell, 630, 0.8, 0.7, -2.5), band (bell, 3800, -0.7, 0.6, 2),
            band (bell, 14400, 2.2, 0.4, -3.5) }, "Vocals", range12 },
        { "Vocal Lead 3",
          { band (lowCut, 110, 0, 0.8, 0, cut12), band (bell, 100, 3, 0.5, -3.5),
            band (bell, 710, 0.5, 0.7, -2.5), band (bell, 2170, -1.8, 0.65, 2.4),
            band (highShelf, 6200, 2.7, 0.7, -3.5) }, "Vocals", range12, zeroLatency, 0.5f },
    };
}
