# FABPRO-Q4

Projeto editável de equalizador dinâmico em C++17, JUCE 8.0.4 e CMake. O nome interno do alvo é `ProQ3Clone`. O nome do plugin na DAW é `FABPRO-Q4`.

## Para continuar em outra IA

Extraia o ZIP e abra a pasta que contém este README e o `CMakeLists.txt`. Use estas notas como ponto de partida para o estado atual do projeto. O `AGENTS.md` veio com o projeto e descreve a arquitetura original.

- `Source/PluginProcessor.cpp` e `.h` contêm o DSP, os parâmetros de automação, o estado de sessão e a aplicação dos presets. Preserve os IDs `ScAu`, `Pq3C` e os IDs dos parâmetros existentes para manter a compatibilidade com as sessões da DAW.
- `Source/PluginEditor.cpp` e `.h` contêm a interface responsiva, o gráfico, os controles de banda e o painel de saída. A janela padrão é de 900 × 540.
- `Source/FactoryPresets.h` contém os 38 presets. Os 34 presets baseados em capturas foram estimados pelo gráfico. Os presets dinâmicos estão agrupados em Drums, Instruments e Vocals.
- `Tests/test_proq3_acceptance.cpp` contém a suíte DSP independente. `Assets/` reúne as imagens de referência do projeto. A interface é desenhada pelo JUCE.
- `build_win64.bat` e `.github/workflows/build_windows_vst3.yml` contêm os caminhos de build Windows.

O painel de saída abre por hover sobre a leitura de porcentagem e dB. Ele controla volume, escala de ganho, balanço L/R ou M/S, polaridade e Auto Gain. O ícone de piano alterna o teclado. O preset Default Setting abre com o gráfico plano. O gráfico usa uma curva total dourada e preenchimentos translúcidos nas respostas individuais e nas faixas dinâmicas. O seletor do gráfico alterna entre 12, 6, 3 e 30 dB e o menu Analyzer controla as leituras de entrada, saída e sidechain. MIDI Learn associa mensagens MIDI CC ao volume de saída e à escala de ganho e salva essas associações com a sessão.

O seletor permite carregar Natural Phase e Linear Phase. O DSP atual ainda usa o mesmo caminho de processamento nesses modos. A última distribuição Windows foi compilada por cross-compilation e validada no Wine. Os comandos abaixo são para um build nativo Windows com Visual Studio.

## Build Windows x64

Requer Git, CMake 3.22 ou mais recente, Visual Studio 2022 com Desenvolvimento para Desktop com C++ e JUCE 8.0.4. Execute na raiz do projeto em PowerShell.

```powershell
git clone --depth 1 --branch 8.0.4 https://github.com/juce-framework/JUCE.git JUCE
cmake -S . -B build -G "Visual Studio 17 2022" -A x64
cmake --build build --config Release --target ProQ3Clone_VST3 --parallel
```

O pacote é gerado em `build/ProQ3Clone_artefacts/Release/VST3/FABPRO-Q4.vst3`. Para gerar também o Standalone, execute `build_win64.bat` ou compile sem indicar um alvo específico.

O ZIP de fontes não inclui a dependência JUCE. A revisão usada é `51d11a2be6d5c97ccf12b4e5e827006e19f0555a` da tag `8.0.4`.

## Espectro, medição e filtros

O analisador calcula a FFT separadamente para L e R e combina as potências. Isso preserva sinais em oposição de fase. As janelas Hann de 4096 pontos se sobrepõem em 75% e o gráfico termina em Nyquist. Pre-EQ, Post-EQ e Sidechain compartilham a mesma escala em dBFS do medidor. O medidor retém o pico por 1,5 s antes de baixar a marca.

Os filtros Low Cut e High Cut usam seções Butterworth da ordem correspondente à inclinação. Configurações de 6, 18 e 30 dB/oct incluem uma seção de primeira ordem. A opção Brickwall usa uma aproximação IIR de 16ª ordem. Os IDs de parâmetros são preservados.
